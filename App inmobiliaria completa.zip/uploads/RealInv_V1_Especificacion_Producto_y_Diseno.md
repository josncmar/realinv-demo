# REALINV — ESPECIFICACIÓN FUNCIONAL Y DE DISEÑO V1

**Documento maestro para generar un prototipo web interactivo (desktop + móvil)**  
**Estado:** propuesta de producto para validación entre socios · **Fecha:** 18 de octubre de 2026  
**Inspiración de experiencia:** sencillez de Amazon, claridad de cartera de Robinhood / Trade Republic y sofisticación visual B2B de Atlan.  
**Mercado inicial:** España · **Idioma de interfaz:** español · **Moneda principal:** EUR.

> **Instrucción esencial a la IA de diseño:** construir una aplicación realista y navegable, no una landing page ni un dashboard genérico. Respetar estrictamente la separación entre *tesis de inversión* (descubrimiento e interés), *operación inmobiliaria* (activo identificado y financiación) e *inversión efectiva* (capital formalizado). Todos los ejemplos numéricos de este documento son **datos sintéticos para demostración**, no datos reales ni retornos prometidos.

---

## 1. Visión, propuesta de valor y definición de la V1

La plataforma permite que una persona descubra oportunidades de inversión inmobiliaria en España, entienda *por qué* una zona o tipología puede ser interesante, manifieste su interés en participar, reciba propuestas de operaciones concretas que respondan a esa tesis y, una vez formalizada una inversión, siga el capital y los hitos de principio a fin.

La diferencia frente a un portal inmobiliario es que **no se navega únicamente por viviendas individuales**: el producto introduce el concepto de **tesis** —combinación de una microzona geográfica, una tipología de activo, un rango de presupuesto y una estrategia económica— como primera unidad de descubrimiento. Así se puede medir demanda antes de seleccionar qué activo concreto ejecutar. Una tesis puede derivar en cero, una o varias operaciones; una misma operación puede recibir interés de múltiples inversores y no necesariamente de todos los seguidores de la tesis.

**Promesa del producto (no financiera):** «Descubre oportunidades inmobiliarias con datos. Decide con contexto. Sigue cada etapa con transparencia». Evitar prometer rentabilidad, liquidez o plazos de salida garantizados.

### 1.1 Los tres objetos que el prototipo nunca debe mezclar

| Objeto | Qué representa | Qué puede hacer el usuario | Qué NO significa |
|---|---|---|---|
| **Tesis** | Estrategia en un barrio o microzona; por ejemplo, pisos de 2 dormitorios para reformar en Patraix | Explorar, guardar, indicar interés y presupuesto indicativo, seguir oportunidades asociadas | No hay inmueble seleccionado ni dinero invertido automáticamente |
| **Operación** | Vivienda/proyecto concreto que el equipo ha identificado y validado, con presupuesto, hitos y captación de financiación | Revisar ficha definitiva, documentación, escenarios y financiación; avanzar a confirmación si procede | Un contador de interés no equivale a financiación cerrada |
| **Inversión** | Posición del usuario en una operación formalizada conforme al modelo jurídico futuro | Consultar importe, derecho económico, estado, estimaciones y liquidación final | Una estimación no es efectivo disponible ni un precio de mercado negociable |

### 1.2 Objetivo del prototipo

Que un inversor potencial pueda completar cuatro experiencias memorables: (1) registrarse y perfilarse; (2) descubrir tesis a través de recomendaciones **o** un mapa exploratorio; (3) seguir una tesis y ver cómo aparecen operaciones financiables; (4) entender su cartera con estados reales y valoraciones claramente identificadas como estimadas.

No se requiere en esta entrega una plataforma bancaria, un modelo de IA predictivo entrenado, integraciones con notarios, un sistema real de pagos o un motor fiscal. Se requiere **una V1 visual, funcional, convincente y con datos simulados consistentes** que demuestre la lógica del negocio.

## 2. Arquitectura de información y navegación

**Navegación principal desktop:** barra lateral compacta con `Inicio`, `Descubrir`, `Mi portfolio`, `Actividad`, `Mi perfil`; cabecera con búsqueda universal, notificaciones y avatar. La pantalla Descubrir ofrece dos entradas de igual importancia: **Para ti** y **Explorar mapa**. Evitar multiplicar pestañas secundarias sin propósito.

**Navegación móvil:** barra inferior con `Inicio`, `Descubrir`, `Portfolio` y `Perfil`; `Actividad` accesible desde una campana en la cabecera. Al entrar en Descubrir usar un selector muy visible `Para ti | Mapa`. Las operaciones concretas se abren desde tesis y portfolio; no deben confundirse con las recomendaciones iniciales.

**Rutas conceptuales:**

- `/welcome` → acceso/registro y promesa de producto.
- `/onboarding` → perfil de inversor en varios pasos.
- `/home` → resumen personalizado, tesis sugeridas y actividad pendiente.
- `/discover/recommended` → oportunidades recomendadas según perfil.
- `/discover/map` → mapa multicapa de España y búsqueda libre.
- `/thesis/:id` → **ficha maestra y única** de tesis, independientemente de la puerta de entrada.
- `/operations/:id` → operación concreta con ficha financiera y de ejecución.
- `/portfolio` → sección dual de inversiones reales y oportunidades que sigo.
- `/investments/:id` → detalle del seguimiento de una inversión efectiva.
- `/activity` → cronología/notificaciones y acciones pendientes.
- `/profile` → perfil y preferencias editables.

En la demo todas estas rutas deben funcionar, incluso si la información se mantiene en memoria/local state y no hay backend real.

## 3. Dirección visual: sofisticación tipo Atlan, producto financiero de consumo

### 3.1 Personalidad visual

**Alta calidad, limpia, editorial, luminosa, moderna y creíble.** Tomar de Atlan la claridad, aire, tipografía, jerarquía y refinamiento de sus experiencias de datos, sin copiar su identidad gráfica, logotipo ni componentes propietarios. Combinar confianza de fintech con atractivo aspiracional de real estate.

- **Base:** fondos claros (`#F7F9FC`), superficies blancas, texto azul tinta/carbón (`#172337`), bordes tenues (`#E5EAF1`).
- **Acento de marca provisional:** azul petróleo / índigo (`#385CF6` o `#285D75`); acento complementario turquesa moderado (`#18A7A2`) para exploración. Son sugerencias, no branding cerrado.
- **Semántica:** verde tenue para hitos completados; ámbar para acciones pendientes; rojo reservado a riesgos/pérdidas reales. No hacer que todo parezca una app de trading especulativo.
- **Tipografía:** sans profesional, por ejemplo Inter, Manrope o Geist, con cifras alineadas/tabulares y títulos nítidos.
- **Composición:** mucho espacio en blanco; estructuras editoriales y tablas cuando ayuden; tarjetas selectivas, no «cajas por todas partes»; esquinas moderadas, sombras muy suaves.
- **Fotografía:** fotos inmobiliarias de excelente calidad y recortes consistentes; mapas con detalle; pequeños favicon/iconos de Idealista y Fotocasa junto al nombre de la fuente, respetando sus marcas.
- **Visualizaciones:** líneas finas y precisas, tooltips con fuentes y fechas, nada de curvas artificiales, gradientes estridentes ni métricas infladas.

### 3.2 Sistema de componentes

Crear componentes coherentes y reutilizables: `ThesisCard`, `OpportunityScore`, `MetricPill`, `WhyThisArea`, `SourceBadge`, `PropertyListingRow`, `MapLayerSelector`, `MapResultPanel`, `InvestorInterestMeter`, `FundingProgress`, `OpportunityStage`, `InvestmentStatusTimeline`, `ValuationChart`, `InvestmentSummary`, `ScenarioTable`, `ActivityItem`, `ActionRequiredBanner`, `RiskDisclosure`.

**Estados de diseño obligatorios:** vacío, cargando, sin resultados, interés registrado, acción requerida, operación sin disponibilidad, operación cancelada, inversión en curso, inversión finalizada, datos no disponibles, error recuperable.

**Accesibilidad:** contraste razonable, navegación con teclado, texto alternativo, focos visibles, controles táctiles de al menos ~44 px, no depender solo del color para identificar estados. Respetar reducción de movimiento. Animaciones cortas y discretas.

## 4. Onboarding: registro, perfil e intereses

### 4.1 Primera experiencia

Pantalla de bienvenida con una promesa corta, imagen inmobiliaria editorial, botón `Crear cuenta` y vínculo `Ya tengo cuenta`. En un prototipo la autenticación es simulada pero el flujo debe sentirse real: correo, contraseña o acceso social como opción visual, verificación simulada y consentimiento informativo.

### 4.2 Cuestionario progresivo, 5 pasos

**Paso 1 — Objetivo y experiencia:** ¿qué buscas (crecimiento de capital, diversificación, conocer oportunidades)? Nivel de experiencia inmobiliaria y con inversiones.  
**Paso 2 — Capacidad y ticket:** rango orientativo de ingresos anuales, capital que estaría dispuesto a destinar, ticket preferido por operación (p. ej. 2.500 €, 5.000 €, 10.000 €, 25.000 €), frecuencia prevista.  
**Paso 3 — Riesgo y horizonte:** tolerancia a pérdidas, preferencia por prudencia/equilibrio/mayor riesgo, posibilidad de inmovilizar dinero (6–12, 12–18, 18–36+ meses).  
**Paso 4 — Localización y estrategia:** comunidades, ciudades o barrios preferidos; permitir `Toda España`; preferencia entre compraventa directa, reforma y venta, cambio de uso o promociones (algunas marcadas `próximamente`).  
**Paso 5 — Revisión y resultado:** resumen de respuestas, perfil descriptivo y explicación de qué influye en recomendaciones, botón `Ver mis oportunidades`.

No pedir datos sensibles innecesarios para la simple exploración. **Distinguir perfil de recomendación de la documentación KYC/AML, idoneidad u otros requisitos legales**, cuyo alcance real está pendiente de definición. Evitar que una autocalificación de riesgo se presente como asesoramiento financiero autorizado.

### 4.3 Perfil vivo

El usuario puede editar preferencias. El sistema puede aprender de sus búsquedas, tesis guardadas, ubicaciones consultadas e importes indicativos, con transparencia y control del usuario. Mostrar `Por qué ves esta recomendación` y `Ajustar preferencias`.

## 5. Inicio: home personalizado

La home no debe duplicar todo el Discovery. Debe responder en 5 segundos a «¿qué me conviene mirar hoy y qué tengo pendiente?».

**Composición desktop:** bienvenida humana + pequeña síntesis; hero «Oportunidades seleccionadas para ti» con 2–3 tesis relevantes; sección «Actividad que requiere tu atención» (por ejemplo, una vivienda concreta que encaja con una tesis guardada); previsualización de portfolio con capital realmente invertido, si existe; artículo breve «Cómo funciona».  
**Composición móvil:** bienvenida, una recomendación destacada, carrusel de tesis, acción pendiente y extracto del portfolio.

Un usuario sin inversiones reales verá una experiencia inspiradora, no una cartera ficticiamente rellena. Usar `Aún no has invertido` y `Explorar oportunidades`.

## 6. Descubrir: dos caminos equivalentes, un mismo destino

**Esta es una decisión esencial del producto y no debe simplificarse.** Ambos modos terminan en **exactamente la misma ficha de tesis**. Nunca diseñar una ficha diferente para los resultados del mapa.

### 6.1 Modo A: «Para ti» — descubrimiento guiado por el perfil

Pantalla con título `Oportunidades para ti`, texto breve `Seleccionadas según tus objetivos, preferencias y señales de mercado`, chips de filtros (`Localización`, `Estrategia`, `Ticket`, `Horizonte`, `Riesgo`) y selector de orden (`Mejor encaje`, `Interés`, `Plazo`).

Mostrar entre 6 y 8 tarjetas de tesis. Cada tarjeta contiene:

- Fotografía atractiva de la tipología + nombre de **barrio/microzona** y ciudad, nunca solo la provincia o ciudad.
- Tesis concreta: «Pisos de 2 dormitorios para reformar · Patraix, València».
- Etiqueta de estrategia; rango aproximado de compra por inmueble; inversión mínima orientativa, si aplica al caso.
- Estimación de duración **por escenario**, sin garantía; rentabilidad estimada solo si existe un modelo financiero coherente y con advertencia.
- Dos puntuaciones distintas: **Atractivo de la oportunidad** y **Encaje con tu perfil**; explicar que son indicadores de apoyo, no promesas.
- 2–3 razones visibles del modelo (`Demanda residencial sostenida`, `Diferencial entre estado actual y reformado`, `Rotación de anuncios observada`) con una fecha de actualización.
- Contador social bien etiquetado: `40 personas interesadas`, nunca `40 inversores` si no han invertido.
- CTA `Explorar tesis` y acción secundaria `Guardar`.

Permitir cambiar perfil o explorar mapa sin perder estado.

### 6.2 Modo B: «Explorar mapa» — descubrimiento autónomo

**Abrir un mapa interactivo de España**. La persona elige adónde ir y puede cambiar filtros sin depender de las recomendaciones del sistema. El mapa debe funcionar como una herramienta real de inteligencia territorial, no como una ilustración.

**Jerarquía geográfica progresiva:**

1. **España**: mapa nacional con indicadores o clusters de zonas donde hay tesis disponibles; resumen por grandes áreas/ciudades y recuento de tesis.
2. **Región / provincia / municipio**: al acercarse o seleccionar un área, aparecen comparativas territoriales y principales áreas con tesis; no mostrar miles de marcadores a la vez.
3. **Barrio / microzona**: límites o polígonos legibles, métrica territorial principal (seleccionable) y burbujas de tesis.
4. **Segmento de inversión dentro de la microzona**: oportunidad específica por tipología y estrategia, por ejemplo «2 dormitorios · 65–85 m² · reforma y venta». Aquí clicar abre `/thesis/:id`.

El usuario debe poder alternar **capas de información** tales como: atractivo agregado, €/m² anunciado, tendencia de precios, presión de demanda, liquidez aproximada y presencia de tesis. Si faltan datos, mostrar `Sin datos suficientes`, nunca colorear aleatoriamente. Los límites y escalas de color deben tener leyenda y fechas. En demo, métricas y polígonos pueden ser simulados y **etiquetados como demo**.

**Desktop:** mapa ocupa ~65–70 % y panel lateral persistente ~30–35 % con búsqueda por dirección/barrio, filtros, zona seleccionada, lista de tesis y contador de resultados. Hover muestra tooltip; clic fija selección; doble clic o zoom pasa a nivel inferior; «Volver a España» visible.  
**Móvil:** mapa a pantalla completa, búsqueda flotante, chips desplazables de capas y botón `Ver X oportunidades` que levanta un bottom sheet con lista; tarjeta seleccionada se abre como hoja intermedia, y la ficha completa ocupa pantalla propia. Gestos de pellizco y arrastre; botón claro de volver al mapa. Evitar paneles laterales encogidos.

**Conexión obligatoria:** desde cualquier pin, cluster, fila o tarjeta de mapa, `Explorar tesis` lleva a la **misma** ficha que Modo A. La ficha conserva breadcrumbs/contexto y ofrece volver al mapa o a recomendaciones según origen.

### 6.3 Una capa que explique, no solo coloree

Al elegir una zona, mostrar un panel `¿Por qué destaca esta zona?` con señales explicadas, fuentes y fecha: población/hogares, demanda, oferta, precios, empleo, proyectos locales, tiempo comercial estimado y confianza/calidad del dato. No usar frases de IA vagas («zona emergente») sin evidencia concreta. Distinguir señales medibles, hipótesis interpretativas y riesgos.

## 7. Ficha de tesis: la pantalla más importante de Discovery

Ruta única `/thesis/:id`. Debe sentirse como la combinación entre un informe inmobiliario de alto nivel y una ficha de compra impecable. **Es la misma ficha desde recomendaciones y desde mapa**.

### 7.1 Cabecera / zona hero

Nombre exacto de tesis, barrio + ciudad, tipo de activo, estrategia, imagen destacada, chips de estado (`Captando interés`, `Operaciones identificadas`, etc.), guardado y compartir. Resumen en una frase que explique la oportunidad.

En un bloque lateral/sticky mostrar: rango de coste total estimado por operación, inversión mínima orientativa, plazo orientativo, resumen de riesgo y CTA principal `Me interesa esta tesis` (no `Invertir ahora` si no existe operación concreta). Mostrar `40 personas interesadas` y capital **indicativo** agregado con explicación visible.

### 7.2 «Por qué esta zona» — explicación verdaderamente profunda

Sección diferencial, extensa y visual, con:

- **Tesis de inversión en lenguaje natural** (2–4 párrafos): qué anomalía, ventaja o diferencia observa el modelo y por qué podría existir margen tras compra y mejora.
- **Indicadores del mercado** con unidad, fuente y fecha: precio de oferta €/m², evolución 12/36 meses, número de anuncios comparables, dinámica de demanda, tiempo de publicación o proxy de liquidez, evolución de hogares, empleo, nuevos desarrollos y distancia a equipamientos/transporte cuando haya datos fiables.
- **Comparación** de microzona frente a municipio/provincia y tendencia histórica, sin insinuar causalidad donde solo hay correlación.
- **Factores de oportunidad** y **factores de riesgo** presentados simétricamente; incertidumbres explícitas.
- **Metodología desplegable**: qué significa cada score, peso aproximado de variables, qué datos son estimados, últimos refrescos, calidad/cobertura. No fingir «IA infalible».
- Mini-mapa del barrio con límite territorial aproximado y puntos indicativos, no exponer direcciones privadas cuando proceda.

### 7.3 Economía de una operación tipo

Mostrar un **modelo ilustrativo**, no una cotización contractual: compra con tributos/costes iniciales, reforma, contingencia, honorarios, gastos de mantenimiento, gastos de venta, financiación si aplica, impuestos societarios o personales según estructura final, inversión agregada, venta objetivo, escenarios pesimista/base/optimista, plazo y rentabilidad estimada para un ticket seleccionado. No mezclar rentabilidad bruta del inmueble con rentabilidad neta del inversor.

Ejemplo estrictamente matemático para demo: `Coste total 100.000 €` y `venta objetivo 120.000 €` implican `20.000 € de margen antes de otros costes de salida, comisiones e impuestos sobre el resultado`. **No** mostrar que una participación de 10.000 € genera automáticamente 12.000 € netos: falta definir costes, impuestos, fees y derechos del inversor. Los valores deben recalcularse cuando cambie el ticket, y las hipótesis deben estar a la vista.

### 7.4 «Viviendas que encajan con esta tesis» — requisito visual fundamental

Listado de **inmuebles individuales** que cumplen los criterios de barrio, superficie, antigüedad, tipología, coste y estrategia. Cada inmueble muestra fotografía (si existe licencia), dirección aproximada/barrio, m², dormitorios, precio anunciado, €/m², estado de reforma, fecha de actualización y estado (`Anuncio externo`, `En evaluación`, `Operación abierta`, `Descartada`).

**Fuentes externas:** al lado de cada anuncio, mostrar un icono/favicón pequeño y bonito, más el nombre `Idealista` o `Fotocasa`, enlazando **a la URL del anuncio específico si fue verificada y está disponible**. Si el enlace no está verificado en la demo, usar etiqueta `Enlace de ejemplo / no disponible` sin inventar una URL de anuncio. Estas viviendas son ejemplos o candidatas; aclarar cuáles no están adquiridas ni reservadas por la empresa.

Permitir pestañas `Todas`, `En evaluación`, `Financiación abierta`; orden por precio, €/m² o actualización. Clicar un candidato sin operación abre un panel informativo; clicar una operación aprobada abre `/operations/:id`.

### 7.5 Interés de la comunidad y actividad real

- Contador `40 personas han mostrado interés`.
- `Capital potencial indicado: 280.000 €` (no disponible ni comprometido).
- `Operaciones identificadas: 3`, `Operaciones con captación abierta: 1` (son contadores diferentes).
- Pequeña visualización tipo funnel, útil y sin gamificación de casino.
- Acción `Quiero seguir esta tesis` y modal para indicar importe **orientativo** (ej.: 5.000 €, 10.000 €, 25.000 € o personalizado) y recibir avisos. Confirmación inequívoca: `Has registrado tu interés. No se ha cargado dinero ni asumido un compromiso contractual.`

## 8. Flujo de negocio: del interés a la operación

Es fundamental que el producto permita muchos interesados por tesis, que una tesis origine **varias operaciones**, y que solo algunos interesados se conviertan en inversores reales.

```text
Descubre una tesis (recomendación o mapa)
           ↓
Lee ficha, viviendas candidatas y datos
           ↓
Guarda tesis / registra interés e importe orientativo
           ↓
La plataforma identifica y valida una o varias viviendas
           ↓
Se publica una operación concreta, con sus términos
           ↓
El interesado recibe aviso → revisa operación
           ↓
Confirma intención de participar
           ↓
Verificaciones, documentación, formalización y transferencia
           ↓
Posición efectiva en «Mis inversiones»
           ↓
Compra → reforma → comercialización → venta → liquidación
```

**Estados conceptuales y significado (mock):**

| Etapa | Estado UX | ¿Hay dinero invertido? | Acción esperada |
|---|---|---|---|
| Tesis | Siguiendo | No | Mantener interés o salir |
| Tesis | Candidatas identificadas | No | Ver inmuebles |
| Operación | Disponible para revisar | No | Examinar términos |
| Operación | Intención confirmada | No necesariamente | Completar pasos posteriores |
| Operación | Documentación pendiente | Según estructura final | Verificar datos / firmar |
| Inversión | Formalizada / financiación recibida | Sí, una vez confirmada | Consultar posición |
| Inversión | Compra pendiente / formalizada | Sí | Seguir hitos |
| Inversión | Reforma / comercialización / vendida | Sí | Seguir resultados |
| Inversión | Liquidación pendiente / transferida | Según etapa | Ver cierre y efectivo abonado |

El momento exacto del compromiso vinculante, la custodia del dinero, la captación de fondos y la titularidad deben fijarse **tras asesoramiento jurídico y regulatorio español**. La demo permite recorrer pantallas, pero **no debe cobrar dinero real ni presentar contratos inventados como válidos**.

## 9. Ficha de operación concreta

Diferenciarla visualmente de una tesis. Ahora sí existe inmueble/proyecto específico, dossier verificable y escenario financiero por operación. Incluir:

- Fotografía, localización, inmueble real o demo claramente marcado, características, documentación disponible y estrategia.
- Presupuesto desglosado (compra, impuestos de adquisición, reforma, contingencia, honorarios, coste de venta, otros) y necesidad total de financiación.
- Importe solicitado, capital **efectivamente comprometido/confirmado** según estado, progreso de captación, mínimo y máximo de aportación, fechas e información sobre cuándo se libera/custodia.
- Retorno **objetivo no garantizado** y tres escenarios, horizonte y posibles retrasos; distinguir ROI de rentabilidad anualizada.
- Explicación de honorarios de la plataforma y riesgos principales, incluidos pérdida de capital e iliquidez.
- Botón `Quiero participar` que lleva a un flujo de revisión de inversión. Si el usuario llegó desde una tesis, conservar el vínculo y permitir volver.

**Modal de participación simulado:** elegir ticket, comparar escenarios y costes estimados, confirmar que entiende la falta de garantías, pasos de verificación y firma como pantallas de demostración, estado de confirmación. Simular posible abandono o rechazo y permitir reintentar. Nunca afirmar que se ha debitado una cuenta bancaria real.

## 10. Mi portfolio — UNA pantalla con DOS universos separados

El portfolio es el centro de retorno recurrente del usuario. **No mezclar los importes de interés con dinero invertido.** Orden recomendado: primero `Mis inversiones`; debajo `Oportunidades que sigo`.

### 10.1 Cabecera de cartera

Mostrar, para usuarios con inversión efectiva: **capital aportado**, **valor estimado de posiciones**, **resultado realizado**, **resultado no realizado estimado**, **efectivo liquidado** (si corresponde) y gráfico temporal de valoración. Tooltip con metodología y fecha de estimación. Si no existe mercado secundario, evitar visuales que insinúen venta instantánea o cotización continua. Filtros 1M / 3M / 1A / Todo solo si hay series temporales consistentes; en demo, fechas simuladas.

La línea de valoración debe distinguir cambios por hitos (ej., reforma completada) de cambios debidos a estimaciones de mercado; si faltan tasaciones, mostrar un tramo plano o `Sin actualización` y explicar por qué. **No aplicar automáticamente un +10 % por reformar:** solo cuando exista método y evidencia. Comparación opcional contra precio €/m² de la zona, con series en eje aparte o claramente separadas.

### 10.2 Sección A — Mis inversiones

Tarjetas o tabla con inmueble/operación, importe desembolsado, valoración estimada, beneficio/pérdida realizada si aplica, retorno estimado con carácter no garantizado, fecha de actualización y `Estado`:

1. Documentación/firma en curso (solo si ya hay una posición jurídicamente clasificable como inversión; si no, en seguimiento de operación).
2. Financiación confirmada / pendiente de adquisición.
3. Adquisición formalizada.
4. Proyecto en preparación.
5. Reforma en curso.
6. Reforma terminada.
7. En comercialización.
8. Oferta aceptada / compraventa pendiente de firma.
9. Venta formalizada.
10. Liquidación y transferencia en proceso.
11. Capital y resultado abonados / operación finalizada.

Al abrir una inversión, mostrar una **línea de tiempo** con hitos, fechas previstas/reales, evidencia/documentos, fotos «antes / durante / después», noticias, incidencias, posible desviación presupuestaria, estimación financiera y detalle del reparto final. Estado `Retrasada` o `Incidencia` visible cuando corresponda.

### 10.3 Sección B — Oportunidades que sigo

Listado de tesis donde mostró interés, con nombre y barrio, **importe orientativo (no invertido)**, interesados totales, candidato(s) asociados, operaciones que ya captan financiación, progreso real de cada captación, último cambio y botón `Ver oportunidades`.

Si en una tesis hay tres inmuebles, uno puede estar en evaluación, otro captando capital y otro descartado. El seguimiento debe reflejarlo, no mover toda la tesis de estado como si fuera un único activo. Las operaciones en las que ha confirmado intención pero no ha completado formalización pueden figurar como `Acción pendiente` en esta sección, con mensaje claro.

**Regla de transición:** cuando el usuario formaliza una inversión en un inmueble, aparece una posición nueva en `Mis inversiones`. La tesis puede **seguir** en `Oportunidades que sigo` si desea recibir otras propuestas relacionadas; no debe desaparecer automáticamente si sigue teniendo valor de seguimiento.

### 10.4 Ejemplo de composición responsive

**Desktop:** en cabecera 3–4 KPIs y gráfico amplio; debajo sección inversiones en tabla elegante/tarjetas horizontales; separador editorial; sección oportunidades con cards de tesis y progreso de cada operación.  
**Móvil:** resumen de cartera en columna, gráfico deslizable y métricas en 2 columnas; inversiones como cards verticales expandibles; bloque posterior de tesis seguidas, con CTA para regresar a Discovery. Priorizar `Qué tengo`, `Cómo va`, `Qué requiere mi acción`.

## 11. Notificaciones, actividad y confianza

La sección Actividad es una cronología de hechos, no solo mensajes de marketing. Categorías: `Nueva vivienda compatible`, `Operación publicada`, `Financiación actualizada`, `Documentación pendiente`, `Compra formalizada`, `Reforma completada`, `Precio de venta revisado`, `Oferta recibida`, `Venta cerrada`, `Transferencia realizada`, `Retraso/incidencia`.

Cada notificación tiene fecha, entidad asociada, tipo, contexto y CTA. Se deben poder distinguir eventos confirmados de hipótesis o simulaciones del modelo. Ajustes para preferencias de notificaciones. No diseñar FOMO artificial, cuenta atrás falsa ni contadores inventados presentados como reales.

## 12. Datos, inteligencia y lógica de recomendación (versión demo)

La arquitectura futura combina fuentes públicas y comerciales sujetas a licencias: INE, Catastro, indicadores oficiales de empleo, vivienda y licencias, anuncios/cifras contractualmente reutilizables de portales y señales de noticias/proyectos. La V1 del prototipo puede usar un **dataset mock enriquecido**. No se requiere scraping real.

**Score de atractivo de tesis (conceptual, no calibrado):** demanda/suministro, variación de precios, liquidez, margen estimado tras reforma, riesgo operativo y confianza de datos.  
**Score de encaje usuario–tesis (conceptual):** ticket, horizonte, tolerancia al riesgo, ubicaciones preferidas y estrategias.  
Mostrar ambos por separado; no formular asesoramiento financiero automatizado sin validación legal. Para cada score, mostrar variables y justificación en lenguaje natural.

**Cadencia de datos:** indicar `Actualizado [fecha]`, fuente y limitaciones. Distinguir precios anunciados frente a transacciones cerradas, tendencias frente a predicciones y poblaciones frente a hogares. No afirmar que un anuncio equivale a disponibilidad para compra. Un motor interno para responsables de operaciones puede revisarse en fases futuras; para la demo se puede disponer de una vista simple de administración con creación de tesis y vinculación de inmuebles, no es la pantalla principal.

## 13. Datos de demostración: Murcia y Albacete, más una tesis en València

Estas localizaciones son reales, pero **todas las cifras, eventos, puntuaciones, imágenes y operaciones específicas propuestas abajo son ficticias, creadas únicamente para mostrar la experiencia**. No se han contrastado precios ni anuncios actuales. El prototipo debe mostrar una etiqueta discreta `Datos de demostración` en las áreas que empleen estos ejemplos.

| ID | Tesis demo | Estrategia | Coste total típico ficticio | Plazo ejemplo | Interesados ejemplo | Capital potencial ejemplo |
|---|---|---|---:|---|---:|---:|
| T-01 | **La Flota, Murcia** · pisos de 2 hab. y 65–85 m² | Compra, reforma y venta | 132.000 € | 10–15 meses | 46 | 365.000 € |
| T-02 | **El Carmen, Murcia** · viviendas compactas para actualización | Reforma y venta | 108.000 € | 12–18 meses | 32 | 225.000 € |
| T-03 | **Centro, Albacete** · pisos de 2–3 hab. con mejora de acabados | Reforma y venta | 126.000 € | 10–16 meses | 38 | 310.000 € |
| T-04 | **Ensanche, Albacete** · pisos familiares de 80–105 m² | Compraventa y mejora selectiva | 154.000 € | 12–18 meses | 24 | 215.000 € |
| T-05 | **Patraix, València** · 2 dormitorios de 60–85 m² | Compra, reforma y venta | 173.000 € | 12–18 meses | 40 | 280.000 € |

Para T-01, simular tres inmuebles vinculados: `M-101` candidato en evaluación, `M-102` operación captando financiación y `M-103` descartado. Para T-03, simular dos inmuebles: `A-201` anuncio de origen Idealista y `A-202` anuncio de origen Fotocasa. **No crear enlaces URL de anuncio inventados**; si la IA necesita un clic en la demo, abrir un modal con la imagen, los datos sintéticos y la nota `Enlace a anuncio pendiente de verificación`; los iconos de las fuentes sí deben estar visibles.

**Operación demo O-102** (asociada a La Flota): presupuesto total ficticio 132.000 €, compromiso confirmado ficticio 79.200 € (60 %), 8 compromisos confirmados, venta objetivo hipotética 155.000 € antes de calcular fees/gastos finales e impuestos del beneficio. Ejemplo de ticket de usuario 10.000 €, pero no inferir la ganancia neta hasta incluir todas las partidas y derechos. Otra operación O-201 puede estar ya `En reforma` con fechas y avance simulados.

**Dos perfiles demo:** `Marina — moderada`, prefiere Murcia/Albacete, 5.000–10.000 €, horizonte 12–18 meses; `Álex — diversificación`, 10.000–25.000 €, toda España, horizonte 18–24 meses. Las recomendaciones difieren al alternar perfiles. No afirmar que los ingresos personales determinan automáticamente idoneidad regulatoria.

### 13.1 Prueba concreta de coherencia en la demo

- Marina abre `Para ti` y ve T-01/T-03 con alta compatibilidad.
- Marina cambia a `Mapa`, selecciona Murcia → La Flota → la tesis T-01.
- **La ficha T-01 es idéntica** a la ficha abierta desde `Para ti` (salvo breadcrumb/volver).
- Marina marca `Me interesa`, indica 10.000 € y ve la tesis en `Oportunidades que sigo`.
- Desde T-01 descubre operación O-102 con barra real de compromisos **simulados**.
- Marina confirma intención para O-102; ve `Pendiente de formalización` sin falsear dinero invertido.
- En un modo de demo, `Simular formalización` crea la posición en `Mis inversiones` y activa el timeline.
- Al avanzar hitos con un control de demo, la línea temporal y el gráfico de valor estimado se actualizan de forma consistente, marcando las valoraciones como simuladas.

## 14. Especificación desktop y móvil por pantalla

| Pantalla | Desktop (>= 1024 px) | Móvil (<= 767 px) |
|---|---|---|
| Bienvenida | Hero editorial, imagen lateral, CTA | Imagen reducida, mensaje y CTA prominente |
| Onboarding | Panel centrado, progreso lateral, preguntas aireadas | Un paso por vista, progreso superior y CTA fijo abajo |
| Inicio | 2 columnas con recomendaciones y actividad | Feed vertical con cards y carruseles táctiles |
| Recomendadas | Grid de 2–3 tarjetas, filtros visibles | Una tarjeta principal por fila, filtros como bottom sheet |
| Mapa | Mapa 65–70 % + panel 30–35 %, leyenda lateral | Mapa full-screen + chips + bottom sheet de resultados |
| Ficha de tesis | Hero, contenido editorial 2/3 + panel sticky 1/3 | Hero apilado + CTA inferior fijo, secciones acordeón donde proceda |
| Listado viviendas | Tabla/cards con datos y badge de fuente | Cards verticales compactas, fuente con favicon legible |
| Ficha operación | Dossier 2 columnas, sidebar financiero | Secciones verticales, simulador y CTA anclados |
| Portfolio | KPIs + gráfica + tablas y cards | Gráfica responsive, cards y 2 secciones claramente separadas |
| Detalle inversión | Gráfica + timeline + documentos en dos columnas | Gráfica + timeline vertical + fotos y documentos deslizables |
| Actividad | Lista cronológica con filtros | Feed cronológico, enlaces de acción grandes |
| Perfil | Menú lateral de preferencias | Pantallas apiladas, edición por secciones |

**Breakpoints intermedios:** 768–1023 px, layout tablet con menos columnas. No simplemente escalar tipografías: reorganizar navegación, interacciones y densidad. Soportar al menos 390 px y 1440 px como referencias de QA.

## 15. Interacción real del prototipo y criterios de aceptación

Se exige interacción funcional de extremo a extremo, aunque los datos sean locales:

1. El onboarding modifica efectivamente las recomendaciones.
2. `Para ti` y `Mapa` se pueden alternar; los filtros funcionan y el mapa permite selección jerárquica.
3. El mapa soporta zoom/cambio de nivel, resultados y navegación a tesis.
4. Cualquier ruta hacia una tesis desemboca en la misma pantalla/componente y los mismos datos.
5. Los iconos de Idealista/Fotocasa aparecen junto a las viviendas; enlaces solo si válidos o modal informativo demo.
6. El usuario puede guardar/quitar tesis, expresar interés y modificar importe; el contador puede actualizarse **en modo demo** sin insinuar que hay nuevos usuarios reales.
7. Una tesis puede contener múltiples operaciones con estados diferentes.
8. Las barras de interés potencial y de capital formalizado son independientes y tienen leyendas inequívocas.
9. `Quiero participar` abre pasos de lectura, confirmación y estado sin procesar dinero real.
10. El portfolio muestra **únicamente posiciones formalizadas** en el agregado monetario.
11. El historial de inversión cambia al accionar el simulador de hitos demo; las valoraciones y retornos se etiquetan como estimados.
12. Existe estado vacío, loading y error en las principales vistas.
13. Móvil y desktop poseen navegación e interacciones adaptadas; mapa y fichas usables a 390 px.
14. Fechas, cifras y fuentes son consistentes a través de tarjetas, fichas, mapa y portfolio.
15. No hay garantías de rentabilidad, fecha de liquidación o disponibilidad inmediata del capital.

## 16. Qué está decidido y qué queda abierto

### Decisiones tomadas para el prototipo

- Propuesta de inversión inmobiliaria en España, con ejecución integral por la compañía y proveedores.
- Discovery doble: personalización y mapa exploratorio multicapa de España.
- Tesis por microzona + tipología + estrategia como unidad de descubrimiento.
- Ficha de tesis profunda, explicativa, con métricas, riesgos y anuncios candidatos con iconos de fuente.
- Interés y capital potencial separados de compromiso efectivo.
- Una tesis puede alimentar varias operaciones y varios inversores.
- Portfolio unificado con secciones **Mis inversiones** y **Oportunidades que sigo**.
- Timeline operacional, actualizaciones y evolución de valoración claramente estimada.
- Diseño nativo para desktop y móvil desde el inicio.

### Decisiones todavía no tomadas (NO inventarlas en la demo)

- Estructura de propiedad y participación: copropiedad, sociedad vehículo, préstamo o tercero regulado.
- Impuestos y comisiones finales, forma de cobrar, retorno neto por perfil fiscal.
- Momento legal exacto en que se acepta dinero, términos vinculantes y custodia.
- KYC/AML, idoneidad, permisos/regulación CNMV y documentos definitivos.
- Tickets mínimos comerciales y política de cancelación/reembolso.
- Disponibilidad/licencias de APIs de portales, datos, mapas y fotos.
- Fórmula calibrada del scoring y fuentes suficientes para predicciones reales.
- Duraciones y retornos por estrategia (el documento de negocio menciona típicamente 12–18 meses en operaciones sencillas; plazos más cortos fueron solo hipótesis de ideación).

Para la demo, utilizar supuestos claramente identificados y una pantalla `Cómo funciona` que explique que el prototipo no admite inversión real. No convertir hipótesis en compromisos del negocio.

## 17. Instrucción final lista para la IA que construye la web

> **Construye una V1 navegable y responsive (desktop y móvil) de una plataforma española de inversión inmobiliaria con lenguaje visual premium inspirado en la claridad de Atlan y la sencillez de Robinhood/Trade Republic, sin copiar sus marcas.** Debe demostrar todo el flujo: onboarding con perfil de inversión → home → Discovery por recomendaciones personalizadas → Discovery autónomo mediante mapa multicapa de España (país → provincia/ciudad → barrio → tesis por tipología) → ficha ÚNICA de tesis con explicación profunda de datos, razones, riesgos y viviendas individuales con iconos de Idealista/Fotocasa → manifestación de interés sin desembolso → aparición de una o varias operaciones inmobiliarias concretas → simulación de formalización → portfolio con dos secciones claramente separadas (inversiones efectivas y tesis que sigo) → detalle de inversión con gráfica de valoración estimada y timeline de hitos hasta venta y liquidación.
>
> Implementa rutas, navegación, filtros, mapa, botones, modales, progreso de financiación, cambios de estado, gráfica, timeline, perfiles demo y acciones consistentes. El mapa desktop debe ocupar la mayor parte del espacio con panel de resultados lateral, mientras en móvil debe ser full-screen con bottom sheet. Diseña ambos formatos deliberadamente, no solo CSS reducido.
>
> Usa un sistema visual ligero, tipografía excelente, mucho aire, fotografía inmobiliaria, microinteracciones sutiles y componentes reutilizables. Prepara datasets **sintéticos y etiquetados** para tesis en La Flota y El Carmen (Murcia), Centro y Ensanche (Albacete), y Patraix (València). Ninguna cifra demo debe presentarse como dato actual confirmado; no inventes enlaces de anuncios. Para listados candidatos sí muestra iconos pequeños de los portales y, cuando no haya URL verificada, un modal de demo. Nunca sumes interés potencial al capital invertido. No muestres rendimientos netos garantizados ni funciones legales o bancarias reales. Prioriza una experiencia convincente, coherente, elegante y utilizable.

---

## Anexo A. Ejemplos de copy UX y microcopy

- Recomendaciones: **«Estas zonas encajan contigo»** · Subtexto: «Seleccionadas según tus preferencias y señales inmobiliarias. Explora también cualquier zona de España».
- Discovery libre: **«Explora España, barrio a barrio»** · Subtexto: «Cambia las capas, compara microzonas y encuentra estrategias que te interesen».
- Ficha de tesis: **«Por qué estamos siguiendo esta zona»** · Enlace: `Ver fuentes y metodología`.
- Indicador social: **«40 personas interesadas»** · Tooltip: «Personas que han indicado interés en esta tesis. No equivale a capital comprometido».
- Modal interés: **«¿Cuánto considerarías invertir?»** · Mensaje final: «Te avisaremos cuando haya una operación concreta. No se ha realizado ningún cargo».
- Captación: **«60 % de financiación confirmada»** · Tooltip: «Compromisos verificados para esta operación. No incluye interés indicativo».
- Portfolio: **«Tu dinero, con contexto»** · Subtítulo: «Distingue posiciones efectivas de oportunidades que estás siguiendo».
- Valoración: **«Valor estimado, no disponible para retirada»** · Enlace: `Cómo lo calculamos`.
- Estado: **«Reforma en curso»**, **«En comercialización»**, **«Venta formalizada»**, **«Transferencia en proceso»**.

## Anexo B. Preguntas de validación para José Carlos y Juanpe

1. ¿Una tesis admite varios inmuebles simultáneos y una inversión por inmueble, o también financiación agrupada sobre una cartera? Para V1 se diseña **una inversión por operación concreta**, manteniendo la tesis como funnel común.
2. ¿Qué grado de transparencia sobre inmuebles candidatos queréis antes de asegurar su captación? Esos anuncios pueden desaparecer o cambiar.
3. ¿Cuál será el ticket mínimo real y los segmentos de inversor elegibles?
4. ¿Se promete una política de selección dentro de ciertos criterios de tesis o cada inversor debe ratificar el activo concreto? Definirlo legalmente.
5. ¿Quién valida la valoración y con qué periodicidad cuando no hay venta ni tasación reciente?
6. ¿Qué métricas internas permiten medir conversión: vista de tesis → interés → revisión de operación → compromiso → formalización?
7. ¿Qué alcance del motor territorial y de la red operativa es necesario en el piloto?
8. ¿Quién gestiona la regulación/captación, cómo se custodia el dinero y cuál es el tratamiento fiscal según la estructura escogida?

**Base documental:** «Proyecto RealInv — Visión Estratégica», 18/10/2026, aportado por los fundadores, combinado con las decisiones y matices expresados en la conversación. Los elementos de UX, ejemplos y especificaciones son propuestas de diseño para un prototipo, no hechos verificados de mercado ni asesoramiento jurídico o financiero.
