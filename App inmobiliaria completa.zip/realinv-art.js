/* RealInv — ilustraciones geométricas deterministas para sustituir fotos. <ri-art seed="..." label="..."> */
(function () {
  if (customElements.get('ri-art')) return;
  const hash = s => { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; };
  const rng = seed => () => { seed = (seed + 0x6D2B79F5) | 0; let t = Math.imul(seed ^ (seed >>> 15), 1 | seed); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  const THEMES = [
    { bg: '#f3f5f7', far: '#e8ecef', b: ['#dfe4e8', '#e9f7f7', '#d6dbe0'], win: '#c9d0d6', lit: '#b4ebeb', sun: '#ffffff' },
    { bg: '#eef8f8', far: '#e1f1f1', b: ['#d3e9ea', '#f4f6f8', '#c7dfe0'], win: '#a9cfd1', lit: '#ffffff', sun: '#ffffff' },
    { bg: '#f5f6f8', far: '#eceef1', b: ['#e2e5e9', '#d9eeee', '#eef0f3'], win: '#c4cad1', lit: '#c9eeee', sun: '#ffffff' }
  ];
  function facade(r, T) {
    let s = `<rect width="400" height="300" fill="${T.bg}"/>`;
    s += `<circle cx="${60 + r() * 280}" cy="${50 + r() * 40}" r="${22 + r() * 18}" fill="${T.sun}" opacity="0.9"/>`;
    let x = -10;
    while (x < 400) { const w = 30 + r() * 50, h = 60 + r() * 90; s += `<rect x="${x}" y="${300 - 40 - h}" width="${w}" height="${h + 40}" fill="${T.far}"/>`; x += w + 4; }
    x = -20 + r() * 20;
    let i = 0;
    while (x < 410) {
      const w = 90 + r() * 70, h = 120 + r() * 120, y = 300 - h, col = T.b[i % T.b.length];
      s += `<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="${col}"/>`;
      const cols = Math.max(2, Math.floor(w / 26)), rows = Math.max(3, Math.floor((h - 30) / 30));
      const cw = (w - 16) / cols, rh = (h - 30) / rows;
      const winBase = T.win;
      for (let cx = 0; cx < cols; cx++) for (let ry = 0; ry < rows; ry++) {
        const lit = r() < 0.22;
        s += `<rect x="${(x + 8 + cx * cw + cw * 0.18).toFixed(1)}" y="${(y + 14 + ry * rh + rh * 0.2).toFixed(1)}" width="${(cw * 0.64).toFixed(1)}" height="${(rh * 0.6).toFixed(1)}" rx="1.5" fill="${lit ? T.lit : winBase}" opacity="${lit ? 0.9 : 0.6}"/>`;
      }
      if (r() < 0.6) for (let ry = 1; ry < rows; ry += 2) s += `<rect x="${x + 4}" y="${(y + 14 + ry * rh + rh * 0.82).toFixed(1)}" width="${w - 8}" height="2.5" fill="${winBase}" opacity="0.35"/>`;
      x += w + 6 + r() * 10; i++;
    }
    return s;
  }
  function interior(r, T) {
    let s = `<rect width="400" height="300" fill="${T.bg}"/><rect y="210" width="400" height="90" fill="${T.far}"/>`;
    const wx = 70 + r() * 120;
    s += `<rect x="${wx}" y="50" width="140" height="130" rx="4" fill="${T.lit}"/><rect x="${wx + 68}" y="50" width="4" height="130" fill="${T.b[0]}"/><rect x="${wx}" y="113" width="140" height="4" fill="${T.b[0]}"/>`;
    s += `<polygon points="${wx},210 ${wx + 140},210 ${wx + 190},300 ${wx - 50},300" fill="${T.lit}" opacity="0.35"/>`;
    s += `<rect x="${250 - r() * 40}" y="172" width="120" height="40" rx="10" fill="${T.b[0]}"/><rect x="${250 - 10}" y="155" width="34" height="30" rx="8" fill="${T.b[1]}"/>`;
    s += `<circle cx="${40 + r() * 20}" cy="160" r="26" fill="${T.b[1]}"/><rect x="${50}" y="180" width="6" height="32" fill="${T.b[0]}"/>`;
    return s;
  }
  function plan(r, T) {
    const ink = T.b[0];
    let s = `<rect width="400" height="300" fill="${T.bg}"/><g fill="none" stroke="${ink}" stroke-width="5" stroke-linecap="square">`;
    s += `<rect x="50" y="40" width="300" height="220"/>`;
    const vx = 150 + r() * 80, hy = 120 + r() * 60;
    s += `<path d="M${vx} 40 V${hy - 25} M${vx} ${hy + 20} V260 M50 ${hy} H${vx - 30} M${vx} ${hy} H${vx + 40} M${vx + 90} ${hy} H350"/></g>`;
    s += `<rect x="${vx + 20}" y="${hy + 30}" width="${340 - vx - 30}" height="${250 - hy - 40}" fill="${T.lit}" opacity="0.5"/>`;
    s += `<rect x="60" y="50" width="${vx - 70}" height="${hy - 60}" fill="${T.far}"/>`;
    return s;
  }
  function render(el) {
    const seed = el.getAttribute('seed') || 'x', label = el.getAttribute('label') || '';
    const r = rng(hash(seed + label)), T = THEMES[hash(seed) % THEMES.length];
    const kind = /plano/i.test(label) ? plan : /interior|durante/i.test(label) ? interior : facade;
    (el.shadowRoot || el.attachShadow({ mode: 'open' })).innerHTML = `<svg viewBox="0 0 400 300" preserveAspectRatio="xMidYMid slice" style="display:block;width:100%;height:100%" role="img" aria-label="Ilustración: ${label.replace(/"/g, '')}">${kind(r, T)}</svg>`;
  }
  customElements.define('ri-art', class extends HTMLElement {
    static get observedAttributes() { return ['seed', 'label']; }
    connectedCallback() { this.style.display = 'block'; this.style.width = '100%'; this.style.height = '100%'; render(this); }
    attributeChangedCallback() { if (this.isConnected) render(this); }
  });
})();
