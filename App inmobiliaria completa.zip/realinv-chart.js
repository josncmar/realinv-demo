/* RealInv — gráfico financiero interactivo (hover / táctil, filtros de periodo). */
(function () {
  const MON = ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic'];
  const fd = t => { const d = new Date(t); return d.getDate() + ' ' + MON[d.getMonth()] + ' ' + d.getFullYear(); };
  const eur = n => window.REALINV.fmtEUR(n);
  const sg = n => (n > 0.5 ? '+' : n < -0.5 ? '−' : '') + eur(Math.abs(n));
  const pc = n => (n > 0 ? '+' : n < 0 ? '−' : '') + Math.abs(n * 100).toFixed(2).replace('.', ',') + ' %';
  const RANGES = [['1M', 30], ['3M', 91], ['6M', 182], ['1A', 365], ['Todo', 0]];

  window.RIChart = function RIChart(p) {
    const R = React, h = R.createElement;
    const [range, setRange] = R.useState(p.range || 'Todo');
    const [hi, setHi] = R.useState(null);
    const [w, setW] = R.useState(640);
    const ref = R.useRef(null);
    R.useEffect(() => {
      const el = ref.current; if (!el || !window.ResizeObserver) return;
      const ro = new ResizeObserver(e => { const cw = Math.round(e[0].contentRect.width); if (cw > 0) setW(cw); });
      ro.observe(el); return () => ro.disconnect();
    }, []);
    const all = p.series || []; if (!all.length) return null;
    const end = all[all.length - 1].t, days = (RANGES.find(r => r[0] === range) || [0, 0])[1];
    const from = days ? Math.max(all[0].t, end - days * 864e5) : all[0].t;
    const pts = all.filter(x => x.t >= from);
    const H = p.height || 260, pt = 16, pb = 26, pl = 4, pr = 4;
    let lo = Infinity, hiV = -Infinity; pts.forEach(x => { lo = Math.min(lo, x.v, x.c); hiV = Math.max(hiV, x.v, x.c); });
    const pad = Math.max((hiV - lo) * 0.18, hiV * 0.02, 50); lo = Math.max(0, lo - pad); hiV += pad;
    const t0 = pts[0].t, t1 = Math.max(pts[pts.length - 1].t, t0 + 864e5);
    const X = t => pl + (t - t0) / (t1 - t0) * (w - pl - pr), Y = v => pt + (hiV - v) / (hiV - lo) * (H - pt - pb);
    const line = k => pts.map((x, i) => (i ? 'L' : 'M') + X(x.t).toFixed(1) + ' ' + Y(x[k]).toFixed(1)).join(' ');
    const last = pts[pts.length - 1], first = pts[0];
    const up = last.v >= last.c, col = up ? '#0e966c' : '#e36d57', fill = up ? 'rgba(14,150,108,0.12)' : 'rgba(227,109,87,0.14)';
    const area = line('v') + ' ' + pts.slice().reverse().map(x => 'L' + X(x.t).toFixed(1) + ' ' + Y(x.c).toFixed(1)).join(' ') + ' Z';
    const marks = (p.marks || []).filter(m => m.t >= t0 && m.t <= t1);
    const shown = hi != null && pts[hi] ? pts[hi] : last;
    const gain = shown.v - shown.c, chg = shown.v - first.v;
    const near = hi != null ? marks.filter(m => Math.abs(m.t - shown.t) <= 2 * 864e5) : [];
    const pick = e => {
      const r = ref.current.getBoundingClientRect(); const cx = (e.touches ? e.touches[0].clientX : e.clientX) - r.left;
      const t = t0 + (cx - pl) / (w - pl - pr) * (t1 - t0); let best = 0, bd = Infinity;
      for (let i = 0; i < pts.length; i++) { const d = Math.abs(pts[i].t - t); if (d < bd) { bd = d; best = i; } }
      setHi(best);
    };
    const els = [];
    [0.25, 0.75].forEach((f, i) => { const v = lo + (hiV - lo) * f; els.push(h('line', { key: 'g' + i, x1: 0, x2: w, y1: Y(v), y2: Y(v), stroke: 'rgba(0,0,0,0.05)' })); els.push(h('text', { key: 'gt' + i, x: w - 2, y: Y(v) - 5, fontSize: 10, fill: 'rgba(45,49,57,0.4)', textAnchor: 'end' }, eur(Math.round(v / 100) * 100))); });
    els.push(h('path', { key: 'a', d: area, fill }));
    els.push(h('path', { key: 'c', d: line('c'), fill: 'none', stroke: 'rgba(45,49,57,0.45)', strokeWidth: 1.4, strokeDasharray: '4 4' }));
    els.push(h('path', { key: 'v', d: line('v'), fill: 'none', stroke: col, strokeWidth: 2.4, strokeLinejoin: 'round' }));
    marks.forEach((m, i) => { const pv = pts.find(x => x.t >= m.t) || last; els.push(h('circle', { key: 'm' + i, cx: X(m.t), cy: Y(pv.v), r: 4, fill: m.kind === 'out' ? '#0e966c' : m.kind === 'in' ? '#fff' : '#72d9d9', stroke: '#2d3139', strokeWidth: 1.4 })); });
    if (hi != null) { const x = X(shown.t); els.push(h('line', { key: 'hl', x1: x, x2: x, y1: pt - 6, y2: H - pb, stroke: 'rgba(45,49,57,0.35)', strokeWidth: 1 })); els.push(h('circle', { key: 'hc', cx: x, cy: Y(shown.v), r: 5.5, fill: col, stroke: '#fff', strokeWidth: 2 })); els.push(h('circle', { key: 'hcc', cx: x, cy: Y(shown.c), r: 3.5, fill: '#fff', stroke: 'rgba(45,49,57,0.6)', strokeWidth: 1.4 })); }
    els.push(h('text', { key: 'x0', x: pl, y: H - 6, fontSize: 11, fill: 'rgba(45,49,57,0.45)' }, fd(t0)));
    els.push(h('text', { key: 'x1', x: w - pr, y: H - 6, fontSize: 11, fill: 'rgba(45,49,57,0.45)', textAnchor: 'end' }, fd(t1)));
    const tipX = hi != null ? Math.min(Math.max(X(shown.t), 90), w - 90) : 0;
    const S = (o) => o;
    return h('div', { style: S({ display: 'flex', flexDirection: 'column', gap: 14, fontFamily: 'inherit', color: '#2d3139' }) },
      h('div', { style: S({ display: 'flex', flexDirection: 'column', gap: 4 }) },
        h('span', { style: S({ fontSize: 14, color: 'rgba(45,49,57,0.55)' }) }, p.title || 'Valor'),
        h('span', { style: S({ fontSize: p.big || 'clamp(40px,5vw,56px)', fontWeight: 500, letterSpacing: '-0.05em', lineHeight: 1.02, fontVariantNumeric: 'tabular-nums' }) }, eur(shown.v)),
        h('div', { style: S({ display: 'flex', gap: 14, flexWrap: 'wrap', fontSize: 14, alignItems: 'baseline' }) },
          h('span', { style: S({ color: gain >= 0 ? '#0b6e50' : '#a8432f', fontWeight: 600 }) }, sg(gain) + ' (' + pc(shown.c ? gain / shown.c : 0) + ')'),
          h('span', { style: S({ color: 'rgba(45,49,57,0.55)' }) }, 'sobre ' + eur(shown.c) + ' aportados'),
          h('span', { style: S({ color: 'rgba(45,49,57,0.45)' }) }, hi != null ? fd(shown.t) : (range === 'Todo' ? 'Hoy · simulado' : 'Cambio en ' + range + ' · ' + sg(chg)))
        )
      ),
      h('div', { ref, style: S({ position: 'relative', width: '100%', touchAction: 'pan-y', cursor: 'crosshair', userSelect: 'none' }), onMouseMove: pick, onTouchStart: pick, onTouchMove: pick, onMouseLeave: () => setHi(null), onTouchEnd: () => setHi(null) },
        h('svg', { width: w, height: H, viewBox: '0 0 ' + w + ' ' + H, style: { display: 'block', width: '100%', height: H }, role: 'img', 'aria-label': (p.title || 'Valor') + ': evolución' }, els),
        hi != null ? h('div', { style: S({ position: 'absolute', top: 0, left: tipX, transform: 'translate(-50%,-100%)', marginTop: -6, background: '#2d3139', color: '#fff', borderRadius: 12, padding: '8px 12px', fontSize: 12, lineHeight: 1.45, pointerEvents: 'none', whiteSpace: 'nowrap', boxShadow: '0 10px 30px rgba(15,23,42,0.25)' }) },
          h('div', { style: { color: 'rgba(255,255,255,0.6)' } }, fd(shown.t)),
          h('div', null, 'Valor ', h('b', null, eur(shown.v))),
          h('div', null, 'Aportado ', eur(shown.c)),
          near.map((m, i) => h('div', { key: i, style: { color: '#72d9d9' } }, m.label))
        ) : null
      ),
      h('div', { style: S({ display: 'flex', justifyContent: 'space-between', gap: 12, flexWrap: 'wrap', alignItems: 'center' }) },
        h('div', { style: S({ display: 'flex', gap: 2, background: '#f2f3f5', borderRadius: 999, padding: 3 }) },
          RANGES.map(r => h('button', { key: r[0], onClick: () => { setRange(r[0]); setHi(null); }, style: S({ height: 32, padding: '0 14px', borderRadius: 999, border: 0, background: range === r[0] ? '#fff' : 'transparent', boxShadow: range === r[0] ? '0 1px 3px rgba(0,0,0,0.12)' : 'none', fontFamily: 'inherit', fontSize: 13, fontWeight: 500, color: range === r[0] ? '#2d3139' : 'rgba(45,49,57,0.55)', cursor: 'pointer' }) }, r[0]))),
        h('div', { style: S({ display: 'flex', gap: 14, flexWrap: 'wrap', fontSize: 12, color: 'rgba(45,49,57,0.6)' }) },
          h('span', { style: { display: 'flex', alignItems: 'center', gap: 6 } }, h('span', { style: { width: 14, height: 2.4, background: col } }), 'Valor estimado'),
          h('span', { style: { display: 'flex', alignItems: 'center', gap: 6 } }, h('span', { style: { width: 14, borderTop: '1.5px dashed rgba(45,49,57,0.55)' } }), 'Capital aportado'),
          h('span', { style: { display: 'flex', alignItems: 'center', gap: 6 } }, h('span', { style: { width: 12, height: 10, background: fill, borderRadius: 2 } }), up ? 'Ganancia estimada' : 'Pérdida estimada'),
          h('span', { style: { display: 'flex', alignItems: 'center', gap: 6 } }, h('span', { style: { width: 8, height: 8, borderRadius: '50%', background: '#72d9d9', border: '1.4px solid #2d3139' } }), 'Hito')
        )
      ),
      h('span', { style: S({ fontSize: 11, color: 'rgba(45,49,57,0.45)' }) }, 'Datos simulados de demostración. El valor solo cambia con evidencia (tasación, venta, pago). No es un retorno garantizado.')
    );
  };
})();
