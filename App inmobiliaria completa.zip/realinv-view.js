/* RealInv V1 — valores de render. Se llama con el componente como `this`. */
window.RealInvView = function () {
  const s = this.state, D = window.REALINV, P = this.props || {};
  const forced = P.viewport === 'Móvil 390' || /[?&]movil=1/.test(location.search);
  const isMobile = forced || s.vw < 768;
  const shell = forced ? { maxW: '390px', h: '844px', radius: '44px', shadow: '0 0 0 10px #16181d, 0 40px 100px rgba(15,23,42,0.4)' } : { maxW: '100%', h: '100vh', radius: '0px', shadow: 'none' };
  const out = { shell, isMobile, isDesktop: !isMobile, ready: true, notReady: false, mainRef: this.mainRef, stop: e => e.stopPropagation() };
  const A = s.answers || D.profiles[s.profileKey];
  const r = {}; ['welcome', 'how', 'auth', 'onboarding', 'home', 'discover', 'thesis', 'operation', 'portfolio', 'investment', 'activity', 'profile'].forEach(k => { r[k] = s.route === k; });
  const inApp = !['welcome', 'how', 'auth', 'onboarding'].includes(s.route);
  const sec = { home: 'home', discover: 'discover', thesis: 'discover', operation: 'discover', portfolio: 'portfolio', investment: 'portfolio', activity: 'activity', profile: 'profile' }[s.route];
  const navI = k => { const a = sec === k; return { go: () => this.go(k), fg: a ? '#2d3139' : 'rgba(45,49,57,0.55)', w: a ? '600' : '500', bar: a ? '#2d3139' : 'transparent', cur: a ? 'page' : 'false', mfg: a ? '#2d3139' : 'rgba(45,49,57,0.42)' }; };
  const nav = { home: navI('home'), discover: navI('discover'), portfolio: navI('portfolio'), activity: navI('activity'), profile: navI('profile') };
  const CLAIMS = {
    'Oportunidades': ['No busques pisos.', 'Descubre oportunidades', 'Una nueva forma de invertir en inmobiliario. Descubre zonas con potencial, invierte desde nuestra plataforma y deja la gestión en nuestras manos.'],
    'Bien construido': ['Tu patrimonio.', 'Bien construido.', 'Inversión inmobiliaria en España, guiada por datos y ejecutada de principio a fin. Con la claridad que merece tu capital.'],
    'Como debió ser': ['Invertir en vivienda,', 'como siempre debió ser.', 'Oportunidades seleccionadas con inteligencia territorial y cada etapa a la vista, de la compra a la liquidación.'],
    'Sin ruido': ['Inversión inmobiliaria.', 'Sin ruido.', 'Solo oportunidades con fundamento, datos con fuente y una ejecución que puedes seguir en todo momento.']
  };
  const cl = CLAIMS[P.claim] || CLAIMS['Oportunidades'];
  const LST = { 'En evaluación': ['rgba(217,119,6,0.1)', '#8a4b04'], 'Operación abierta': ['rgba(114,217,217,0.2)', '#1f5f64'], 'Anuncio externo': ['rgba(0,0,0,0.05)', '#2d3139'], 'Descartada': ['rgba(227,109,87,0.1)', '#a8432f'], 'Operación en curso': ['rgba(14,150,108,0.1)', '#0b6e50'] };
  const SRC = { Idealista: ['#e3f05a', '#2d3139', 'id'], Fotocasa: ['#1f6fd6', '#fff', 'f'] };
  const decL = l => { const st = LST[l.status], sr = SRC[l.source]; return Object.assign({}, l, { priceF: this.eur(l.price), eurm2: l.price / l.m2, eurm2F: D.fmtNum(l.price / l.m2) + ' €/m²', meta: l.m2 + ' m² · ' + l.rooms + ' hab. · ' + l.state, stBg: st[0], stFg: st[1], srcBg: sr[0], srcFg: sr[1], srcMono: sr[2], img: 'viv-' + l.id, hasNote: !!l.note, note: l.note || '', hasOp: !!l.op, d: this.parseDate(l.updated), open: () => l.op ? this.go('operation', { operationId: l.op }) : this.setState({ modal: { type: 'listing', id: l.id } }) }); };
  const sum = (arr, fn) => arr.reduce((a, x) => a + fn(x), 0);

  const all = D.theses.map(t => this.dec(t, A, 'foryou'));
  const f = s.f;
  const list = all.filter(t => (f.loc === 'Todas' || t.region === f.loc) && (f.strat === 'Todas' || (f.strat === 'Reforma y venta' ? t.strategyKey === 'reforma' : t.strategyKey === 'compraventa')) && (f.ticket === 'Cualquiera' || t.minTicket <= (f.ticket === 'Hasta 5.000 €' ? 5000 : 10000)) && (f.hor === 'Cualquiera' || t.termMax <= (f.hor === 'Hasta 15 meses' ? 15 : 18)) && (f.risk === 'Cualquiera' || t.risk === f.risk));
  const sorters = { 'Mejor encaje': (a, b) => b.fit - a.fit || b.attract - a.attract, 'Interés': (a, b) => b.interestedN - a.interestedN, 'Plazo': (a, b) => a.termMax - b.termMax };
  list.sort(sorters[s.sort] || sorters['Mejor encaje']);
  const setF = k => v => this.setState(st => ({ f: Object.assign({}, st.f, { [k]: v }) }));
  const FDEF = [['loc', 'Zona', ['Todas', 'Región de Murcia', 'Castilla-La Mancha', 'Comunitat Valenciana', 'Comunidad de Madrid']], ['strat', 'Estrategia', ['Todas', 'Reforma y venta', 'Compraventa y mejora']], ['ticket', 'Ticket', ['Cualquiera', 'Hasta 5.000 €', 'Hasta 10.000 €']], ['hor', 'Horizonte', ['Cualquiera', 'Hasta 15 meses', 'Hasta 18 meses']], ['risk', 'Riesgo', ['Cualquiera', 'Moderado', 'Medio', 'Medio-alto']]];
  const segOn = { bg: '#fff', sh: '0 1px 3px rgba(0,0,0,0.12)', fg: '#2d3139' }, segOff = { bg: 'transparent', sh: 'none', fg: 'rgba(45,49,57,0.6)' };
  const fy = s.discoverMode === 'foryou' ? segOn : segOff, mp = s.discoverMode === 'map' ? segOn : segOff;
  const disc = {
    isForYou: s.discoverMode === 'foryou', isMap: s.discoverMode === 'map', list, count: list.length + ' tesis',
    filters: FDEF.map(d => { const on = f[d[0]] !== d[2][0]; return { label: d[1], el: this.sel(f[d[0]], d[2], setF(d[0]), d[1]), bg: on ? 'rgba(114,217,217,0.16)' : '#fff', bd: on ? 'rgba(42,109,116,0.35)' : 'rgba(0,0,0,0.1)' }; }),
    sortEl: this.sel(s.sort, ['Mejor encaje', 'Interés', 'Plazo'], v => this.setState({ sort: v }), 'Ordenar'),
    showLoading: s.loading, showError: !s.loading && s.error, showEmpty: !s.loading && !s.error && list.length === 0, showList: !s.loading && !s.error && list.length > 0,
    clear: () => this.setState({ f: this.emptyF() }), toForYou: () => this.setState({ discoverMode: 'foryou' }), toMap: () => this.setState({ discoverMode: 'map', mapFocus: '' }),
    fyBg: fy.bg, fySh: fy.sh, fyFg: fy.fg, mpBg: mp.bg, mpSh: mp.sh, mpFg: mp.fg,
    mapSrc: 'mapa-espana.html' + (s.mapFocus ? '?focus=' + s.mapFocus : '')
  };

  const acts = this.activityItems().map(a => {
    const K = { 'Confirmado': ['rgba(14,150,108,0.1)', '#0b6e50'], 'Simulación demo': ['rgba(217,119,6,0.1)', '#8a4b04'] }; const k = K[a.kind] || ['rgba(114,217,217,0.2)', '#1f5f64']; const g = a.go;
    return Object.assign({}, a, { kBg: k[0], kFg: k[1], unread: a.action && !s.readIds.includes(a.id), dot: a.action ? '#d97706' : 'rgba(45,49,57,0.25)', ctaLabel: { thesis: 'Ver tesis', operation: 'Ver operación', investment: 'Ver inversión' }[g[0]], open: () => { if (g[0] === 'thesis') this.openThesis(g[1], 'activity'); else if (g[0] === 'operation') this.go('operation', { operationId: g[1] }); else this.go('investment', { investmentId: g[1] }); } });
  });
  const badge = acts.filter(a => a.unread).length;

  const PFB = window.RealInvPortfolio;
  const port = PFB.build(s.profileKey, s.investments.filter(i => i.added && D.operations[i.op]).map(i => PFB.fromOperation(D.operations[i.op], i)));
  const pendingOps = Object.keys(s.intents).filter(k => s.intents[k].status === 'pending' && !s.investments.find(i => i.op === k));
  const highFit = all.filter(t => t.fit >= 85).length;
  const home = {
    date: 'Sábado, 18 de octubre', greet: 'Hola, ' + s.userName + '.',
    synth: highFit + (highFit === 1 ? ' oportunidad encaja' : ' oportunidades encajan') + ' especialmente bien contigo esta semana.',
    recs: all.slice().sort((a, b) => b.fit - a.fit || b.attract - a.attract).slice(0, 3).map(t => Object.assign({}, t, { open: () => this.openThesis(t.id, 'home') })),
    hasPending: pendingOps.length > 0, pendingText: pendingOps.length ? 'Confirmaste tu intención en ' + pendingOps[0] + ' por ' + this.eur(s.intents[pendingOps[0]].ticket) + '. Falta la formalización. No se ha realizado ningún cargo.' : '',
    pendingGo: () => { if (pendingOps.length) this.go('operation', { operationId: pendingOps[0] }); },
    attention: acts.filter(a => a.action).concat(acts.filter(a => !a.action)).slice(0, 3),
    hasInv: port.list.length > 0, noInv: port.list.length === 0, investedF: this.eur(port.k.activeCap), estF: this.eur(port.k.activeVal), nInv: port.k.nActive + (port.k.nActive === 1 ? ' inversión activa' : ' inversiones activas')
  };
  const locTxt = (A.locations || []).join(', ');
  const profileShort = A.pref + ' · ' + this.eur(A.ticket || 0) + ' · ' + A.horizon + ' meses';

  const tRaw = D.theses.find(x => x.id === s.thesisId) || D.theses[0];
  const t = this.dec(tRaw, A, 'thesis');
  const backMap = { foryou: ['Para ti', () => this.go('discover', { discoverMode: 'foryou' })], map: ['Mapa', () => this.go('discover', { discoverMode: 'map', mapFocus: tRaw.barrio })], home: ['Inicio', () => this.go('home')], portfolio: ['Mi portfolio', () => this.go('portfolio')], activity: ['Actividad', () => this.go('activity')], search: ['Descubrir', () => this.go('discover')], operation: ['Descubrir', () => this.go('discover')] };
  const bk = backMap[s.origin] || backMap.foryou;
  const crumbArr = s.origin === 'map' ? ['Mapa'].concat(s.trail || [t.city, t.name]) : [bk[0], t.name + ', ' + t.city];
  const lAll = tRaw.listings.map(id => decL(D.listings[id]));
  const tabsDef = ['Todas', 'En evaluación', 'Financiación abierta'];
  const inTab = (l, tb) => tb === 'Todas' || (tb === 'En evaluación' ? l.status === 'En evaluación' : l.status === 'Operación abierta');
  const lst = lAll.filter(l => inTab(l, s.listTab));
  const lsort = { 'Precio': (a, b) => a.price - b.price, '€/m²': (a, b) => a.eurm2 - b.eurm2, 'Actualización': (a, b) => b.d - a.d };
  lst.sort(lsort[s.listSort] || lsort['Actualización']);
  const tOps = tRaw.operations.map(id => this.opDec(id));
  const bump = s.bump[tRaw.id] || 0;
  const fun = [['Personas interesadas', t.interestedN], ['Indicaron un importe orientativo', tRaw.withAmount + bump], ['Revisaron una operación', tRaw.reviewed], ['Compromisos confirmados', sum(tOps, o => o.commitmentsN)]];
  const openOp = tOps.find(o => o.isCaptando);
  const cmp = tRaw.compare;
  const T = {
    t, back: bk[1], backLabel: bk[0], crumbs: crumbArr.map((c, i) => ({ c, sep: i < crumbArr.length - 1 ? '/' : '' })),
    toggleSave: () => this.toggleSave(tRaw.id), share: () => this.toast('Enlace copiado (demo)'),
    narr: tRaw.narrative.map(p => ({ p })), tr: this.trendChart(tRaw),
    cmpRows: [['Precio de oferta', 0, v => D.fmtNum(v) + ' €/m²'], ['Variación 12 meses', 1, v => D.fmtPct(v)], ['Variación 36 meses', 2, v => D.fmtPct(v)], ['Días en publicación', 3, v => v + ' días']].map(rw => ({ k: rw[0], a: rw[2](cmp.micro[rw[1]]), b: rw[2](cmp.muni[rw[1]]), c: rw[2](cmp.prov[rw[1]]) })),
    opp: tRaw.opp.map(x => ({ x })), risks: tRaw.risks.map(x => ({ x })),
    showMethod: s.showMethod, toggleMethod: () => this.setState({ showMethod: !s.showMethod }), methodLabel: s.showMethod ? 'Ocultar metodología' : 'Ver fuentes y metodología',
    method: [['Atractivo de la oportunidad', 'Demanda y oferta 25 % · variación de precios 15 % · liquidez 15 % · margen estimado tras reforma 25 % · riesgo operativo 10 % · confianza del dato 10 %. Pesos orientativos, no calibrados.'], ['Encaje con tu perfil', 'Ticket, horizonte, preferencia de riesgo, zonas y estrategias. Independiente del atractivo.'], ['Datos estimados', 'Diferencial reformado, presión de demanda y liquidez se calculan sobre una muestra demo de anuncios. Los precios anunciados no son transacciones.'], ['Última actualización', D.UPDATED + ' · cobertura de la muestra: media.']].map(m => ({ k: m[0], v: m[1] })),
    miniSrc: 'mapa-espana.html?mini=' + tRaw.barrio,
    eco: this.eco(tRaw, s.ecoTicket),
    ecoTickets: [2500, 5000, 10000, 25000].map(v => ({ label: this.eur(v), bg: v === s.ecoTicket ? '#2d3139' : '#fff', fg: v === s.ecoTicket ? '#fff' : '#2d3139', bd: v === s.ecoTicket ? '#2d3139' : 'rgba(0,0,0,0.12)', pick: () => this.setState({ ecoTicket: v }) })),
    tabs: tabsDef.map(tb => { const on = tb === s.listTab; return { label: tb, count: lAll.filter(l => inTab(l, tb)).length, bg: on ? '#2d3139' : 'transparent', fg: on ? '#fff' : 'rgba(45,49,57,0.65)', pick: () => this.setState({ listTab: tb }) }; }),
    listSortEl: this.sel(s.listSort, ['Actualización', 'Precio', '€/m²'], v => this.setState({ listSort: v }), 'Ordenar viviendas'),
    listings: lst, noListings: lst.length === 0,
    funnel: fun.map(x => ({ k: x[0], n: x[1], w: Math.max(3, Math.round(x[1] / Math.max(1, fun[0][1]) * 100)) + '%' })),
    ops: tOps, hasOps: tOps.length > 0, noOps: tOps.length === 0,
    interest: () => this.openInterest(tRaw.id), unfollow: () => this.unfollow(tRaw.id),
    fitReasons: D.fitReasons(tRaw, A).map(x => ({ x })), goPrefs: () => this.go('profile', { profileTab: 'inv' }),
    hasOpenOp: !!openOp, openOpLabel: openOp ? openOp.id + ' · ' + openOp.pctLabel : '', openOpGo: openOp ? openOp.open : null
  };

  const O = this.opDec(D.operations[s.operationId] ? s.operationId : 'O-102');
  const oL = D.listings[O.listing];
  Object.assign(O, { back: () => this.openThesis(O.thesis, 'operation'), listingL: oL ? decL(oL) : {}, part: () => this.openPart(O.id), formalize: () => this.formalize(O.id), goInv: () => this.go('investment', { investmentId: O.invId }) });

  const pfTab = s.pfTab || 'Todas', K = port.k;
  const rowsAll = port.list.map(x => Object.assign({}, x, { open: () => this.go('investment', { investmentId: x.id }) }));
  const rows = rowsAll.filter(x => pfTab === 'Activas' ? x.active : pfTab === 'Completadas' ? x.done : true);
  const followIds = Object.keys(s.interests).concat(s.saved.filter(id => !s.interests[id])).filter(id => D.theses.find(x => x.id === id));
  const follow = followIds.map(id => {
    const tr = D.theses.find(x => x.id === id), td = this.dec(tr, A, 'portfolio');
    const ls = tr.listings.map(l => D.listings[l]).filter(Boolean), evalN = ls.filter(l => l.status === 'En evaluación').length;
    const allOps = tr.operations.map(o => this.opDec(o)), ops = allOps.filter(o => o.isCaptando), pend = allOps.filter(o => o.pending || o.abandoned);
    return Object.assign({}, td, { amtLabel: s.interests[id] ? this.eur(s.interests[id]) : 'Guardada', evalN: String(evalN), ops, hasOps: ops.length > 0,
      hasPend: pend.length > 0, pendText: pend.length ? (pend[0].pending ? 'Acción pendiente: completar la formalización de ' + pend[0].id + ' (' + pend[0].intentF + ').' : 'Proceso sin completar en ' + pend[0].id + '. Puedes retomarlo.') : '', pendGo: pend.length ? pend[0].open : null,
      next: tr.nextAction || (ops.length ? 'Captación abierta en ' + ops[0].id : 'Te avisaremos cuando haya una operación concreta'), open: () => this.openThesis(id, 'portfolio') });
  });
  const PF = {
    loading: s.loading, error: !s.loading && s.error, ok: !s.loading && !s.error,
    chartEl: React.createElement(window.RIChart, { key: 'pf-' + s.profileKey + '-' + port.list.length, series: port.series, marks: port.marks, title: 'Valor total del portfolio' }),
    totalF: this.eur(K.total), activeValF: this.eur(K.activeVal), returnedF: this.eur(K.returned), activeW: (K.activeVal / K.total * 100).toFixed(1) + '%', returnedW: (K.returned / K.total * 100).toFixed(1) + '%',
    kpis: [['Capital activo invertido', this.eur(K.activeCap), '#2d3139'], ['Total invertido histórico', this.eur(K.totalHist), '#2d3139'], ['Beneficio no realizado (estimado)', PFB.sgn(K.unreal), K.unreal >= 0 ? '#0b6e50' : '#a8432f'], ['Beneficio realizado', PFB.sgn(K.realized), '#0b6e50'], ['Beneficio total', PFB.sgn(K.profit), K.profit >= 0 ? '#0b6e50' : '#a8432f'], ['Rentabilidad acumulada (ilustrativa)', PFB.pct(K.ret), K.ret >= 0 ? '#0b6e50' : '#a8432f'], ['Inversiones activas', String(K.nActive), '#2d3139'], ['Inversiones completadas', String(K.nDone), '#2d3139']].map(k => ({ k: k[0], v: k[1], fg: k[2] })),
    tabs: ['Todas', 'Activas', 'Completadas'].map(tb => { const on = tb === pfTab, n = tb === 'Todas' ? rowsAll.length : tb === 'Activas' ? K.nActive : K.nDone; return { label: tb + ' · ' + n, bg: on ? '#fff' : 'transparent', sh: on ? '0 1px 3px rgba(0,0,0,0.12)' : 'none', fg: on ? '#2d3139' : 'rgba(45,49,57,0.6)', pick: () => this.setState({ pfTab: tb }) }; }),
    rows, follow, hasFollow: follow.length > 0, noFollow: follow.length === 0
  };
  const selI = rowsAll.find(x => x.id === s.investmentId) || rowsAll[0];
  const IV = selI ? Object.assign({}, selI, { has: true, none: false, hasThesis: !!selI.thesis, goThesis: () => { if (selI.thesis) this.openThesis(selI.thesis, 'portfolio'); },
    chartEl: React.createElement(window.RIChart, { key: 'iv-' + selI.id, series: selI.series, marks: selI.marks, title: selI.done ? 'Valor de tu posición' : 'Valor estimado de tu posición', big: 'clamp(34px,4vw,48px)', height: 220 }) }) : { has: false, none: true };

  const cats = ['Todas', 'Requiere acción', 'Tesis', 'Operaciones', 'Inversiones'];
  const items = acts.filter(a => s.actFilter === 'Todas' || (s.actFilter === 'Requiere acción' ? a.action : a.cat === s.actFilter));
  const AC = { filters: cats.map(c => { const on = c === s.actFilter; return { c, bg: on ? '#2d3139' : '#fff', fg: on ? '#fff' : '#2d3139', bd: on ? '#2d3139' : 'rgba(0,0,0,0.12)', pick: () => this.setState({ actFilter: c }) }; }), items, empty: items.length === 0, has: items.length > 0 };

  const ptabs = [['inv', 'Perfil de inversión'], ['loc', 'Zonas y estrategia'], ['notif', 'Notificaciones'], ['data', 'Datos y privacidad']];
  const PR = {
    tabs: ptabs.map(p => { const on = s.profileTab === p[0]; return { label: p[1], bg: on ? '#f2f3f5' : 'transparent', fg: on ? '#2d3139' : 'rgba(45,49,57,0.6)', w: on ? '600' : '500', pick: () => this.setState({ profileTab: p[0] }) }; }),
    isInv: s.profileTab === 'inv', isLoc: s.profileTab === 'loc', isNotif: s.profileTab === 'notif', isData: s.profileTab === 'data',
    invGroups: ['goals', 'expRE', 'expInv', 'income', 'capital', 'ticket', 'freq', 'loss', 'pref', 'horizon'].map(k => this.groupView(k, A, 'answers')),
    locGroups: ['locations', 'strategies'].map(k => this.groupView(k, A, 'answers')),
    why: ['Tu ticket (' + this.eur(A.ticket || 0) + ') se compara con la inversión mínima orientativa de cada tesis.', 'Tu horizonte (' + A.horizon + ' meses) se compara con el plazo del escenario base.', 'Tus zonas: ' + locTxt + '.', 'Tu preferencia de riesgo: ' + A.pref + '.', 'Tesis guardadas y búsquedas, con tu permiso.'].map(x => ({ x })),
    notifs: [['viviendas', 'Nuevas viviendas compatibles con tesis que sigo'], ['operaciones', 'Operaciones publicadas y cambios de financiación'], ['hitos', 'Hitos de mis inversiones'], ['resumen', 'Resumen semanal por correo']].map(n => { const on = !!s.notif[n[0]]; return { label: n[1], on, bg: on ? '#2d3139' : 'rgba(0,0,0,0.14)', x: on ? '22px' : '2px', toggle: () => this.setState(st => ({ notif: Object.assign({}, st.notif, { [n[0]]: !st.notif[n[0]] }) })) }; }),
    name: s.userName, label: D.profiles[s.profileKey].label
  };

  const q = (s.q || '').trim().toLowerCase(); const results = [];
  if (q) {
    D.theses.forEach(x => { if ((x.title + ' ' + x.name + ' ' + x.city + ' ' + x.id).toLowerCase().indexOf(q) >= 0) results.push({ label: x.title, sub: x.name + ', ' + x.city + ' · Tesis ' + x.id, go: () => this.openThesis(x.id, 'search') }); });
    Object.keys(D.operations).forEach(k => { const o = D.operations[k]; if ((o.title + ' ' + o.id).toLowerCase().indexOf(q) >= 0) results.push({ label: o.title, sub: 'Operación ' + o.id, go: () => this.go('operation', { operationId: o.id }) }); });
    D.barrios.forEach(b => { if (b.name.toLowerCase().indexOf(q) >= 0) results.push({ label: b.name, sub: 'Barrio · ver en el mapa', go: () => this.go('discover', { discoverMode: 'map', mapFocus: b.id }) }); });
  }

  const md = s.modal;
  const m = { any: !!md, close: () => this.closeModal(), align: isMobile ? 'flex-end' : 'center', radius: isMobile ? '28px 28px 0 0' : '28px', pad: isMobile ? '0px' : '24px', isInterest: !!md && md.type === 'interest', isPart: !!md && md.type === 'part', isListing: !!md && md.type === 'listing' };
  if (m.isInterest) {
    const tt = D.theses.find(x => x.id === md.id);
    Object.assign(m, { tTitle: tt.title, tLoc: tt.name + ', ' + tt.city, amounts: [5000, 10000, 25000, 'custom'].map(v => { const on = md.amount === v; return { label: v === 'custom' ? 'Otro' : this.eur(v), bg: on ? '#2d3139' : '#fff', fg: on ? '#fff' : '#2d3139', bd: on ? '#2d3139' : 'rgba(0,0,0,0.12)', pick: () => this.setModal({ amount: v, err: '' }) }; }),
      isCustom: md.amount === 'custom', custom: md.custom, setCustom: e => this.setModal({ custom: e.target.value }), notify: md.notify, toggleNotify: () => this.setModal({ notify: !md.notify }),
      err: md.err, hasErr: !!md.err, notDone: !md.done, isDone: !!md.done, finalF: md.finalAmt ? this.eur(md.finalAmt) : '', confirm: () => this.confirmInterest(), toPortfolio: () => this.go('portfolio'), ctaLabel: md.edit ? 'Actualizar importe' : 'Registrar interés' });
  }
  if (m.isPart) {
    const o = D.operations[md.op], share = md.ticket / o.total, allOk = md.checks.every(Boolean);
    Object.assign(m, { opTitle: o.title, opId: o.id, steps: ['Importe', 'Riesgos', 'Verificación', 'Firma', 'Estado'].map((n, i) => ({ n, bg: i <= md.step ? '#2d3139' : 'rgba(0,0,0,0.08)', fg: i <= md.step ? '#2d3139' : 'rgba(45,49,57,0.4)' })),
      stepTitle: ['¿Cuánto quieres aportar?', 'Antes de continuar.', 'Verificación de identidad.', 'Revisión y firma.', 'Intención confirmada.'][md.step],
      s0: md.step === 0, s1: md.step === 1, s2: md.step === 2, s3: md.step === 3, s4: md.step === 4,
      tickets: [5000, 10000, 15000, 25000].map(v => { const on = md.ticket === v; return { label: this.eur(v), bg: on ? '#2d3139' : '#fff', fg: on ? '#fff' : '#2d3139', bd: on ? '#2d3139' : 'rgba(0,0,0,0.12)', pick: () => this.setModal({ ticket: v }) }; }),
      scen: o.scenarios.map(x => ({ k: x.k, sale: this.eur(x.sale), part: this.eur(share * (x.sale - o.total)), months: x.months + ' meses' })), shareF: this.pc(share * 100, 2), ticketF: this.eur(md.ticket),
      checks: ['Entiendo que la rentabilidad no está garantizada y que puedo perder parte o todo el capital.', 'Entiendo que el dinero queda inmovilizado hasta la venta y que no hay mercado secundario.', 'Entiendo que plazos y escenarios son estimaciones que pueden retrasarse.', 'Entiendo que la estructura jurídica, comisiones finales e impuestos están pendientes de definición.'].map((l, i) => ({ l, on: !!md.checks[i], toggle: () => { const c = md.checks.slice(); c[i] = !c[i]; this.setModal({ checks: c }); } })),
      nextBg: allOk ? '#2d3139' : 'rgba(45,49,57,0.25)', rejected: md.verify === 'rejected', notRejected: md.verify !== 'rejected',
      next0: () => this.setModal({ step: 1 }), next1: () => { if (allOk) this.setModal({ step: 2 }); }, back: () => this.setModal({ step: Math.max(0, md.step - 1) }),
      verifyOk: () => this.setModal({ step: 3, verify: 'ok' }), verifyKo: () => this.setModal({ verify: 'rejected' }), retry: () => this.setModal({ verify: 'idle' }),
      confirmIntent: () => this.confirmIntent(), done: () => this.setState({ modal: null }), toPortfolio: () => this.go('portfolio') });
  }
  if (m.isListing) m.l = decL(D.listings[md.id]);

  return Object.assign(out, {
    r, inApp, nav, claim: { a: cl[0], b: cl[1], sub: cl[2] }, updated: D.UPDATED, profileShort,
    openHow: () => this.setState({ route: 'how', howBack: s.route === 'how' ? s.howBack : s.route, modal: null, demoOpen: false }),
    howBack: () => this.setState({ route: s.howBack || 'welcome' }), howBackLabel: s.howBack === 'welcome' ? 'Volver' : 'Volver a la app',
    howSteps: [['Descubre', 'Recomendaciones según tu perfil o exploración libre en el mapa de España.'], ['Entiende', 'Datos con fuente, factores de oportunidad y de riesgo, viviendas candidatas y economía de una operación tipo.'], ['Sigue', 'Guarda la tesis o indica un importe orientativo. No se carga dinero ni asumes compromiso.'], ['Operación', 'Cuando el equipo identifica y valida una vivienda, se publica una operación con sus términos.'], ['Revisa', 'Recibes aviso y revisas presupuesto, escenarios, documentación y riesgos.'], ['Confirma', 'Confirmas tu intención y completas verificación y documentación.'], ['Formaliza', 'Tras la formalización y la transferencia, la posición aparece en Mis inversiones.'], ['Ejecución', 'Compra, reforma, comercialización y venta, con fotos, documentos e incidencias.'], ['Liquidación', 'Al cerrar la venta ves el reparto final y el efectivo abonado.']].map((x, i) => ({ n: String(i + 1).padStart(2, '0'), t: x[0], d: x[1] })),
    howOpen: ['Estructura de propiedad: copropiedad, sociedad vehículo, préstamo o tercero regulado.', 'Comisiones finales, impuestos y retorno neto por perfil fiscal.', 'Momento legal del compromiso, custodia del dinero y términos vinculantes.', 'KYC/AML, idoneidad y regulación CNMV aplicable.', 'Tickets mínimos y política de cancelación o reembolso.', 'Licencias de datos, mapas, fotos y portales inmobiliarios.'].map(x => ({ t: x })),
    goAuth: () => s.loggedIn ? this.go('home') : this.setState({ route: 'auth', authStep: 'form', authErr: '' }), goWelcome: () => this.go('welcome'), login: () => s.loggedIn ? this.go('home') : this.login(), logout: () => this.logout(),
    accountLabel: s.loggedIn ? 'Mi cuenta' : 'Entrar', startLabel: s.loggedIn ? 'Volver a mi cuenta' : 'Empezar',
    social: () => this.setState({ email: 'juanpedro@correo.es', userName: 'Juan Pedro', authStep: 'verify', authErr: '' }),
    auth: { isForm: s.authStep === 'form', isVerify: s.authStep === 'verify', isLogin: s.authStep === 'login' }, doLogin: () => this.doLogin(), loginKey: e => { if (e.key === 'Enter') this.doLogin(); }, fillJP: () => this.setState({ email: 'juanpemurcia', pwd: 'murcia123', authErr: '' }), fillJC: () => this.setState({ email: 'josecarlosalba', pwd: 'alba123', authErr: '' }),
    email: s.email, pwd: s.pwd, code: s.code, consent: s.consent, authErr: s.authErr,
    setEmail: e => this.setState({ email: e.target.value }), setPwd: e => this.setState({ pwd: e.target.value }), setCode: e => this.setState({ code: e.target.value.replace(/\D/g, '').slice(0, 6) }),
    toggleConsent: () => this.setState({ consent: !s.consent }), authSubmit: () => this.authSubmit(), fillCode: () => this.setState({ code: '246810', authErr: '' }), verify: () => this.verify(),
    onb: this.onbVals(), onbErr: s.onbErr, onbNext: () => this.onbNext(), onbBack: () => this.onbBack(), presetMarina: () => this.fillPreset('marina'), presetAlex: () => this.fillPreset('alex'),
    search: { q: s.q, setQ: e => this.setState({ q: e.target.value }), open: q.length > 0, results: results.slice(0, 7), none: q.length > 0 && results.length === 0 },
    demo: { open: s.demoOpen, toggle: () => this.setState({ demoOpen: !s.demoOpen, userMenuOpen: false }), marina: () => this.switchProfile('marina'), alex: () => this.switchProfile('alex'), mBg: s.profileKey === 'marina' ? '#fff' : 'transparent', mSh: s.profileKey === 'marina' ? '0 1px 3px rgba(0,0,0,0.12)' : 'none', aBg: s.profileKey === 'alex' ? '#fff' : 'transparent', aSh: s.profileKey === 'alex' ? '0 1px 3px rgba(0,0,0,0.12)' : 'none', load: () => { this.setState({ demoOpen: false }); this.simulateLoad(); }, err: () => this.setState({ error: !s.error, demoOpen: false }), errLabel: s.error ? 'Quitar error simulado' : 'Simular error de carga' },
    userMenu: { open: !!s.userMenuOpen, name: s.userName, toggle: () => this.setState({ userMenuOpen: !s.userMenuOpen, demoOpen: false }) },
    badge, hasBadge: badge > 0, initial: (s.userName || 'M').charAt(0).toUpperCase(),
    goForYou: () => this.go('discover', { discoverMode: 'foryou' }), goPrefs: () => this.go('profile', { profileTab: 'inv' }), retry: () => { this.setState({ error: false }); this.simulateLoad(); },
    home, disc, T, O, PF, IV, AC, PR, m, skeletons: [1, 2, 3].map(i => ({ i })),
    toast: s.toast, hasToast: !!s.toast,
    mobThesis: isMobile && r.thesis, mobOp: isMobile && r.operation && (O.canPart || O.pending || O.abandoned)
  });
};
