/* RealInv V1 — dataset sintético de demostración. Ninguna cifra es real. */
(function () {
  const UPDATED = '14 oct 2026';

  const fmtEUR = (n) => (n == null ? '—' : Math.round(n).toLocaleString('es-ES', { useGrouping: 'always' }) + ' €');
  const fmtNum = (n) => Math.round(n).toLocaleString('es-ES', { useGrouping: 'always' });
  const fmtPct = (n, d = 1) => (n == null ? '—' : (n > 0 ? '+' : '') + n.toFixed(d).replace('.', ',') + ' %');

  const barrios = [
    { id: 'laflota', name: 'La Flota', city: 'murcia', c: [37.9947, -1.1196], r: 420, m: { attract: 82, eurm2: 1720, trend: 6.8, demand: 74, liquidity: 68 }, theses: ['T-01'] },
    { id: 'elcarmen', name: 'El Carmen', city: 'murcia', c: [37.9795, -1.1302], r: 420, m: { attract: 74, eurm2: 1390, trend: 8.1, demand: 69, liquidity: 81 }, theses: ['T-02'] },
    { id: 'vistabella', name: 'Vistabella', city: 'murcia', c: [37.9838, -1.1180], r: 330, m: { attract: 61, eurm2: 1240, trend: 5.2, demand: null, liquidity: 95 }, theses: [] },
    { id: 'santamaria', name: 'Santa María de Gracia', city: 'murcia', c: [37.9998, -1.1335], r: 380, m: { attract: 66, eurm2: 1610, trend: 4.9, demand: 63, liquidity: null }, theses: [] },
    { id: 'ab-centro', name: 'Centro', city: 'albacete', c: [38.9950, -1.8565], r: 380, m: { attract: 79, eurm2: 1650, trend: 5.9, demand: 71, liquidity: 74 }, theses: ['T-03'] },
    { id: 'ab-ensanche', name: 'Ensanche', city: 'albacete', c: [38.9878, -1.8640], r: 380, m: { attract: 71, eurm2: 1480, trend: 4.6, demand: 66, liquidity: 79 }, theses: ['T-04'] },
    { id: 'ab-feria', name: 'Feria', city: 'albacete', c: [38.9852, -1.8470], r: 360, m: { attract: null, eurm2: 1180, trend: null, demand: null, liquidity: null }, theses: [] },
    { id: 'patraix', name: 'Patraix', city: 'valencia', c: [39.4612, -0.3942], r: 520, m: { attract: 84, eurm2: 2480, trend: 9.4, demand: 81, liquidity: 52 }, theses: ['T-05'] },
    { id: 'benicalap', name: 'Benicalap', city: 'valencia', c: [39.4935, -0.3955], r: 520, m: { attract: 68, eurm2: 2050, trend: 7.6, demand: 72, liquidity: 64 }, theses: ['T-06'] },
    { id: 'russafa', name: 'Russafa', city: 'valencia', c: [39.4622, -0.3738], r: 420, m: { attract: 63, eurm2: 3650, trend: 7.1, demand: 88, liquidity: 41 }, theses: [] },
    { id: 'benimaclet', name: 'Benimaclet', city: 'valencia', c: [39.4865, -0.3602], r: 450, m: { attract: 70, eurm2: 2560, trend: 8.0, demand: 79, liquidity: 49 }, theses: [] }
  ];

  const cities = [
    { id: 'murcia', name: 'Murcia', region: 'Región de Murcia', c: [37.9890, -1.1260], zoom: 14, m: { eurm2: 1580, trend: 5.9 } },
    { id: 'albacete', name: 'Albacete', region: 'Castilla-La Mancha', c: [38.9905, -1.8560], zoom: 14, m: { eurm2: 1460, trend: 4.8 } },
    { id: 'valencia', name: 'València', region: 'Comunitat Valenciana', c: [39.4760, -0.3800], zoom: 13, m: { eurm2: 2390, trend: 8.2 } }
  ];

  const theses = [
    {
      id: 'T-01', barrio: 'laflota', name: 'La Flota', city: 'Murcia', region: 'Región de Murcia',
      title: 'Pisos de 2 hab. y 65–85 m²', strategy: 'Compra, reforma y venta', strategyKey: 'reforma',
      asset: 'Vivienda plurifamiliar · edificios de 1970–1990', cost: 132000, costRange: '120.000–145.000 €',
      minTicket: 5000, term: '10–15 meses', termMin: 10, termMax: 15, risk: 'Medio', attract: 82,
      interested: 46, potential: 365000, opsIdentified: 3, opsOpen: 1, reviewed: 19, withAmount: 31,
      status: ['Operaciones identificadas', 'Captación abierta'],
      reasons: ['Demanda residencial sostenida', 'Diferencial entre estado actual y reformado', 'Rotación de anuncios observada'],
      summary: 'Pisos de los años 70–90 con distribución eficiente, en una zona con demanda estable y un diferencial observado entre viviendas sin reformar y reformadas.',
      narrative: [
        'En La Flota los anuncios de pisos de dos dormitorios sin reformar se publican, en la muestra demo, con un descuento medio del 24 % por metro cuadrado frente a viviendas equivalentes ya reformadas en el mismo barrio. Esa diferencia es mayor que el coste típico de una reforma integral de calidad media para 65–85 m².',
        'La demanda de este formato se apoya en hogares de dos o tres personas y en la cercanía a ejes de transporte y servicios. El tiempo mediano de publicación (68 días) sugiere rotación suficiente para plantear una salida en el plazo del escenario base, aunque no la garantiza.',
        'La hipótesis es que comprar por debajo del rango reformado, ejecutar una reforma estandarizada y vender a precio de mercado puede dejar margen tras costes. Es una hipótesis: depende del precio de compra negociado, del control de la obra y de la evolución del mercado durante la operación.'
      ],
      indicators: [
        { label: 'Precio de oferta', value: '1.720 €/m²', note: 'Anuncios comparables · muestra demo', date: 'sep 2026' },
        { label: 'Evolución 12 meses', value: '+6,8 %', note: 'Precio de oferta, no transacciones', date: 'sep 2026' },
        { label: 'Evolución 36 meses', value: '+17,5 %', note: 'Precio de oferta', date: 'sep 2026' },
        { label: 'Anuncios comparables', value: '38', note: '2 hab. · 65–85 m²', date: 'oct 2026' },
        { label: 'Días en publicación', value: '68 días', note: 'Mediana · proxy de liquidez', date: 'oct 2026' },
        { label: 'Hogares', value: '+1,4 %', note: 'Variación anual · padrón (demo)', date: '2025' },
        { label: 'Diferencial reformado', value: '24 %', note: '€/m² reformado vs. sin reformar', date: 'oct 2026' },
        { label: 'Transporte', value: '350 m', note: 'Distancia media a parada de bus', date: '2026' }
      ],
      compare: { micro: [1720, 6.8, 17.5, 68], muni: [1580, 5.9, 15.2, 77], prov: [1290, 5.1, 13.0, 92] },
      opp: ['Diferencial de precio entre vivienda sin reformar y reformada superior al coste de reforma estimado', 'Oferta de producto de 2 hab. relativamente homogénea, lo que facilita estandarizar la reforma', 'Demanda de hogares pequeños estable en la muestra de los últimos 36 meses'],
      risks: ['Sobrecostes de obra en edificios antiguos (instalaciones, estructura, comunidad)', 'Tiempo de venta superior al previsto si se enfría la demanda local', 'El precio de oferta no equivale al precio de cierre; el margen real puede ser menor'],
      operations: ['O-102'], listings: ['M-101', 'M-102', 'M-103']
    },
    {
      id: 'T-02', barrio: 'elcarmen', name: 'El Carmen', city: 'Murcia', region: 'Región de Murcia',
      title: 'Viviendas compactas para actualización', strategy: 'Reforma y venta', strategyKey: 'reforma',
      asset: 'Pisos de 45–65 m² · 1 y 2 hab.', cost: 108000, costRange: '95.000–118.000 €',
      minTicket: 2500, term: '12–18 meses', termMin: 12, termMax: 18, risk: 'Medio-alto', attract: 74,
      interested: 32, potential: 225000, opsIdentified: 2, opsOpen: 0, reviewed: 0, withAmount: 21,
      status: ['Captando interés'],
      reasons: ['Precio de entrada bajo frente al municipio', 'Demanda de alquiler y primera vivienda', 'Mejora de equipamientos cercanos'],
      summary: 'Viviendas pequeñas con precio de entrada inferior a la media municipal, orientadas a primera vivienda tras una actualización completa.',
      narrative: [
        'El Carmen presenta en la muestra demo un precio de oferta inferior a la media de Murcia con una evolución reciente más rápida. El producto compacto tiene un público amplio, pero el estado de conservación de los edificios es heterogéneo.',
        'La tesis plantea actualizaciones completas de viviendas pequeñas, con presupuesto controlado, para venderlas como primera vivienda. El riesgo operativo es mayor que en otras tesis por el estado de las fincas.'
      ],
      indicators: [
        { label: 'Precio de oferta', value: '1.390 €/m²', note: 'Muestra demo', date: 'sep 2026' },
        { label: 'Evolución 12 meses', value: '+8,1 %', note: 'Precio de oferta', date: 'sep 2026' },
        { label: 'Anuncios comparables', value: '52', note: '45–65 m²', date: 'oct 2026' },
        { label: 'Días en publicación', value: '81 días', note: 'Mediana', date: 'oct 2026' }
      ],
      compare: { micro: [1390, 8.1, 19.0, 81], muni: [1580, 5.9, 15.2, 77], prov: [1290, 5.1, 13.0, 92] },
      opp: ['Precio de entrada inferior a la media municipal', 'Público amplio para vivienda compacta', 'Evolución reciente del precio de oferta por encima del municipio'],
      risks: ['Estado heterogéneo de los edificios', 'Mayor sensibilidad a la financiación hipotecaria del comprador final', 'Muestra de datos más reducida y con mayor dispersión'],
      operations: [], listings: ['E-111', 'E-112']
    },
    {
      id: 'T-03', barrio: 'ab-centro', name: 'Centro', city: 'Albacete', region: 'Castilla-La Mancha',
      title: 'Pisos de 2–3 hab. con mejora de acabados', strategy: 'Reforma y venta', strategyKey: 'reforma',
      asset: 'Pisos de 80–100 m² · edificios con ascensor', cost: 126000, costRange: '115.000–138.000 €',
      minTicket: 5000, term: '10–16 meses', termMin: 10, termMax: 16, risk: 'Medio', attract: 79,
      interested: 38, potential: 310000, opsIdentified: 3, opsOpen: 0, reviewed: 0, withAmount: 26,
      status: ['Operaciones identificadas', 'Operación en ejecución'],
      reasons: ['Producto amplio con demanda familiar', 'Reforma ligera de acabados', 'Liquidez comparable a capitales medias'],
      summary: 'Pisos amplios en el centro de Albacete donde una mejora de acabados, sin reforma estructural, acerca la vivienda al rango de precio reformado.',
      narrative: [
        'En el centro de Albacete abundan pisos de 80–100 m² en edificios con ascensor cuyo estado general es correcto pero con acabados antiguos. La muestra demo indica que la mejora de cocina, baños y suelos los acerca al rango de precio de viviendas reformadas.',
        'Al no requerir reforma estructural, el plazo y el riesgo de obra son más acotados. El margen depende de comprar por debajo del rango y de mantener el presupuesto de acabados.'
      ],
      indicators: [
        { label: 'Precio de oferta', value: '1.650 €/m²', note: 'Muestra demo', date: 'sep 2026' },
        { label: 'Evolución 12 meses', value: '+5,9 %', note: 'Precio de oferta', date: 'sep 2026' },
        { label: 'Anuncios comparables', value: '44', note: '2–3 hab.', date: 'oct 2026' },
        { label: 'Días en publicación', value: '74 días', note: 'Mediana', date: 'oct 2026' }
      ],
      compare: { micro: [1650, 5.9, 14.8, 74], muni: [1460, 4.8, 12.6, 83], prov: [1120, 4.1, 10.9, 104] },
      opp: ['Reforma de acabados con menor incertidumbre de obra', 'Producto familiar con demanda estable', 'Precio por m² aún por debajo de capitales comparables'],
      risks: ['Margen sensible al precio de compra', 'Competencia con obra nueva en la periferia', 'Mercado de menor tamaño: menos compradores potenciales'],
      operations: ['O-201'], listings: ['A-201', 'A-202', 'A-205']
    },
    {
      id: 'T-04', barrio: 'ab-ensanche', name: 'Ensanche', city: 'Albacete', region: 'Castilla-La Mancha',
      title: 'Pisos familiares de 80–105 m²', strategy: 'Compraventa y mejora selectiva', strategyKey: 'compraventa',
      asset: 'Pisos de 3 hab. · edificios de 1990–2005', cost: 154000, costRange: '140.000–165.000 €',
      minTicket: 10000, term: '12–18 meses', termMin: 12, termMax: 18, risk: 'Moderado', attract: 71,
      interested: 24, potential: 215000, opsIdentified: 1, opsOpen: 0, reviewed: 0, withAmount: 15,
      status: ['Captando interés'],
      reasons: ['Edificios recientes con menor riesgo de obra', 'Demanda familiar consolidada', 'Mejora selectiva de bajo coste'],
      summary: 'Compra de pisos familiares en buen estado con mejoras puntuales; menor riesgo de obra y margen más moderado.',
      narrative: [
        'Los edificios del Ensanche son más recientes y requieren mejoras puntuales. El potencial de margen es menor que en tesis de reforma integral, pero también el riesgo de ejecución.',
        'La tesis busca oportunidades de compra por debajo de mercado (herencias, ventas rápidas) con mejoras selectivas.'
      ],
      indicators: [
        { label: 'Precio de oferta', value: '1.480 €/m²', note: 'Muestra demo', date: 'sep 2026' },
        { label: 'Evolución 12 meses', value: '+4,6 %', note: 'Precio de oferta', date: 'sep 2026' },
        { label: 'Días en publicación', value: '79 días', note: 'Mediana', date: 'oct 2026' }
      ],
      compare: { micro: [1480, 4.6, 12.1, 79], muni: [1460, 4.8, 12.6, 83], prov: [1120, 4.1, 10.9, 104] },
      opp: ['Menor riesgo de obra', 'Demanda familiar consolidada', 'Mejoras de bajo coste y plazo corto'],
      risks: ['Margen moderado y dependiente de la compra', 'Pocas oportunidades por debajo de mercado', 'Ticket mínimo más alto'],
      operations: [], listings: ['N-301']
    },
    {
      id: 'T-05', barrio: 'patraix', name: 'Patraix', city: 'València', region: 'Comunitat Valenciana',
      title: '2 dormitorios de 60–85 m²', strategy: 'Compra, reforma y venta', strategyKey: 'reforma',
      asset: 'Pisos de 2 hab. · edificios de 1960–1985', cost: 173000, costRange: '160.000–188.000 €',
      minTicket: 10000, term: '12–18 meses', termMin: 12, termMax: 18, risk: 'Medio', attract: 84,
      interested: 40, potential: 280000, opsIdentified: 2, opsOpen: 0, reviewed: 0, withAmount: 27,
      status: ['Captando interés', 'Operaciones identificadas'],
      reasons: ['Presión de demanda alta', 'Liquidez elevada', 'Diferencial reformado en barrio consolidado'],
      summary: 'Barrio consolidado de València con alta presión de demanda, donde pisos de 2 dormitorios sin reformar cotizan con descuento frente a los reformados.',
      narrative: [
        'Patraix combina en la muestra demo una presión de demanda alta con tiempos de publicación cortos. Los pisos sin reformar mantienen un descuento relevante frente a los reformados.',
        'El ticket de entrada es mayor por el precio de la zona, y la competencia de otros compradores-reformistas puede reducir el margen disponible.'
      ],
      indicators: [
        { label: 'Precio de oferta', value: '2.480 €/m²', note: 'Muestra demo', date: 'sep 2026' },
        { label: 'Evolución 12 meses', value: '+9,4 %', note: 'Precio de oferta', date: 'sep 2026' },
        { label: 'Días en publicación', value: '52 días', note: 'Mediana', date: 'oct 2026' },
        { label: 'Anuncios comparables', value: '61', note: '2 hab.', date: 'oct 2026' }
      ],
      compare: { micro: [2480, 9.4, 24.6, 52], muni: [2390, 8.2, 22.1, 58], prov: [1810, 6.9, 18.4, 71] },
      opp: ['Alta liquidez para la salida', 'Diferencial reformado observable', 'Barrio consolidado con servicios'],
      risks: ['Competencia de otros inversores en la compra', 'Precio de entrada alto', 'Sensibilidad a cambios regulatorios locales'],
      operations: ['O-501'], listings: ['P-401', 'P-402', 'P-403']
    },
    {
      id: 'T-06', barrio: 'benicalap', name: 'Benicalap', city: 'València', region: 'Comunitat Valenciana',
      title: 'Pisos de 3 hab. para reforma integral', strategy: 'Compra, reforma y venta', strategyKey: 'reforma',
      asset: 'Pisos de 85–100 m² · edificios de 1970–1985', cost: 189000, costRange: '175.000–205.000 €',
      minTicket: 10000, term: '14–20 meses', termMin: 14, termMax: 20, risk: 'Medio-alto', attract: 68,
      interested: 18, potential: 160000, opsIdentified: 1, opsOpen: 0, reviewed: 0, withAmount: 11,
      status: ['Captando interés'],
      reasons: ['Precio inferior a barrios colindantes', 'Producto familiar escaso reformado', 'Nuevos equipamientos en el entorno'],
      summary: 'Pisos amplios para reforma integral en un barrio con precio inferior a sus colindantes; plazo y presupuesto de obra más exigentes.',
      narrative: [
        'Benicalap ofrece en la muestra demo pisos amplios con precio por m² inferior a barrios colindantes. La oferta de producto familiar reformado es escasa.',
        'La reforma integral alarga el plazo y aumenta el riesgo de desviaciones; el escenario base es más largo que en otras tesis.'
      ],
      indicators: [
        { label: 'Precio de oferta', value: '2.050 €/m²', note: 'Muestra demo', date: 'sep 2026' },
        { label: 'Evolución 12 meses', value: '+7,6 %', note: 'Precio de oferta', date: 'sep 2026' },
        { label: 'Días en publicación', value: '64 días', note: 'Mediana', date: 'oct 2026' }
      ],
      compare: { micro: [2050, 7.6, 20.3, 64], muni: [2390, 8.2, 22.1, 58], prov: [1810, 6.9, 18.4, 71] },
      opp: ['Precio inferior a barrios colindantes', 'Escasez de producto familiar reformado', 'Equipamientos en mejora'],
      risks: ['Reforma integral con mayor riesgo de desviación', 'Plazo más largo', 'Ticket mínimo y coste total más altos'],
      operations: [], listings: ['B-501']
    }
  ];

  const listings = {
    'M-101': { id: 'M-101', thesis: 'T-01', zone: 'La Flota · sector norte (aprox.)', m2: 74, rooms: 2, price: 99000, state: 'Para reformar', updated: '16 oct 2026', status: 'En evaluación', source: 'Idealista' },
    'M-102': { id: 'M-102', thesis: 'T-01', zone: 'La Flota · sector central (aprox.)', m2: 78, rooms: 2, price: 104000, state: 'Para reformar', updated: '12 oct 2026', status: 'Operación abierta', source: 'Fotocasa', op: 'O-102' },
    'M-103': { id: 'M-103', thesis: 'T-01', zone: 'La Flota · sector sur (aprox.)', m2: 69, rooms: 2, price: 112000, state: 'Reforma parcial', updated: '3 oct 2026', status: 'Descartada', source: 'Idealista', note: 'Coste estructural estimado por encima de la tesis' },
    'E-111': { id: 'E-111', thesis: 'T-02', zone: 'El Carmen · junto a Alameda (aprox.)', m2: 58, rooms: 2, price: 76000, state: 'Para reformar', updated: '15 oct 2026', status: 'En evaluación', source: 'Fotocasa' },
    'E-112': { id: 'E-112', thesis: 'T-02', zone: 'El Carmen · sector oeste (aprox.)', m2: 49, rooms: 1, price: 64500, state: 'Para reformar', updated: '9 oct 2026', status: 'Anuncio externo', source: 'Idealista' },
    'A-201': { id: 'A-201', thesis: 'T-03', zone: 'Centro · entorno peatonal (aprox.)', m2: 92, rooms: 3, price: 109000, state: 'Acabados antiguos', updated: '13 oct 2026', status: 'Anuncio externo', source: 'Idealista' },
    'A-202': { id: 'A-202', thesis: 'T-03', zone: 'Centro · sector este (aprox.)', m2: 84, rooms: 2, price: 98500, state: 'Acabados antiguos', updated: '11 oct 2026', status: 'En evaluación', source: 'Fotocasa' },
    'A-205': { id: 'A-205', thesis: 'T-03', zone: 'Centro · sector norte (aprox.)', m2: 88, rooms: 3, price: 99000, state: 'En reforma', updated: '2 oct 2026', status: 'Operación en curso', source: 'Idealista', op: 'O-201' },
    'N-301': { id: 'N-301', thesis: 'T-04', zone: 'Ensanche · sector central (aprox.)', m2: 98, rooms: 3, price: 139000, state: 'Buen estado', updated: '10 oct 2026', status: 'Anuncio externo', source: 'Idealista' },
    'P-401': { id: 'P-401', thesis: 'T-05', zone: 'Patraix · entorno plaza (aprox.)', m2: 72, rooms: 2, price: 149000, state: 'Para reformar', updated: '16 oct 2026', status: 'En evaluación', source: 'Idealista' },
    'P-402': { id: 'P-402', thesis: 'T-05', zone: 'Patraix · sector sur (aprox.)', m2: 66, rooms: 2, price: 141000, state: 'Para reformar', updated: '12 oct 2026', status: 'Anuncio externo', source: 'Fotocasa' },
    'P-403': { id: 'P-403', thesis: 'T-05', zone: 'Patraix · sector norte (aprox.)', m2: 70, rooms: 2, price: 146000, state: 'Para reformar', updated: '28 sep 2026', status: 'Descartada', source: 'Fotocasa', op: 'O-501', note: 'Operación cancelada: el propietario retiró el inmueble' },
    'B-501': { id: 'B-501', thesis: 'T-06', zone: 'Benicalap · sector este (aprox.)', m2: 92, rooms: 3, price: 158000, state: 'Para reformar', updated: '14 oct 2026', status: 'Anuncio externo', source: 'Fotocasa' }
  };

  const operations = {
    'O-102': {
      id: 'O-102', thesis: 'T-01', listing: 'M-102', title: 'Piso de 2 hab. · La Flota, Murcia', status: 'captando',
      features: [['Superficie', '78 m² construidos'], ['Dormitorios', '2'], ['Baños', '1'], ['Planta', '3ª con ascensor'], ['Año', '1978'], ['Estado', 'Para reformar']],
      budget: [['Compra (precio acordado demo)', 98000], ['Impuestos y gastos de adquisición', 8800], ['Reforma', 16500], ['Contingencia', 2500], ['Honorarios de gestión de la plataforma', 3200], ['Mantenimiento durante la operación', 1000], ['Costes de venta', 2000]],
      total: 132000, confirmed: 79200, commitments: 8, min: 5000, max: 25000, closeDate: '15 nov 2026',
      scenarios: [{ k: 'Pesimista', sale: 140000, months: 18 }, { k: 'Base', sale: 155000, months: 14 }, { k: 'Optimista', sale: 163000, months: 11 }],
      docs: [['Nota simple', 'Disponible (demo)'], ['Informe técnico preliminar', 'Disponible (demo)'], ['Presupuesto de reforma · 2 ofertas', 'Disponible (demo)'], ['Tasación previa', 'Pendiente'], ['Términos de participación', 'Pendiente de definición jurídica']],
      valuations: { 5: [141000, 'Tasación demo tras reforma'], 7: [152000, 'Oferta aceptada (demo)'] }
    },
    'O-201': {
      id: 'O-201', thesis: 'T-03', listing: 'A-205', title: 'Piso de 3 hab. · Centro, Albacete', status: 'cerrada',
      features: [['Superficie', '88 m² construidos'], ['Dormitorios', '3'], ['Baños', '2'], ['Planta', '2ª con ascensor'], ['Año', '1984'], ['Estado', 'En reforma']],
      budget: [['Compra (precio acordado demo)', 93500], ['Impuestos y gastos de adquisición', 8400], ['Reforma de acabados', 15200], ['Contingencia', 2300], ['Honorarios de gestión de la plataforma', 3100], ['Mantenimiento durante la operación', 1500], ['Costes de venta', 2000]],
      total: 126000, confirmed: 126000, commitments: 11, min: 5000, max: 25000, closeDate: '30 may 2026',
      scenarios: [{ k: 'Pesimista', sale: 132000, months: 16 }, { k: 'Base', sale: 145000, months: 12 }, { k: 'Optimista', sale: 150000, months: 10 }],
      docs: [['Escritura de compraventa', 'Disponible (demo)'], ['Licencia de obra', 'Disponible (demo)'], ['Informe de obra · semana 6', 'Disponible (demo)']],
      valuations: { 5: [136000, 'Tasación demo tras reforma'], 7: [145000, 'Oferta aceptada (demo)'] }
    },
    'O-501': {
      id: 'O-501', thesis: 'T-05', listing: 'P-403', title: 'Piso de 2 hab. · Patraix, València', status: 'cancelada',
      features: [['Superficie', '70 m² construidos'], ['Dormitorios', '2'], ['Baños', '1'], ['Planta', '4ª sin ascensor'], ['Año', '1969'], ['Estado', 'Para reformar']],
      budget: [['Compra (precio previsto demo)', 140000], ['Impuestos y gastos de adquisición', 14000], ['Reforma', 11000], ['Contingencia', 1500], ['Honorarios de gestión de la plataforma', 2500], ['Mantenimiento durante la operación', 500], ['Costes de venta', 1500]],
      total: 171000, confirmed: 0, commitments: 0, min: 10000, max: 25000, closeDate: '—',
      scenarios: [{ k: 'Pesimista', sale: 178000, months: 18 }, { k: 'Base', sale: 196000, months: 14 }, { k: 'Optimista', sale: 204000, months: 12 }],
      docs: [['Comunicación de cancelación', 'Disponible (demo)']],
      cancelReason: 'El propietario retiró el inmueble antes de la firma de arras. Los compromisos registrados se liberaron sin cargo (demo).',
      valuations: {}
    }
  };

  const stages = [
    { k: 'Documentación y firma', d: 0, ev: 'Documentación de participación (demo)' },
    { k: 'Financiación confirmada', d: 3, ev: 'Confirmación de captación completa' },
    { k: 'Adquisición formalizada', d: 30, ev: 'Escritura de compraventa (demo)' },
    { k: 'Proyecto en preparación', d: 45, ev: 'Proyecto y licencia de obra (demo)' },
    { k: 'Reforma en curso', d: 75, ev: 'Fotos de obra · informe semanal' },
    { k: 'Reforma terminada', d: 180, ev: 'Certificado fin de obra · tasación demo' },
    { k: 'En comercialización', d: 195, ev: 'Anuncio publicado · visitas registradas' },
    { k: 'Oferta aceptada', d: 270, ev: 'Oferta firmada (demo)' },
    { k: 'Venta formalizada', d: 300, ev: 'Escritura de venta (demo)' },
    { k: 'Liquidación en proceso', d: 315, ev: 'Liquidación detallada (demo)' },
    { k: 'Capital y resultado abonados', d: 330, ev: 'Justificante de transferencia (simulado)' }
  ];

  const profiles = {
    marina: { key: 'marina', name: 'Juan Pedro', label: 'Juan Pedro — moderado', goals: ['Crecimiento de capital'], expRE: 'Algo', expInv: 'Algo', income: '30.000–50.000 €', capital: '10.000–25.000 €', ticket: 10000, freq: '1 al año', loss: 'Media', pref: 'Equilibrio', horizon: '12–18', locations: ['Región de Murcia', 'Castilla-La Mancha'], strategies: ['reforma'] },
    alex: { key: 'alex', name: 'Jose Carlos', label: 'Jose Carlos — diversificación', goals: ['Diversificación'], expRE: 'Amplia', expInv: 'Amplia', income: 'Más de 70.000 €', capital: '25.000–50.000 €', ticket: 25000, freq: '2–3 al año', loss: 'Alta', pref: 'Mayor riesgo', horizon: '18–36+', locations: ['Toda España'], strategies: ['reforma', 'compraventa'] }
  };

  const horizonRange = { '6–12': [6, 12], '12–18': [12, 18], '18–36+': [18, 36] };
  const riskAdj = { Prudencia: { Moderado: 6, Medio: 0, 'Medio-alto': -8 }, Equilibrio: { Moderado: 4, Medio: 6, 'Medio-alto': -2 }, 'Mayor riesgo': { Moderado: 0, Medio: 4, 'Medio-alto': 6 } };

  function fit(t, p) {
    let s = 35;
    const locs = p.locations || [];
    if (locs.includes(t.region)) s += 24; else if (locs.includes('Toda España')) s += 16;
    s += t.minTicket <= (p.ticket || 0) ? 10 : -10;
    const [a, b] = horizonRange[p.horizon] || [12, 18];
    if (t.termMin >= a && t.termMax <= b) s += 12; else if (t.termMax >= a && t.termMin <= b) s += 6;
    if ((p.strategies || []).includes(t.strategyKey)) s += 10;
    s += (riskAdj[p.pref] || riskAdj.Equilibrio)[t.risk] || 0;
    return Math.max(30, Math.min(96, s));
  }

  function fitReasons(t, p) {
    const r = [];
    const locs = p.locations || [];
    if (locs.includes(t.region)) r.push('Está en una zona que has marcado como preferida'); else if (locs.includes('Toda España')) r.push('Has indicado interés en toda España');
    else r.push('Está fuera de tus zonas preferidas');
    r.push(t.minTicket <= p.ticket ? 'El mínimo orientativo encaja con tu ticket' : 'El mínimo orientativo supera tu ticket preferido');
    const [a, b] = horizonRange[p.horizon] || [12, 18];
    r.push(t.termMax <= b && t.termMin >= a ? 'El plazo del escenario base encaja con tu horizonte' : 'El plazo solo encaja parcialmente con tu horizonte');
    return r;
  }

  const activity = [
    { id: 'a1', date: '17 oct 2026', type: 'Nueva vivienda compatible', entity: 'T-01 · La Flota, Murcia', text: 'M-101 (74 m², 2 hab.) cumple los criterios de la tesis y está en evaluación.', kind: 'Detectado por el modelo', cta: 'Ver tesis', go: ['thesis', 'T-01'], action: false, cat: 'Tesis', profiles: ['marina', 'alex'] },
    { id: 'a2', date: '15 oct 2026', type: 'Operación publicada', entity: 'O-102 · La Flota, Murcia', text: 'Se ha publicado una operación concreta asociada a la tesis T-01, con presupuesto y términos de captación.', kind: 'Confirmado', cta: 'Ver operación', go: ['operation', 'O-102'], action: true, cat: 'Operaciones', profiles: ['marina', 'alex'] },
    { id: 'a3', date: '14 oct 2026', type: 'Financiación actualizada', entity: 'O-102 · La Flota, Murcia', text: 'La operación alcanza un 60 % de financiación confirmada (8 compromisos verificados).', kind: 'Confirmado', cta: 'Ver operación', go: ['operation', 'O-102'], action: false, cat: 'Operaciones', profiles: ['marina', 'alex'] },
    { id: 'a4', date: '10 oct 2026', type: 'Retraso/incidencia', entity: 'O-201 · Centro, Albacete', text: 'La entrega de carpintería se retrasa unas 3 semanas. El plazo base pasa de 12 a 13 meses.', kind: 'Confirmado', cta: 'Ver inversión', go: ['investment', 'INV-O-201'], action: false, cat: 'Inversiones', profiles: ['alex'] },
    { id: 'a5', date: '2 oct 2026', type: 'Precio de venta revisado', entity: 'T-05 · Patraix, València', text: 'El modelo revisa el rango de venta del escenario base tras actualizar comparables. Es una estimación, no una tasación.', kind: 'Estimación del modelo', cta: 'Ver tesis', go: ['thesis', 'T-05'], action: false, cat: 'Tesis', profiles: ['alex'] },
    { id: 'a6', date: '28 sep 2026', type: 'Operación cancelada', entity: 'O-501 · Patraix, València', text: 'El propietario retiró el inmueble. Los compromisos registrados se liberaron sin cargo.', kind: 'Confirmado', cta: 'Ver operación', go: ['operation', 'O-501'], action: false, cat: 'Operaciones', profiles: ['alex'] }
  ];

  function trendSeries(t) {
    const end = t.compare.micro[0], endM = t.compare.muni[0];
    const g = t.compare.micro[2] / 100, gm = t.compare.muni[2] / 100;
    const pts = [];
    for (let i = 0; i <= 12; i++) {
      const f = i / 12;
      const w = Math.sin(i * 1.7 + t.attract) * 0.006;
      pts.push([end / (1 + g) * (1 + g * Math.pow(f, 1.1)) * (1 + w), endM / (1 + gm) * (1 + gm * f) * (1 - w / 2)]);
    }
    return pts;
  }

  window.REALINV = { UPDATED, barrios, cities, theses, listings, operations, stages, profiles, activity, fit, fitReasons, horizonRange, trendSeries, fmtEUR, fmtNum, fmtPct };
})();
