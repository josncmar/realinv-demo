/* RealInv V1 — lógica de la app (acciones y helpers). Se instala sobre el componente. */
(function () {
  const MONTHS = ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic'];
  const STEPS = [['goals', 'expRE', 'expInv'], ['income', 'capital', 'ticket', 'freq'], ['loss', 'pref', 'horizon'], ['locations', 'strategies']];
  const KEEP = ['route', 'howBack', 'authStep', 'email', 'userName', 'onbStep', 'draft', 'answers', 'profileKey', 'thesisId', 'operationId', 'investmentId', 'origin', 'trail', 'discoverMode', 'f', 'sort', 'saved', 'interests', 'intents', 'investments', 'extra', 'bump', 'readIds', 'listTab', 'listSort', 'ecoTicket', 'opTicket', 'profileTab', 'pfTab', 'actFilter', 'range', 'notif'];

  const M = {
    initState() {
      const base = {
        route: 'welcome', howBack: 'welcome', authStep: 'form', email: '', pwd: '', consent: false, authErr: '', code: '', userName: 'Marina',
        onbStep: 0, onbErr: '', draft: this.emptyDraft(), answers: null, profileKey: 'marina',
        thesisId: 'T-01', operationId: 'O-102', investmentId: null, origin: 'foryou', trail: null, mapFocus: '',
        discoverMode: 'map', f: this.emptyF(), sort: 'Mejor encaje',
        saved: [], interests: {}, intents: {}, investments: [], extra: [], bump: {}, readIds: [],
        listTab: 'Todas', listSort: 'Actualización', ecoTicket: 10000, opTicket: 10000, showMethod: false, showCalc: false,
        pfTab: 'Todas', profileTab: 'inv', actFilter: 'Todas', range: 'Todo', notif: { viviendas: true, operaciones: true, hitos: true, resumen: false }
      };
      let saved = null;
      try { saved = JSON.parse(localStorage.getItem('realinv-app-v2') || 'null'); } catch (e) {}
      if (saved && saved.userName) saved.userName = saved.userName.replace('José', 'Jose');
      return Object.assign(base, saved || {}, { modal: null, loading: false, error: false, q: '', demoOpen: false, toast: '', vw: window.innerWidth, booted: true });
    },
    emptyDraft() { return { goals: [], expRE: null, expInv: null, income: null, capital: null, ticket: null, freq: null, loss: null, pref: null, horizon: null, locations: [], strategies: [] }; },
    emptyF() { return { loc: 'Todas', strat: 'Todas', ticket: 'Cualquiera', hor: 'Cualquiera', risk: 'Cualquiera' }; },
    _didUpdate(pp, ps) {
      const s = this.state; if (!s.booted) return;
      const o = {}; KEEP.forEach(k => { o[k] = s[k]; });
      try { localStorage.setItem('realinv-app-v2', JSON.stringify(o)); } catch (e) {}
      const key = s.route + '|' + s.thesisId + '|' + s.operationId + '|' + s.investmentId; if (this._lastKey !== key) { this._lastKey = key; const m = this.mainRef && this.mainRef.current; if (m) m.scrollTop = 0; }
    },

    fd(d) { return d.getDate() + ' ' + MONTHS[d.getMonth()] + ' ' + d.getFullYear(); },
    addDays(iso, n) { const p = iso.split('-').map(Number); const d = new Date(p[0], p[1] - 1, p[2]); d.setDate(d.getDate() + n); return d; },
    parseDate(str) { const p = str.split(' '); return new Date(+p[2], MONTHS.indexOf(p[1]), +p[0]); },
    eur(n) { return window.REALINV.fmtEUR(n); },
    pc(n, d) { return n.toFixed(d == null ? 1 : d).replace('.', ',') + ' %'; },
    sgn(n) { return (n > 0.5 ? '+' : n < -0.5 ? '−' : '') + this.eur(Math.abs(n)); },
    sel(value, options, onChange, label) {
      return React.createElement('select', { value, 'aria-label': label, onChange: e => onChange(e.target.value), style: { border: 0, background: 'transparent', fontFamily: 'inherit', fontSize: 13, fontWeight: 500, color: '#2d3139', height: 34, cursor: 'pointer', paddingRight: 4, outline: 'none', fieldSizing: 'content', maxWidth: 150 } },
        options.map(o => React.createElement('option', { key: o, value: o }, o)));
    },

    go(route, extra) {
      const patch = Object.assign({ route, q: '', demoOpen: false, modal: null }, extra || {});
      if (route === 'discover' && !(extra && extra.discoverMode)) { patch.discoverMode = 'map'; patch.mapFocus = ''; }
      if (route === 'activity') patch.readIds = this.activityItems().map(a => a.id);
      this.setState(patch);
    },
    openThesis(id, origin, trail) { this.go('thesis', { thesisId: id, origin: origin || 'foryou', trail: trail || null, listTab: 'Todas', showMethod: false }); },
    toast(msg) { clearTimeout(this._tt); this.setState({ toast: msg }); this._tt = setTimeout(() => this.setState({ toast: '' }), 2800); },
    simulateLoad() { clearTimeout(this._lt); this.setState({ loading: true }); this._lt = setTimeout(() => this.setState({ loading: false }), 900); },
    activityItems() { const s = this.state, D = window.REALINV; return (s.extra || []).concat(D.activity.filter(a => a.profiles.includes(s.profileKey))); },

    seed(key) {
      const p = window.REALINV.profiles[key];
      const b = { profileKey: key, userName: p.name, answers: Object.assign({}, p), saved: [], interests: {}, intents: {}, investments: [], extra: [], bump: {}, readIds: [] };
      b.interests = Object.assign({}, window.RealInvPortfolio.USERS[key].opportunities);
      return b;
    },
    switchProfile(key) {
      const s = this.state; const patch = Object.assign(this.seed(key), { demoOpen: false });
      if (['investment', 'operation', 'thesis'].includes(s.route)) patch.route = 'home';
      this.setState(patch); this.simulateLoad(); this.toast('Perfil de demostración: ' + window.REALINV.profiles[key].label);
    },
    resetDemo() {
      try { localStorage.removeItem('realinv-map-v1'); } catch (e) {}
      this.setState(Object.assign(this.seed('marina'), { route: 'welcome', authStep: 'form', email: '', pwd: '', consent: false, code: '', authErr: '', onbStep: 0, draft: this.emptyDraft(), answers: null, demoOpen: false, discoverMode: 'map', error: false, f: this.emptyF() }));
    },

    groups() {
      return {
        goals: { t: '¿Qué buscas?', multi: true, opts: ['Crecimiento de capital', 'Diversificación', 'Conocer oportunidades'] },
        expRE: { t: 'Experiencia en inversión inmobiliaria', opts: ['Ninguna', 'Algo', 'Amplia'] },
        expInv: { t: 'Experiencia con otras inversiones', opts: ['Ninguna', 'Algo', 'Amplia'] },
        income: { t: 'Ingresos anuales orientativos', s: 'Opcional. Ajusta sugerencias; no determina tu idoneidad.', optional: true, opts: ['Menos de 30.000 €', '30.000–50.000 €', '50.000–70.000 €', 'Más de 70.000 €', 'Prefiero no decirlo'] },
        capital: { t: 'Capital total que destinarías', opts: ['Menos de 10.000 €', '10.000–25.000 €', '25.000–50.000 €', 'Más de 50.000 €'] },
        ticket: { t: 'Ticket preferido por operación', opts: [['2.500 €', 2500], ['5.000 €', 5000], ['10.000 €', 10000], ['25.000 €', 25000]] },
        freq: { t: 'Frecuencia prevista', opts: ['1 al año', '2–3 al año', 'Más de 3 al año'] },
        loss: { t: 'Tolerancia a pérdidas', s: 'Una operación inmobiliaria puede perder parte o todo el capital aportado.', opts: ['Baja', 'Media', 'Alta'] },
        pref: { t: 'Preferencia general', opts: ['Prudencia', 'Equilibrio', 'Mayor riesgo'] },
        horizon: { t: '¿Cuánto tiempo podrías inmovilizar el dinero?', opts: [['6–12 meses', '6–12'], ['12–18 meses', '12–18'], ['18–36+ meses', '18–36+']] },
        locations: { t: 'Zonas preferidas', s: 'Elige varias o toda España.', multi: true, opts: ['Toda España', 'Región de Murcia', 'Castilla-La Mancha', 'Comunitat Valenciana', 'Comunidad de Madrid', 'Andalucía'] },
        strategies: { t: 'Estrategias', multi: true, opts: [['Compraventa directa', 'compraventa'], ['Reforma y venta', 'reforma'], ['Cambio de uso', 'uso', true], ['Promociones', 'promo', true]] }
      };
    },
    groupView(key, obj, target) {
      const G = this.groups()[key]; const cur = obj ? obj[key] : null;
      return { key, t: G.t, s: G.s || '', hasS: !!G.s, opts: G.opts.map(o => {
        const a = Array.isArray(o) ? o : [o, o, false]; const label = a[0], val = a[1], soon = !!a[2];
        const sel = G.multi ? (cur || []).includes(val) : cur === val;
        return { label, sel, soon, bg: sel ? '#2d3139' : '#fff', fg: sel ? '#fff' : (soon ? 'rgba(45,49,57,0.4)' : '#2d3139'), bd: sel ? '#2d3139' : 'rgba(0,0,0,0.12)', pick: soon ? () => this.toast('Esta estrategia estará disponible próximamente') : () => this.pickOpt(target, key, val) };
      }) };
    },
    pickOpt(target, key, val) {
      const D = window.REALINV;
      this.setState(s => {
        const G = this.groups()[key];
        const obj = Object.assign({}, s[target] || D.profiles[s.profileKey]);
        if (G.multi) {
          let arr = (obj[key] || []).slice();
          if (arr.includes(val)) arr = arr.filter(x => x !== val);
          else if (key === 'locations' && val === 'Toda España') arr = ['Toda España'];
          else { if (key === 'locations') arr = arr.filter(x => x !== 'Toda España'); arr.push(val); }
          obj[key] = arr;
        } else obj[key] = val;
        return { [target]: obj, onbErr: '' };
      });
      if (target === 'answers') this.toast('Preferencias guardadas · recomendaciones actualizadas');
    },
    stepValid(i, d) { const G = this.groups(); return STEPS[i].every(k => G[k].optional || (G[k].multi ? (d[k] || []).length > 0 : d[k] != null)); },
    onbNext() {
      const s = this.state;
      if (s.onbStep < 4) { if (!this.stepValid(s.onbStep, s.draft)) { this.setState({ onbErr: 'Responde cada pregunta para continuar.' }); return; } this.setState({ onbStep: s.onbStep + 1, onbErr: '' }); }
      else this.finishOnb();
    },
    onbBack() { const s = this.state; if (s.onbStep > 0) this.setState({ onbStep: s.onbStep - 1, onbErr: '' }); else this.setState({ route: 'auth' }); },
    fillPreset(key) { const p = window.REALINV.profiles[key]; this.setState({ draft: Object.assign({}, p), profileKey: key, userName: p.name, onbStep: 4, onbErr: '' }); },
    finishOnb() { const s = this.state; this.setState(Object.assign(this.seed(s.profileKey), { answers: Object.assign({}, s.draft), userName: s.userName, route: 'discover', discoverMode: 'foryou', origin: 'foryou' })); this.simulateLoad(); },
    onbVals() {
      const s = this.state, dr = s.draft || this.emptyDraft();
      const names = ['Objetivo', 'Capacidad', 'Riesgo', 'Zonas', 'Revisión'];
      const T = [['Paso 1 · Objetivo', '¿Qué te mueve?', 'Cuéntanos qué buscas. Lo usaremos para elegir qué mostrarte primero.'], ['Paso 2 · Capacidad', 'A tu medida.', 'Importes orientativos. No pedimos justificantes para explorar.'], ['Paso 3 · Riesgo y horizonte', 'Tu ritmo.', 'La inversión inmobiliaria es ilíquida hasta la venta y puede perder capital.'], ['Paso 4 · Zonas y estrategia', 'Dónde y cómo.', 'Elige comunidades o toda España, y las estrategias que te interesan.'], ['Paso 5 · Revisión', 'Tu perfil, en claro.', 'Revisa tus respuestas antes de ver tus oportunidades.']];
      const st = Math.min(4, s.onbStep);
      const strat = { compraventa: 'Compraventa directa', reforma: 'Reforma y venta' };
      const v = x => (x == null || (Array.isArray(x) && !x.length)) ? '—' : x;
      const prefName = dr.pref === 'Prudencia' ? 'Prudente' : dr.pref === 'Mayor riesgo' ? 'Dinámico' : 'Equilibrado';
      return {
        n: st + 1, pctW: ((st + 1) / 5 * 100) + '%', eyebrow: T[st][0], title: T[st][1], sub: T[st][2], isQuestions: st < 4, isSummary: st === 4,
        groups: st < 4 ? STEPS[st].map(k => this.groupView(k, dr, 'draft')) : [],
        steps: names.map((l, i) => ({ label: l })),
        nextLabel: st === 4 ? 'Ver mis oportunidades' : 'Continuar',
        profileName: prefName + ', ' + ((dr.strategies || []).includes('reforma') ? 'orientado a reforma y venta' : 'orientado a compraventa'),
        profileText: 'Buscas ' + v((dr.goals || []).join(' y ')).toLowerCase() + ' con un ticket orientativo de ' + (dr.ticket ? this.eur(dr.ticket) : '—') + ', un horizonte de ' + v(dr.horizon) + ' meses y foco en ' + v((dr.locations || []).join(', ')) + '. Verás primero las tesis con mínimos y plazos compatibles.',
        summary: [['Objetivo', v((dr.goals || []).join(', '))], ['Experiencia', 'Inmobiliaria: ' + v(dr.expRE) + ' · Inversiones: ' + v(dr.expInv)], ['Capital total', v(dr.capital)], ['Ticket preferido', dr.ticket ? this.eur(dr.ticket) : '—'], ['Frecuencia', v(dr.freq)], ['Riesgo', v(dr.pref) + ' · tolerancia ' + v(dr.loss).toString().toLowerCase()], ['Horizonte', v(dr.horizon) + ' meses'], ['Zonas', v((dr.locations || []).join(', '))], ['Estrategias', v((dr.strategies || []).map(x => strat[x] || x).join(', '))]].map(x => ({ k: x[0], v: x[1] }))
      };
    },

    authSubmit() {
      const s = this.state;
      if (!/^\S+@\S+\.\S+$/.test(s.email)) return this.setState({ authErr: 'Introduce un correo válido.' });
      if ((s.pwd || '').length < 8) return this.setState({ authErr: 'La contraseña necesita al menos 8 caracteres.' });
      if (!s.consent) return this.setState({ authErr: 'Acepta la información de privacidad para continuar.' });
      const nm = s.email.split('@')[0].split(/[._-]/)[0];
      this.setState({ authStep: 'verify', authErr: '', userName: nm.charAt(0).toUpperCase() + nm.slice(1) });
    },
    verify() { if ((this.state.code || '').replace(/\D/g, '').length !== 6) return this.setState({ authErr: 'Introduce los 6 dígitos.' }); this.setState({ route: 'onboarding', onbStep: 0, draft: this.emptyDraft(), authErr: '' }); },
    login() { this.setState({ route: 'auth', authStep: 'login', authErr: '', email: '', pwd: '' }); },
    doLogin() {
      const s = this.state, U = window.RealInvPortfolio.USERS, u = (s.email || '').trim().toLowerCase();
      const key = Object.keys(U).find(k => U[k].user === u && U[k].password === s.pwd);
      if (!key) return this.setState({ authErr: 'Usuario o contraseña incorrectos.' });
      this.setState(Object.assign(this.seed(key), { route: 'home', authErr: '', pwd: '' }));
    },

    toggleSave(id) { const on = this.state.saved.includes(id); this.setState(s => ({ saved: on ? s.saved.filter(x => x !== id) : s.saved.concat(id) })); this.toast(on ? 'Tesis eliminada de guardadas' : 'Tesis guardada · aparece en Oportunidades que sigo'); },
    setModal(p) { this.setState(s => ({ modal: Object.assign({}, s.modal, p) })); },
    openInterest(id) { const s = this.state; const A = s.answers || window.REALINV.profiles[s.profileKey]; const cur = s.interests[id]; const amt = cur || A.ticket || 10000; const std = [5000, 10000, 25000].includes(amt); this.setState({ modal: { type: 'interest', id, amount: std ? amt : 'custom', custom: std ? '' : String(amt), notify: true, done: false, err: '', edit: !!cur } }); },
    confirmInterest() {
      const m = this.state.modal; let amt = m.amount;
      if (amt === 'custom') { amt = parseInt(String(m.custom).replace(/\D/g, ''), 10); if (!amt || amt < 500) { this.setModal({ err: 'Introduce un importe orientativo de al menos 500 €.' }); return; } }
      const t = window.REALINV.theses.find(x => x.id === m.id);
      this.setState(s => {
        const had = !!s.interests[m.id];
        return {
          interests: Object.assign({}, s.interests, { [m.id]: amt }),
          bump: had ? s.bump : Object.assign({}, s.bump, { [m.id]: (s.bump[m.id] || 0) + 1 }),
          modal: Object.assign({}, s.modal, { done: true, finalAmt: amt }),
          extra: had ? s.extra : [{ id: 'x' + Date.now(), date: '18 oct 2026', type: 'Interés registrado', entity: m.id + ' · ' + t.name + ', ' + t.city, text: 'Importe orientativo de ' + this.eur(amt) + '. No se ha realizado ningún cargo ni asumido compromiso.', kind: 'Confirmado', go: ['thesis', m.id], action: false, cat: 'Tesis' }].concat(s.extra)
        };
      });
    },
    unfollow(id) { this.setState(s => { const i = Object.assign({}, s.interests); delete i[id]; return { interests: i, bump: Object.assign({}, s.bump, { [id]: Math.max(0, (s.bump[id] || 0) - 1) }) }; }); this.toast('Has dejado de seguir esta tesis'); },

    openPart(opId) { const s = this.state; const prev = s.intents[opId]; this.setState({ modal: { type: 'part', op: opId, step: 0, ticket: prev ? prev.ticket : s.opTicket, checks: [false, false, false, false], verify: 'idle' } }); },
    closeModal() {
      const m = this.state.modal;
      if (m && m.type === 'part' && m.step > 0 && m.step < 4) { this.setState(s => ({ modal: null, intents: Object.assign({}, s.intents, { [m.op]: { ticket: m.ticket, status: 'abandoned' } }) })); this.toast('Proceso guardado sin completar. Puedes retomarlo cuando quieras.'); }
      else this.setState({ modal: null });
    },
    confirmIntent() {
      const m = this.state.modal; const o = window.REALINV.operations[m.op];
      this.setState(s => ({
        intents: Object.assign({}, s.intents, { [m.op]: { ticket: m.ticket, status: 'pending' } }),
        modal: Object.assign({}, s.modal, { step: 4 }),
        extra: [{ id: 'x' + Date.now(), date: '18 oct 2026', type: 'Documentación pendiente', entity: o.id + ' · ' + o.title, text: 'Intención de participar confirmada por ' + this.eur(m.ticket) + '. Falta la formalización. No se ha realizado ningún cargo.', kind: 'Simulación demo', go: ['operation', o.id], action: true, cat: 'Operaciones' }].concat(s.extra)
      }));
    },
    formalize(opId) {
      const s = this.state, it = s.intents[opId]; if (!it) return; const o = window.REALINV.operations[opId];
      this.setState(st => ({
        intents: Object.assign({}, st.intents, { [opId]: Object.assign({}, it, { status: 'formalized' }) }),
        investments: st.investments.concat([{ id: 'INV-' + opId, op: opId, ticket: it.ticket, stage: 1, start: '2026-10-18', added: true, incident: false }]),
        extra: [{ id: 'x' + Date.now(), date: '18 oct 2026', type: 'Financiación confirmada', entity: o.id + ' · ' + o.title, text: 'Formalización simulada por ' + this.eur(it.ticket) + '. La posición aparece en Mis inversiones, pendiente de adquisición.', kind: 'Simulación demo', go: ['investment', 'INV-' + opId], action: false, cat: 'Inversiones' }].concat(st.extra)
      }));
      this.toast('Formalización simulada · nueva posición en Mis inversiones');
    },
    stageMove(id, d) {
      const D = window.REALINV;
      const EV = { 2: 'Compra formalizada', 5: 'Reforma completada', 6: 'En comercialización', 7: 'Oferta recibida', 8: 'Venta cerrada', 10: 'Transferencia realizada' };
      this.setState(s => {
        const inv = s.investments.find(i => i.id === id); if (!inv) return null;
        const ns = Math.max(1, Math.min(10, inv.stage + d)); if (ns === inv.stage) return null;
        const o = D.operations[inv.op];
        const extra = d > 0 ? [{ id: 'x' + Date.now(), date: this.fd(this.addDays(inv.start, D.stages[ns].d)), type: EV[ns] || 'Hito actualizado', entity: o.id + ' · ' + o.title, text: D.stages[ns].k + '. ' + D.stages[ns].ev + '.', kind: 'Simulación demo', go: ['investment', id], action: false, cat: 'Inversiones' }].concat(s.extra) : s.extra;
        return { investments: s.investments.map(i => i.id === id ? Object.assign({}, i, { stage: ns }) : i), extra };
      });
    },
    toggleIncident(id) { this.setState(s => ({ investments: s.investments.map(i => i.id === id ? Object.assign({}, i, { incident: !i.incident }) : i) })); },

    invPoints(inv) {
      const D = window.REALINV, o = D.operations[inv.op];
      const pts = [{ date: this.addDays(inv.start, 0), v: inv.ticket, label: null }];
      let sale = null;
      for (let i = 1; i <= inv.stage; i++) {
        const val = o.valuations[i]; let label = null;
        if (val) { sale = val[0]; label = val[1]; }
        if (i === 10) label = 'Abono simulado';
        pts.push({ date: this.addDays(inv.start, D.stages[i].d), v: sale ? inv.ticket * sale / o.total : inv.ticket, label });
      }
      return pts;
    },
    invDec(inv) {
      const D = window.REALINV, o = D.operations[inv.op], t = D.theses.find(x => x.id === o.thesis);
      const pts = this.invPoints(inv), last = pts[pts.length - 1];
      const delayed = !!inv.incident && inv.stage >= 3 && inv.stage <= 6;
      return { inv, o, t, pts, last, est: last.v, liq: inv.stage === 10, result: last.v - inv.ticket, delayed, statusLabel: (delayed ? 'Retrasada · ' : '') + D.stages[inv.stage].k };
    },
    simToday() { let t = new Date(2026, 9, 18).getTime(); this.state.investments.forEach(i => { const p = this.invPoints(i); t = Math.max(t, p[p.length - 1].date.getTime()); }); return new Date(t); },

    chart(pts, contrib, today) {
      const h = React.createElement, W = 640, H = 220, pl = 72, pr = 16, pt = 14, pb = 30;
      const t0 = pts[0].date.getTime(); let t1 = Math.max(today.getTime(), pts[pts.length - 1].date.getTime()); if (t1 - t0 < 20 * 864e5) t1 = t0 + 20 * 864e5;
      const vals = pts.map(p => p.v).concat(contrib.map(p => p.v));
      let lo = Math.min.apply(null, vals), hi = Math.max.apply(null, vals); const pad = Math.max((hi - lo) * 0.35, hi * 0.04); lo = Math.max(0, lo - pad); hi = hi + pad;
      const X = t => pl + (t - t0) / (t1 - t0) * (W - pl - pr), Y = v => pt + (hi - v) / (hi - lo) * (H - pt - pb);
      const step = arr => { let d = 'M' + X(arr[0].date.getTime()).toFixed(1) + ' ' + Y(arr[0].v).toFixed(1); for (let i = 1; i < arr.length; i++) d += ' H' + X(arr[i].date.getTime()).toFixed(1) + ' V' + Y(arr[i].v).toFixed(1); return d; };
      const d = step(pts), last = pts[pts.length - 1], lx = X(last.date.getTime());
      const els = [];
      [0, 0.5, 1].forEach((f, i) => { const v = lo + (hi - lo) * f, y = Y(v); els.push(h('line', { key: 'g' + i, x1: pl, x2: W - pr, y1: y, y2: y, stroke: 'rgba(0,0,0,0.06)' })); els.push(h('text', { key: 'gt' + i, x: 0, y: y + 4, fontSize: 11, fill: 'rgba(45,49,57,0.5)' }, this.eur(Math.round(v / 100) * 100))); });
      els.push(h('path', { key: 'area', d: d + ' H' + lx.toFixed(1) + ' V' + (H - pb) + ' H' + X(t0).toFixed(1) + ' Z', fill: 'rgba(114,217,217,0.16)' }));
      els.push(h('path', { key: 'con', d: step(contrib) + ' H' + X(t1).toFixed(1), fill: 'none', stroke: 'rgba(45,49,57,0.4)', strokeWidth: 1.5, strokeDasharray: '4 4' }));
      els.push(h('path', { key: 'line', d, fill: 'none', stroke: '#2d3139', strokeWidth: 2.2 }));
      if (t1 > last.date.getTime() + 864e5) { els.push(h('path', { key: 'ext', d: 'M' + lx.toFixed(1) + ' ' + Y(last.v).toFixed(1) + ' H' + X(t1).toFixed(1), fill: 'none', stroke: '#2d3139', strokeWidth: 2, strokeDasharray: '1 5', strokeLinecap: 'round' })); els.push(h('text', { key: 'extl', x: X(t1), y: Y(last.v) - 10, fontSize: 11, fill: 'rgba(45,49,57,0.55)', textAnchor: 'end' }, 'Sin actualización')); }
      pts.forEach((p, i) => { if (p.label) els.push(h('circle', { key: 'c' + i, cx: X(p.date.getTime()), cy: Y(p.v), r: 5, fill: '#72d9d9', stroke: '#2d3139', strokeWidth: 1.5 }, h('title', null, p.label + ' · ' + this.fd(p.date) + ' · ' + this.eur(p.v)))); });
      els.push(h('text', { key: 'x0', x: pl, y: H - 8, fontSize: 11, fill: 'rgba(45,49,57,0.5)' }, this.fd(new Date(t0))));
      els.push(h('text', { key: 'x1', x: W - pr, y: H - 8, fontSize: 11, fill: 'rgba(45,49,57,0.5)', textAnchor: 'end' }, this.fd(new Date(t1))));
      return h('svg', { viewBox: '0 0 ' + W + ' ' + H, style: { width: '100%', height: 'auto', display: 'block' }, role: 'img', 'aria-label': 'Evolución del valor estimado' }, els);
    },
    trendChart(t) {
      const s = window.REALINV.trendSeries(t), W = 600, H = 180, pl = 64, pr = 12, pt = 12, pb = 24;
      const all = [].concat.apply([], s); const mn = Math.min.apply(null, all), mx = Math.max.apply(null, all); const lo = mn * 0.97, hi = mx * 1.02;
      const X = i => pl + i / (s.length - 1) * (W - pl - pr), Y = v => pt + (hi - v) / (hi - lo) * (H - pt - pb);
      const path = k => s.map((p, i) => (i ? 'L' : 'M') + X(i).toFixed(1) + ' ' + Y(p[k]).toFixed(1)).join(' ');
      const fmt = v => window.REALINV.fmtNum(Math.round(v / 10) * 10) + ' €';
      return { micro: path(0), muni: path(1), yHi: fmt(mx), yLo: fmt(mn), yHiY: Y(mx).toFixed(1), yLoY: Y(mn).toFixed(1), yHiT: (Y(mx) + 4).toFixed(1), yLoT: (Y(mn) + 4).toFixed(1) };
    },
    eco(t, ticket) {
      const C = t.cost;
      const P = [['Compra', 0.742], ['Impuestos y gastos de adquisición', 0.067], ['Reforma', 0.125], ['Contingencia', 0.019], ['Honorarios de gestión', 0.024], ['Mantenimiento durante la operación', 0.008], ['Costes de venta', 0.015]];
      let acc = 0;
      const rows = P.map((p, i) => { const v = i === P.length - 1 ? C - acc : Math.round(C * p[1] / 100) * 100; acc += v; return { k: p[0], v: this.eur(v), w: (v / C * 100).toFixed(1) + '%' }; });
      const mult = [1.06, 1.174, 1.235], months = [t.termMax + 3, Math.round((t.termMin + t.termMax) / 2), t.termMin], names = ['Pesimista', 'Base', 'Optimista'];
      const share = ticket / C;
      const sc = mult.map((m, i) => { const sale = Math.round(C * m / 1000) * 1000, margin = sale - C, roi = margin / C, ann = Math.pow(1 + roi, 12 / months[i]) - 1; return { k: names[i], sale: this.eur(sale), margin: this.eur(margin), roi: this.pc(roi * 100), months: months[i] + ' meses', ann: this.pc(ann * 100), part: this.eur(share * margin), bg: i === 1 ? 'rgba(114,217,217,0.12)' : 'transparent', w: i === 1 ? '600' : '400' }; });
      const base = Math.round(C * 1.174 / 1000) * 1000;
      return { rows, total: this.eur(C), sc, sharePct: this.pc(share * 100, 2), ticketF: this.eur(ticket), example: 'Coste total de ' + this.eur(C) + ' y venta objetivo de ' + this.eur(base) + ' implican ' + this.eur(base - C) + ' de margen antes de otros costes de salida, comisiones e impuestos sobre el resultado.' };
    },
    opDec(id) {
      const s = this.state, D = window.REALINV, o = D.operations[id], t = D.theses.find(x => x.id === o.thesis);
      const inv = s.investments.find(i => i.op === id), intent = s.intents[id];
      const extraC = inv && inv.added ? inv.ticket : 0;
      const confirmed = o.confirmed + extraC, commitments = o.commitments + (extraC ? 1 : 0), pct = Math.round(confirmed / o.total * 100);
      const ST = { captando: ['Captando financiación', 'rgba(114,217,217,0.2)', '#1f5f64'], cerrada: ['Captación cerrada · en ejecución', 'rgba(14,150,108,0.1)', '#0b6e50'], cancelada: ['Operación cancelada', 'rgba(227,109,87,0.1)', '#a8432f'] }[o.status];
      const us = inv ? 'formalized' : intent ? intent.status : 'none';
      const tk = s.opTicket, share = tk / o.total;
      return Object.assign({}, o, {
        thesisTitle: t.title, thesisName: t.name + ', ' + t.city, thesisId: t.id, potentialF: this.eur(t.potential), commitmentsN: commitments,
        confirmedF: this.eur(confirmed), totalF: this.eur(o.total), pct, pctW: pct + '%', pctLabel: pct + ' % de financiación confirmada', commitmentsLabel: commitments + ' compromisos confirmados',
        statusLabel: ST[0], stBg: ST[1], stFg: ST[2], isCaptando: o.status === 'captando', isClosed: o.status === 'cerrada', isCancelled: o.status === 'cancelada', showBar: o.status !== 'cancelada',
        us, pending: us === 'pending', abandoned: us === 'abandoned', formalized: us === 'formalized', canPart: o.status === 'captando' && us === 'none',
        intentF: intent ? this.eur(intent.ticket) : '', invF: inv ? this.eur(inv.ticket) : '', invId: inv ? inv.id : null, minF: this.eur(o.min), maxF: this.eur(o.max),
        budgetRows: o.budget.map(b => ({ k: b[0], v: this.eur(b[1]), w: (b[1] / o.total * 100).toFixed(1) + '%' })),
        featureRows: o.features.map(f => ({ k: f[0], v: f[1] })),
        docRows: o.docs.map(d => ({ k: d[0], v: d[1], fg: d[1].indexOf('Disponible') === 0 ? '#0b6e50' : '#8a4b04' })),
        scen: o.scenarios.map(x => { const margin = x.sale - o.total, roi = margin / o.total, ann = Math.pow(1 + roi, 12 / x.months) - 1; return { k: x.k, sale: this.eur(x.sale), margin: this.eur(margin), roi: this.pc(roi * 100), months: x.months + ' meses', ann: this.pc(ann * 100), part: this.eur(share * margin), bg: x.k === 'Base' ? 'rgba(114,217,217,0.12)' : 'transparent', w: x.k === 'Base' ? '600' : '400' }; }),
        shareF: this.pc(share * 100, 2), ticketF: this.eur(tk),
        ticketOpts: [5000, 10000, 15000, 25000].map(v => ({ label: this.eur(v), bg: v === tk ? '#2d3139' : '#fff', fg: v === tk ? '#fff' : '#2d3139', bd: v === tk ? '#2d3139' : 'rgba(0,0,0,0.12)', pick: () => this.setState({ opTicket: v }) })),
        open: () => this.go('operation', { operationId: id }), img: 'op-' + id
      });
    },
    dec(t, A, origin) {
      const s = this.state; const fit = window.REALINV.fit(t, A), bump = s.bump[t.id] || 0, amt = s.interests[t.id], saved = s.saved.includes(t.id);
      return Object.assign({}, t, {
        fit, fitW: fit + '%', attractW: t.attract + '%', img: 'foto-' + t.id, loc: t.name + ' · ' + t.city,
        interestedN: t.interested + bump, interestedLabel: (t.interested + bump) + ' personas interesadas',
        potentialF: this.eur(t.potential + (bump && amt ? amt : 0)), costF: this.eur(t.cost), minF: this.eur(t.minTicket),
        saved, saveFill: saved ? 'currentColor' : 'none', saveLabel: saved ? 'Guardada' : 'Guardar',
        followed: !!amt, notFollowed: !amt, amtF: amt ? this.eur(amt) : '', demoBump: bump > 0,
        reasonsL: t.reasons.map(r => ({ r })), chipsL: t.status.map(c => ({ c })), statusMain: t.status[t.status.length - 1],
        fitLevel: fit >= 85 ? 'Encaje alto' : fit >= 65 ? 'Encaje medio' : 'Encaje bajo',
        open: () => this.openThesis(t.id, origin), toggleSave: (e) => { if (e && e.stopPropagation) e.stopPropagation(); this.toggleSave(t.id); }
      });
    }
  };

  window.RealInvApp = {
    install(c) {
      Object.keys(M).forEach(k => { c[k] = M[k].bind(c); });
      c._rs = () => c.setState({ vw: window.innerWidth });
      window.addEventListener('resize', c._rs);
      c._msg = (e) => { const d = e.data; if (d && d.source === 'realinv-map' && d.type === 'openThesis') c.openThesis(d.id, 'map', d.trail); };
      window.addEventListener('message', c._msg);
      c.setState(c.initState());
    },
    uninstall(c) { window.removeEventListener('resize', c._rs); window.removeEventListener('message', c._msg); }
  };
})();
