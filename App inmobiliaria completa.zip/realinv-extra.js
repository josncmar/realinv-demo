/* RealInv V1 — ampliación del dataset demo: nuevas tesis, zonas, operaciones y actividad. Todo sintético. */
(function () {
  const R = window.REALINV; if (!R) return;
  R.cities.push(
    { id: 'madrid', name: 'Madrid', region: 'Comunidad de Madrid', c: [40.4350, -3.7040], zoom: 14, m: { eurm2: 5320, trend: 7.2 } },
    { id: 'alicante', name: 'Alicante', region: 'Comunitat Valenciana', c: [38.3452, -0.4815], zoom: 14, m: { eurm2: 2050, trend: 8.6 } }
  );
  R.barrios.find(b => b.id === 'santamaria').theses = ['T-07'];
  R.barrios.push(
    { id: 'ab-universidad', name: 'Universidad', city: 'albacete', c: [38.9775, -1.8540], r: 380, m: { attract: 72, eurm2: 1290, trend: 5.4, demand: 78, liquidity: 61 }, theses: ['T-08'] },
    { id: 'chamberi', name: 'Chamberí', city: 'madrid', c: [40.4362, -3.7037], r: 600, m: { attract: 77, eurm2: 6450, trend: 7.9, demand: 90, liquidity: 38 }, theses: ['T-09'] },
    { id: 'alc-centro', name: 'Centro', city: 'alicante', c: [38.3460, -0.4860], r: 450, m: { attract: 70, eurm2: 2180, trend: 9.1, demand: 76, liquidity: 55 }, theses: ['T-10'] }
  );
  const base = { strategy: 'Compra, reforma y venta', strategyKey: 'reforma', minTicket: 5000, risk: 'Medio', opsOpen: 0, reviewed: 0, status: ['Captando interés'], operations: [], listings: [] };
  const ind = (p, t12, n, dias, d) => [
    { label: 'Precio de oferta', value: R.fmtNum(p) + ' €/m²', note: 'Anuncios comparables · muestra demo', date: 'sep 2026' },
    { label: 'Evolución 12 meses', value: R.fmtPct(t12), note: 'Precio de oferta', date: 'sep 2026' },
    { label: 'Anuncios comparables', value: String(n), note: d, date: 'oct 2026' },
    { label: 'Días en publicación', value: dias + ' días', note: 'Mediana · proxy de liquidez', date: 'oct 2026' }
  ];
  const T = (o) => Object.assign({}, base, o);
  R.theses.push(
    T({ id: 'T-07', barrio: 'santamaria', name: 'Santa María de Gracia', city: 'Murcia', region: 'Región de Murcia', title: 'Pisos de 3 hab. para reforma integral', asset: 'Pisos de 85–100 m² · edificios de 1965–1985', cost: 148000, costRange: '135.000–160.000 €', term: '12–16 meses', termMin: 12, termMax: 16, attract: 66, interested: 29, potential: 198000, opsIdentified: 1, withAmount: 18,
      reasons: ['Producto familiar escaso reformado', 'Buena conexión con el centro', 'Precio por debajo de barrios colindantes'], summary: 'Pisos familiares amplios cerca del centro de Murcia, con poca oferta reformada y precio de entrada contenido.',
      narrative: ['Santa María de Gracia concentra pisos de tres dormitorios en edificios de los años 60 a 80 con poca oferta reformada en la muestra demo.', 'La tesis plantea reformas integrales para vender a familias que buscan cercanía al centro. El plazo es mayor por el alcance de la obra.'],
      indicators: ind(1610, 4.9, 31, 84, '3 hab. · 85–100 m²'), compare: { micro: [1610, 4.9, 13.8, 84], muni: [1580, 5.9, 15.2, 77], prov: [1290, 5.1, 13.0, 92] },
      opp: ['Escasez de pisos familiares reformados', 'Ubicación céntrica con servicios', 'Precio inferior a barrios colindantes'], risks: ['Reforma integral con mayor riesgo de desviación', 'Cobertura de datos incompleta en liquidez', 'Plazo más largo que otras tesis'],
      listings: ['S-701', 'S-702'], nextAction: 'Revisión técnica de S-701 prevista para el 28 oct' }),
    T({ id: 'T-08', barrio: 'ab-universidad', name: 'Universidad', city: 'Albacete', region: 'Castilla-La Mancha', title: 'Pisos de 2 hab. cerca del campus', strategy: 'Compraventa y mejora selectiva', strategyKey: 'compraventa', asset: 'Pisos de 60–75 m² · edificios de 1990–2005', cost: 98000, costRange: '90.000–110.000 €', minTicket: 2500, term: '9–14 meses', termMin: 9, termMax: 14, risk: 'Moderado', attract: 72, interested: 34, potential: 186000, opsIdentified: 2, opsOpen: 1, reviewed: 14, withAmount: 22, status: ['Operaciones identificadas', 'Captación abierta'],
      reasons: ['Demanda estable de estudiantes y profesorado', 'Edificios recientes con poca obra', 'Ticket de entrada bajo'], summary: 'Pisos de dos dormitorios junto al campus, en buen estado, con mejoras puntuales y demanda constante.',
      narrative: ['El entorno del campus mantiene en la muestra demo una presión de demanda alta y tiempos de publicación cortos para pisos pequeños.', 'Los edificios son recientes y solo requieren mejoras selectivas, lo que acota plazo y riesgo de obra.'],
      indicators: ind(1290, 5.4, 27, 61, '2 hab. · 60–75 m²'), compare: { micro: [1290, 5.4, 14.2, 61], muni: [1460, 4.8, 12.6, 83], prov: [1120, 4.1, 10.9, 104] },
      opp: ['Demanda estable vinculada al campus', 'Mejoras de bajo coste', 'Liquidez superior a la media municipal'], risks: ['Estacionalidad de la demanda', 'Margen moderado', 'Dependencia de un único polo de demanda'],
      operations: ['O-801'], listings: ['U-801', 'U-802'], nextAction: 'Captación abierta en O-801 hasta el 30 nov' }),
    T({ id: 'T-09', barrio: 'chamberi', name: 'Chamberí', city: 'Madrid', region: 'Comunidad de Madrid', title: 'Pisos de 1–2 hab. en finca clásica', asset: 'Pisos de 50–70 m² · fincas de 1900–1950', cost: 365000, costRange: '340.000–390.000 €', minTicket: 10000, term: '12–18 meses', termMin: 12, termMax: 18, attract: 77, interested: 58, potential: 640000, opsIdentified: 2, opsOpen: 1, reviewed: 26, withAmount: 39, status: ['Operaciones identificadas', 'Captación abierta'],
      reasons: ['Demanda muy alta y sostenida', 'Diferencial reformado en finca clásica', 'Liquidez elevada'], summary: 'Pisos pequeños en fincas clásicas de Chamberí, donde la diferencia entre reformado y sin reformar es amplia y la venta es rápida.',
      narrative: ['Chamberí combina en la muestra demo la presión de demanda más alta del dataset con tiempos de publicación muy cortos.', 'El ticket es elevado por el precio de la zona y la competencia de otros compradores puede reducir el margen.'],
      indicators: ind(6450, 7.9, 74, 38, '1–2 hab. · 50–70 m²'), compare: { micro: [6450, 7.9, 21.6, 38], muni: [5320, 7.2, 19.8, 46], prov: [4610, 6.8, 18.1, 52] },
      opp: ['Liquidez muy alta para la salida', 'Diferencial reformado amplio', 'Demanda internacional y local'], risks: ['Ticket y coste total elevados', 'Competencia en la compra', 'Licencias en fincas protegidas'],
      operations: ['O-901'], listings: ['C-901', 'C-902'], nextAction: 'O-901 al 72 % · cierre previsto el 22 nov' }),
    T({ id: 'T-10', barrio: 'alc-centro', name: 'Centro', city: 'Alicante', region: 'Comunitat Valenciana', title: 'Pisos para reventa tras mejora', strategy: 'Compraventa y mejora selectiva', strategyKey: 'compraventa', asset: 'Pisos de 75–95 m² · edificios de 1970–1990', cost: 164000, costRange: '150.000–175.000 €', term: '8–12 meses', termMin: 8, termMax: 12, risk: 'Moderado', attract: 70, interested: 27, potential: 172000, opsIdentified: 1, withAmount: 15,
      reasons: ['Evolución de precios por encima de la media', 'Plazo corto', 'Demanda nacional e internacional'], summary: 'Pisos del centro de Alicante con mejoras ligeras para reventa en plazo corto.',
      narrative: ['El centro de Alicante muestra en la muestra demo una de las evoluciones de precio de oferta más rápidas del dataset.', 'La tesis busca compras por debajo de mercado con mejoras ligeras y salida en menos de un año.'],
      indicators: ind(2180, 9.1, 46, 55, '2–3 hab. · 75–95 m²'), compare: { micro: [2180, 9.1, 25.3, 55], muni: [2050, 8.6, 23.4, 61], prov: [1840, 7.7, 20.9, 68] },
      opp: ['Evolución de precios favorable', 'Plazo corto', 'Mejoras ligeras'], risks: ['Sensibilidad a la demanda vacacional', 'Margen dependiente de la compra', 'Posible saturación de oferta reformada'],
      listings: ['L-1001'], nextAction: 'Primera operación prevista en noviembre' })
  );
  Object.assign(R.listings, {
    'S-701': { id: 'S-701', thesis: 'T-07', zone: 'Santa María de Gracia · sector norte (aprox.)', m2: 92, rooms: 3, price: 112000, state: 'Para reformar', updated: '17 oct 2026', status: 'En evaluación', source: 'Idealista' },
    'S-702': { id: 'S-702', thesis: 'T-07', zone: 'Santa María de Gracia · sector sur (aprox.)', m2: 88, rooms: 3, price: 108000, state: 'Para reformar', updated: '11 oct 2026', status: 'En evaluación', source: 'Fotocasa' },
    'U-801': { id: 'U-801', thesis: 'T-08', zone: 'Universidad · junto al campus (aprox.)', m2: 68, rooms: 2, price: 72000, state: 'Buen estado', updated: '15 oct 2026', status: 'Operación abierta', source: 'Idealista', op: 'O-801' },
    'U-802': { id: 'U-802', thesis: 'T-08', zone: 'Universidad · sector oeste (aprox.)', m2: 64, rooms: 2, price: 69500, state: 'Buen estado', updated: '9 oct 2026', status: 'En evaluación', source: 'Fotocasa' },
    'C-901': { id: 'C-901', thesis: 'T-09', zone: 'Chamberí · entorno Olavide (aprox.)', m2: 62, rooms: 2, price: 289000, state: 'Para reformar', updated: '16 oct 2026', status: 'Operación abierta', source: 'Idealista', op: 'O-901' },
    'C-902': { id: 'C-902', thesis: 'T-09', zone: 'Chamberí · sector Trafalgar (aprox.)', m2: 55, rooms: 1, price: 262000, state: 'Para reformar', updated: '12 oct 2026', status: 'En evaluación', source: 'Fotocasa' },
    'L-1001': { id: 'L-1001', thesis: 'T-10', zone: 'Alicante Centro · sector Mercado (aprox.)', m2: 84, rooms: 3, price: 121000, state: 'Reforma parcial', updated: '14 oct 2026', status: 'En evaluación', source: 'Idealista' }
  });
  Object.assign(R.operations, {
    'O-801': { id: 'O-801', thesis: 'T-08', listing: 'U-801', title: 'Piso de 2 hab. · Universidad, Albacete', status: 'captando',
      features: [['Superficie', '68 m² construidos'], ['Dormitorios', '2'], ['Baños', '1'], ['Planta', '2ª con ascensor'], ['Año', '1998'], ['Estado', 'Buen estado']],
      budget: [['Compra (precio acordado demo)', 72000], ['Impuestos y gastos de adquisición', 6500], ['Mejora selectiva', 12000], ['Contingencia', 1800], ['Honorarios de gestión de la plataforma', 2400], ['Mantenimiento durante la operación', 1300], ['Costes de venta', 2000]],
      total: 98000, confirmed: 34300, commitments: 6, min: 2500, max: 15000, closeDate: '30 nov 2026',
      scenarios: [{ k: 'Pesimista', sale: 102000, months: 14 }, { k: 'Base', sale: 113000, months: 11 }, { k: 'Optimista', sale: 118000, months: 9 }],
      docs: [['Nota simple', 'Disponible (demo)'], ['Informe técnico preliminar', 'Disponible (demo)'], ['Términos de participación', 'Pendiente de definición jurídica']], valuations: {} },
    'O-901': { id: 'O-901', thesis: 'T-09', listing: 'C-901', title: 'Piso de 2 hab. · Chamberí, Madrid', status: 'captando',
      features: [['Superficie', '62 m² construidos'], ['Dormitorios', '2'], ['Baños', '1'], ['Planta', '3ª con ascensor'], ['Año', '1928'], ['Estado', 'Para reformar']],
      budget: [['Compra (precio acordado demo)', 290000], ['Impuestos y gastos de adquisición', 23200], ['Reforma', 32000], ['Contingencia', 4800], ['Honorarios de gestión de la plataforma', 8800], ['Mantenimiento durante la operación', 2200], ['Costes de venta', 4000]],
      total: 365000, confirmed: 262800, commitments: 19, min: 10000, max: 50000, closeDate: '22 nov 2026',
      scenarios: [{ k: 'Pesimista', sale: 380000, months: 18 }, { k: 'Base', sale: 418000, months: 14 }, { k: 'Optimista', sale: 432000, months: 12 }],
      docs: [['Nota simple', 'Disponible (demo)'], ['Informe técnico preliminar', 'Disponible (demo)'], ['Presupuesto de reforma · 2 ofertas', 'Disponible (demo)'], ['Términos de participación', 'Pendiente de definición jurídica']], valuations: {} }
  });
  R.activity = [
    { id: 'm1', date: '17 oct 2026', type: 'Nueva vivienda compatible', entity: 'T-07 · Santa María de Gracia, Murcia', text: 'S-701 (92 m², 3 hab.) cumple los criterios de la tesis y está en evaluación.', kind: 'Detectado por el modelo', go: ['thesis', 'T-07'], action: false, cat: 'Tesis', profiles: ['marina'] },
    { id: 'm2', date: '15 oct 2026', type: 'Operación publicada', entity: 'O-801 · Universidad, Albacete', text: 'Hay una operación concreta en una tesis que sigues. Captación al 35 %.', kind: 'Confirmado', go: ['operation', 'O-801'], action: true, cat: 'Operaciones', profiles: ['marina'] },
    { id: 'm3', date: '28 sep 2026', type: 'Valoración actualizada', entity: 'La Flota, Murcia', text: 'Valoración intermedia de obra: tu posición se estima en 10.800 €. Estimación, no disponible para retirada.', kind: 'Confirmado', go: ['investment', 'I-M1'], action: false, cat: 'Inversiones', profiles: ['marina'] },
    { id: 'm4', date: '25 ago 2026', type: 'En comercialización', entity: 'Centro, Albacete', text: 'La vivienda reformada se ha publicado a la venta.', kind: 'Confirmado', go: ['investment', 'I-M2'], action: false, cat: 'Inversiones', profiles: ['marina'] },
    { id: 'm5', date: '4 ago 2026', type: 'Pago recibido', entity: 'El Carmen, Murcia', text: 'Se han abonado 5.750 € (capital + resultado, simulado). Operación completada.', kind: 'Simulación demo', go: ['investment', 'I-M3'], action: false, cat: 'Inversiones', profiles: ['marina'] },
    { id: 'x1', date: '16 oct 2026', type: 'Operación publicada', entity: 'O-901 · Chamberí, Madrid', text: 'Hay una operación concreta en una tesis que sigues. Captación al 72 %.', kind: 'Confirmado', go: ['operation', 'O-901'], action: true, cat: 'Operaciones', profiles: ['alex'] },
    { id: 'x2', date: '2 oct 2026', type: 'Retraso/incidencia', entity: 'Cartagena, Murcia', text: 'Licencia de obra retrasada y sobrecoste estructural. Valor estimado revisado a 7.600 €; salida prevista en junio de 2027.', kind: 'Confirmado', go: ['investment', 'I-A4'], action: true, cat: 'Inversiones', profiles: ['alex'] },
    { id: 'x3', date: '30 sep 2026', type: 'Tasación tras la compra', entity: 'Ruzafa, València', text: 'La tasación sitúa tu posición en 10.700 €. Estimación, no disponible para retirada.', kind: 'Confirmado', go: ['investment', 'I-A3'], action: false, cat: 'Inversiones', profiles: ['alex'] },
    { id: 'x4', date: '4 sep 2026', type: 'Reforma terminada', entity: 'La Flota, Murcia', text: 'Certificado de fin de obra emitido. Preparando la comercialización.', kind: 'Confirmado', go: ['investment', 'I-A1'], action: false, cat: 'Inversiones', profiles: ['alex'] },
    { id: 'x5', date: '29 may 2026', type: 'Pago recibido', entity: 'Patraix, València', text: 'Se han abonado 5.900 € (capital + resultado, simulado). Operación completada.', kind: 'Simulación demo', go: ['investment', 'I-A5'], action: false, cat: 'Inversiones', profiles: ['alex'] },
    { id: 'a6', date: '28 sep 2026', type: 'Operación cancelada', entity: 'O-501 · Patraix, València', text: 'El propietario retiró el inmueble. Los compromisos registrados se liberaron sin cargo.', kind: 'Confirmado', go: ['operation', 'O-501'], action: false, cat: 'Operaciones', profiles: ['alex'] }
  ];
})();
