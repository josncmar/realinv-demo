/* RealInv V1 — portfolios de demostración precargados. Cifras simuladas y reconciliadas. */
(function () {
  const MON = ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic'];
  const TODAY = '2026-10-18';
  const STAGES = ['Adquisición', 'Reforma', 'Reforma terminada', 'En venta', 'Vendida', 'Liquidación en proceso', 'Completada'];
  const DOCS = [['Escritura de compraventa', 'Nota simple'], ['Licencia de obra', 'Presupuesto de reforma'], ['Certificado de fin de obra', 'Tasación tras reforma'], ['Anuncio de venta'], ['Escritura de venta'], ['Liquidación detallada'], ['Justificante de transferencia (simulado)']];
  const ms = iso => { const p = iso.split('-').map(Number); return new Date(p[0], p[1] - 1, p[2]).getTime(); };
  const fd = t => { const d = new Date(t); return d.getDate() + ' ' + MON[d.getMonth()] + ' ' + d.getFullYear(); };
  const eur = n => window.REALINV.fmtEUR(n);
  const sgn = n => (n > 0.5 ? '+' : n < -0.5 ? '−' : '') + eur(Math.abs(n));
  const pct = n => (n > 0 ? '+' : n < 0 ? '−' : '') + Math.abs(n * 100).toFixed(2).replace('.', ',') + ' %';
  const r100 = n => Math.round(n / 100) * 100;
  function budget(total, purchase) {
    const tax = r100(purchase * 0.09), fee = r100(total * 0.024), cont = r100(total * 0.018), maint = r100(total * 0.008), sale = r100(total * 0.016);
    return [['Compra del inmueble', purchase], ['Impuestos y gastos de adquisición', tax], ['Reforma', total - purchase - tax - fee - cont - maint - sale], ['Contingencia', cont], ['Honorarios de gestión', fee], ['Mantenimiento durante la operación', maint], ['Costes de venta', sale]];
  }
  const I = o => Object.assign({ delayed: false, payout: null }, o);
  const USERS = {
    marina: { user: 'juanpemurcia', password: 'murcia123', investments: [
      I({ id: 'I-M1', thesis: 'T-01', barrio: 'La Flota', city: 'Murcia', title: 'Reforma de piso', invested: 10000, value: 10800, stage: 1, status: 'Reforma en curso',
        dates: ['2026-03-02', '2026-04-20', '2026-11-30', '2026-12-10', '2027-02-15', '2027-03-01', '2027-03-15'],
        events: [['2026-03-02', 10000, 'Aportación · compra formalizada'], ['2026-06-15', 10350, 'Tasación previa a obra'], ['2026-09-28', 10800, 'Valoración intermedia de obra']],
        prop: { m2: 78, rooms: 2, baths: 1, year: 1978, floor: '3ª con ascensor', purchase: 98000 }, total: 132000, sale: 155000 }),
      I({ id: 'I-M2', thesis: 'T-03', barrio: 'Centro', city: 'Albacete', title: 'Inversión residencial', invested: 8000, value: 8640, stage: 3, status: 'En venta',
        dates: ['2025-12-10', '2026-01-19', '2026-05-29', '2026-08-25', '2026-11-30', '2026-12-12', '2026-12-20'],
        events: [['2025-12-10', 8000, 'Aportación · compra formalizada'], ['2026-06-02', 8480, 'Tasación tras reforma'], ['2026-09-05', 8640, 'Comparables de venta actualizados']],
        prop: { m2: 88, rooms: 3, baths: 2, year: 1984, floor: '2ª con ascensor', purchase: 93500 }, total: 126000, sale: 145000 }),
      I({ id: 'I-M3', thesis: 'T-02', barrio: 'El Carmen', city: 'Murcia', title: 'Reforma y venta', invested: 5000, value: 5750, stage: 6, status: 'Completada · pagada', payout: 5750,
        dates: ['2025-10-20', '2025-11-24', '2026-03-27', '2026-04-14', '2026-07-15', '2026-07-22', '2026-08-04'],
        events: [['2025-10-20', 5000, 'Aportación · compra formalizada'], ['2026-04-02', 5400, 'Tasación tras reforma'], ['2026-07-15', 5750, 'Venta escriturada'], ['2026-08-04', 5750, 'Pago recibido']],
        prop: { m2: 58, rooms: 2, baths: 1, year: 1972, floor: '1ª sin ascensor', purchase: 76000 }, total: 108000, sale: 124200 })
    ], opportunities: { 'T-07': 5000, 'T-08': 8000 } },
    alex: { user: 'josecarlosalba', password: 'alba123', investments: [
      I({ id: 'I-A1', thesis: 'T-01', barrio: 'La Flota', city: 'Murcia', title: 'Reforma residencial', invested: 15000, value: 16500, stage: 2, status: 'Reforma terminada',
        dates: ['2025-11-17', '2026-01-12', '2026-09-04', '2026-11-02', '2027-01-08', '2027-01-20', '2027-01-31'],
        events: [['2025-11-17', 15000, 'Aportación · compra formalizada'], ['2026-05-11', 15600, 'Valoración intermedia de obra'], ['2026-09-10', 16500, 'Tasación tras reforma']],
        prop: { m2: 82, rooms: 2, baths: 1, year: 1981, floor: '4ª con ascensor', purchase: 95000 }, total: 128000, sale: 150000 }),
      I({ id: 'I-A2', thesis: 'T-03', barrio: 'Centro', city: 'Albacete', title: 'Reforma de piso', invested: 12000, value: 12600, stage: 3, status: 'En venta',
        dates: ['2025-12-01', '2026-01-26', '2026-06-12', '2026-07-06', '2026-12-04', '2026-12-18', '2026-12-31'],
        events: [['2025-12-01', 12000, 'Aportación · compra formalizada'], ['2026-06-20', 12600, 'Tasación tras reforma']],
        prop: { m2: 86, rooms: 3, baths: 1, year: 1986, floor: '1ª con ascensor', purchase: 89000 }, total: 121000, sale: 138000 }),
      I({ id: 'I-A3', thesis: null, barrio: 'Ruzafa', city: 'València', title: 'Oportunidad residencial', invested: 10000, value: 10700, stage: 0, status: 'Adquisición completada',
        dates: ['2026-07-08', '2026-11-02', '2027-03-15', '2027-03-29', '2027-06-15', '2027-06-28', '2027-07-10'],
        events: [['2026-07-08', 10000, 'Aportación · compra formalizada'], ['2026-09-30', 10700, 'Tasación tras la compra']],
        prop: { m2: 70, rooms: 2, baths: 1, year: 1965, floor: '2ª sin ascensor', purchase: 156000 }, total: 205000, sale: 238000 }),
      I({ id: 'I-A4', thesis: null, barrio: 'Cartagena', city: 'Murcia', title: 'Oportunidad de reventa', invested: 8000, value: 7600, stage: 1, status: 'Reforma · retrasada', delayed: true, origExit: '2027-02-26',
        delayNote: 'La licencia de obra se ha retrasado unos 4 meses y se ha detectado un sobrecoste estructural de 3.200 € por encima de la contingencia. El valor estimado de tu posición se revisa a 7.600 € y la salida prevista pasa de febrero a junio de 2027.',
        dates: ['2026-02-16', '2026-04-06', '2027-03-31', '2027-04-20', '2027-06-10', '2027-06-22', '2027-06-30'],
        events: [['2026-02-16', 8000, 'Aportación · compra formalizada'], ['2026-07-20', 7800, 'Sobrecoste estructural detectado'], ['2026-10-02', 7600, 'Revisión por retraso de licencia']],
        prop: { m2: 74, rooms: 2, baths: 1, year: 1975, floor: 'Bajo', purchase: 79000 }, total: 112000, sale: 128000 }),
      I({ id: 'I-A5', thesis: 'T-05', barrio: 'Patraix', city: 'València', title: 'Reforma y venta', invested: 5000, value: 5900, stage: 6, status: 'Completada · pagada', payout: 5900,
        dates: ['2025-07-01', '2025-08-18', '2025-12-19', '2026-01-20', '2026-04-20', '2026-05-12', '2026-05-29'],
        events: [['2025-07-01', 5000, 'Aportación · compra formalizada'], ['2026-01-15', 5450, 'Tasación tras reforma'], ['2026-04-20', 5900, 'Venta escriturada'], ['2026-05-29', 5900, 'Pago recibido']],
        prop: { m2: 68, rooms: 2, baths: 1, year: 1970, floor: '3ª con ascensor', purchase: 132000 }, total: 172000, sale: 202960 })
    ], opportunities: { 'T-05': 25000, 'T-09': 15000, 'T-10': 10000 } }
  };

  function fromOperation(o, inv) {
    const D = window.REALINV, t = D.theses.find(x => x.id === o.thesis), start = inv.start || TODAY;
    const add = (n) => { const d = new Date(ms(start)); d.setDate(d.getDate() + n); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); };
    const f = Object.fromEntries(o.features);
    return I({ id: inv.id, thesis: o.thesis, barrio: t.name, city: t.city, title: 'Operación ' + o.id, invested: inv.ticket, value: inv.ticket, stage: 0, status: 'Pendiente de adquisición', pending: true,
      dates: [30, 60, 180, 195, 270, 300, 330].map(add), events: [[start, inv.ticket, 'Aportación formalizada (simulada)']],
      prop: { m2: parseInt(f['Superficie'], 10), rooms: f['Dormitorios'], baths: f['Baños'], year: f['Año'], floor: f['Planta'], purchase: o.budget[0][1] }, total: o.total, sale: o.scenarios[1].sale, ownBudget: o.budget });
  }

  function seriesFor(list) {
    const t0 = Math.min.apply(null, list.map(x => ms(x.dates[0]))), t1 = ms(TODAY), out = [];
    const prep = list.map(x => ({ x, s: ms(x.dates[0]), ev: x.events.map(e => [ms(e[0]), e[1]]), pay: x.payout ? ms(x.dates[6]) : null }));
    for (let t = t0; t <= t1; t += 864e5) {
      let v = 0, c = 0;
      prep.forEach(p => {
        if (t < p.s) return; c += p.x.invested;
        if (p.pay && t >= p.pay) { v += p.x.payout; return; }
        let val = p.x.invested; p.ev.forEach(e => { if (e[0] <= t) val = e[1]; }); v += val;
      });
      out.push({ t, v, c });
    }
    return out;
  }
  function marksFor(list, prefix) {
    const m = [];
    list.forEach(x => x.events.forEach((e, i) => { if (ms(e[0]) <= ms(TODAY)) m.push({ t: ms(e[0]), label: (prefix ? x.barrio + ' · ' : '') + e[2], kind: i === 0 ? 'in' : (e[2] === 'Pago recibido' ? 'out' : 'val') }); }));
    return m.sort((a, b) => a.t - b.t);
  }
  function stStyle(x) { return x.payout ? ['rgba(14,150,108,0.1)', '#0b6e50'] : x.delayed ? ['rgba(217,119,6,0.12)', '#8a4b04'] : x.pending ? ['rgba(0,0,0,0.05)', '#2d3139'] : x.stage >= 2 ? ['rgba(114,217,217,0.22)', '#1f5f64'] : ['#f2f3f5', '#2d3139']; }

  function decorate(x) {
    const done = !!x.payout, cur = done ? x.payout : x.value, gain = cur - x.invested, st = stStyle(x), share = x.invested / x.total;
    const bud = x.ownBudget || budget(x.total, x.prop.purchase);
    const today = ms(TODAY);
    const ser = seriesFor([x]);
    const updates = x.events.map(e => ({ t: ms(e[0]), d: fd(ms(e[0])), k: e[2], v: e[2].indexOf('Aportación') === 0 ? 'Capital aportado: ' + eur(x.invested) : 'Valor de tu posición: ' + eur(e[1]), kind: e[2] === 'Pago recibido' ? 'Simulación demo' : 'Confirmado' }))
      .concat(x.dates.slice(1, x.stage + 1).map((d, i) => ({ t: ms(d), d: fd(ms(d)), k: 'Fase alcanzada: ' + STAGES[i + 1], v: STAGES[i + 1] === 'Reforma' ? 'Inicio de obra con presupuesto aprobado.' : STAGES[i + 1] === 'En venta' ? 'Vivienda publicada en portales.' : 'Hito documentado.', kind: 'Confirmado' })));
    if (x.delayed) updates.push({ t: ms('2026-10-02') + 1, d: fd(ms('2026-10-02')), k: 'Retraso comunicado', v: 'Salida prevista revisada de ' + fd(ms(x.origExit)) + ' a ' + fd(ms(x.dates[6])) + '.', kind: 'Incidencia' });
    updates.sort((a, b) => b.t - a.t);
    const docs = []; for (let i = 0; i <= x.stage; i++) DOCS[i].forEach(n => docs.push({ k: n, d: fd(ms(x.dates[i])) }));
    return Object.assign({}, x, {
      name: x.barrio + ', ' + x.city, done, active: !done, cur, gain, img: 'inv-' + x.id,
      investedF: eur(x.invested), curF: eur(cur), curLabel: done ? 'Pago final' : 'Valor estimado', gainF: sgn(gain), gainPct: pct(gain / x.invested), gainFg: gain >= 0 ? '#0b6e50' : '#a8432f', gainLabel: done ? 'Beneficio realizado' : 'Beneficio estimado',
      stBg: st[0], stFg: st[1], progressW: Math.round(x.stage / 6 * 100) + '%', progressFg: x.delayed ? '#d97706' : done ? '#0e966c' : '#2d3139', stageN: (x.stage + 1) + ' de 7',
      exitLabel: done ? 'Completada · ' + fd(ms(x.dates[6])) : 'Salida prevista · ' + fd(ms(x.dates[6])) + (x.delayed ? ' (retrasada)' : ''),
      shareF: (share * 100).toFixed(2).replace('.', ',') + ' %', totalF: eur(x.total),
      note: done ? 'Abonado el ' + fd(ms(x.dates[6])) + ' en tu cuenta (simulado).' : 'Estimación basada en la última evidencia. No es un retorno garantizado ni efectivo disponible para retirada.',
      series: ser, marks: marksFor([x], false),
      stages: STAGES.map((k, i) => { const isDone = done || i < x.stage, isCur = !done && i === x.stage, past = ms(x.dates[i]) <= today && (isDone || isCur);
        return { k, date: (past ? 'Real · ' : 'Previsto · ') + fd(ms(x.dates[i])), n: isDone ? '✓' : String(i + 1), bg: isDone ? '#2d3139' : isCur ? (x.delayed ? '#d97706' : '#72d9d9') : '#fff', fg: isDone ? '#fff' : isCur ? '#0d2b2b' : 'rgba(45,49,57,0.4)', bd: isDone ? '#2d3139' : isCur ? (x.delayed ? '#d97706' : '#72d9d9') : 'rgba(0,0,0,0.14)', tc: isDone || isCur ? '#2d3139' : 'rgba(45,49,57,0.45)', w: isCur ? '600' : '500', line: isDone ? '#2d3139' : 'rgba(0,0,0,0.1)', notLast: i < 6 }; }),
      photos: [['Antes', 0, 'Disponible tras la compra'], ['Durante', 1, 'Disponible al iniciar la obra'], ['Después', 2, 'Disponible al terminar la reforma']].map(p => ({ label: p[0], avail: x.stage >= p[1] && !x.pending, na: !(x.stage >= p[1] && !x.pending), note: p[2], id: 'inv-' + x.id + '-' + p[0].toLowerCase() })),
      updates, docs: docs.reverse(),
      propRows: [['Precio de compra', eur(x.prop.purchase)], ['Fecha de compra', fd(ms(x.dates[0]))], ['Superficie', x.prop.m2 + ' m²'], ['Dormitorios / baños', x.prop.rooms + ' / ' + x.prop.baths], ['Planta', x.prop.floor], ['Año de construcción', String(x.prop.year)], ['Precio de compra por m²', window.REALINV.fmtNum(x.prop.purchase / x.prop.m2) + ' €/m²']].map(r => ({ k: r[0], v: r[1] })),
      budgetRows: bud.map(b => ({ k: b[0], v: eur(b[1]), w: (b[1] / x.total * 100).toFixed(1) + '%' })),
      exitRows: (done ? [['Venta escriturada', fd(ms(x.dates[4]))], ['Precio de venta', eur(x.sale)], ['Capital devuelto', eur(x.invested)], ['Beneficio realizado', sgn(gain)], ['Pago recibido', fd(ms(x.dates[6]))]]
        : [['Salida prevista', fd(ms(x.dates[6]))], ['Precio de venta objetivo', eur(x.sale) + ' (no garantizado)'], ['Valor estimado de tu posición', eur(cur)]].concat(x.delayed ? [['Salida prevista original', fd(ms(x.origExit))]] : [])).map(r => ({ k: r[0], v: r[1] }))
    });
  }

  function build(key, extras) {
    const u = USERS[key] || USERS.marina;
    const list = u.investments.concat(extras || []).map(decorate);
    const act = list.filter(x => x.active), fin = list.filter(x => x.done);
    const sum = (a, f) => a.reduce((s, x) => s + f(x), 0);
    const totalHist = sum(list, x => x.invested), activeCap = sum(act, x => x.invested), activeVal = sum(act, x => x.value), returned = sum(fin, x => x.payout);
    const realized = sum(fin, x => x.payout - x.invested), unreal = activeVal - activeCap, profit = realized + unreal;
    return {
      list, user: u,
      k: { totalHist, activeCap, activeVal, returned, realized, unreal, profit, ret: profit / totalHist, total: activeVal + returned, nActive: act.length, nDone: fin.length },
      series: seriesFor(list), marks: marksFor(list, true)
    };
  }
  window.RealInvPortfolio = { USERS, STAGES, TODAY, build, fromOperation, fd, ms, eur, sgn, pct };
})();
