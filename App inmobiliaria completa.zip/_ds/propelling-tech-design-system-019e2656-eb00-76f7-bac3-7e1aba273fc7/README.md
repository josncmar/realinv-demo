# Propelling Tech — Design System

> _"Tech that makes sense."_
> A global technology consulting firm focused on **AI, Data & Analytics**
> with a portfolio of internal products around AI strategy, agent fleets,
> use-case scoring and team enablement.

This folder is a working design system: real assets, real type, the real
CSS tokens lifted from the production codebases, plus React UI kits that
recreate the live products closely enough to use as a starting point for
mocks, slides and prototypes.

---

## Sources

This system was assembled from the following inputs. Treat as read-only
references — files of interest were already copied into this project.

| Kind | Path | Notes |
|---|---|---|
| Codebase | `propelling-hub/` (Next.js 16, Tailwind v4) | "Propelling Hub" — internal/customer portfolio showroom of AI case studies. Public-facing-ish, locked behind a Company Key. |
| Codebase | `propelling-aicc/` (Next.js 16, Tailwind v4, Supabase, next-intl) | "Propelling AICC" — the **AI Command Center**. Multi-tenant dashboard for AI assessments, use-case discovery & scoring, agent fleet, FinOps. EN + ES. |
| Brand PDF | `uploads/2026 PROPELLING TECH - Corporate Profile.pdf` (extracted to `uploads/.corporate_profile.txt`) | Founder-deck-style corporate profile. Source of all marketing copy quoted below. |
| Brand assets | `uploads/*.png`, `uploads/*.jpg` | Logo variants, symbol glyphs, generative imagery. Copied into `assets/`. |
| Fonts | `uploads/New_Science_*.otf` | "New Science" type family — the brand display face. Copied into `fonts/`. |

> The user's email domain is `propellingtech.com`. We are working *for* the
> Propelling Tech team, so it's fine to recreate their UI patterns and
> assets — but we still don't redistribute the typeface outside their
> projects.

---

## The two products

### 1 · Propelling Hub  *(`propelling-hub/`)*
Editorial **case-study showroom**. Marketing-skinned, italic everything,
big rounded `[3rem]` cards, dark navy modal with a cyan accent rail.
Lives on a black/dark backdrop in modal mode; a soft `#F8FAFC` grid
otherwise. Three filter tabs: All / AI Agents / Strategic Advisory /
Modern Data Platform. Cards open a 70/30 modal — editorial panel
(Problem · Solution · Quote · Benefits · CTAs) + asset gallery strip.

**Voice:** marketing-confident. UPPERCASE ITALIC display headlines,
"Project Insights", "Launch Demo →", "View Technical Insights",
"Synchronizing with Cloud assets".

### 2 · Propelling AICC  *(`propelling-aicc/`)*
The **AI Command Center**. Internal SaaS dashboard. Dark sidebar
(`#2d3139`) + light app body (`#F8FAFC`). Workmanlike, calm, dense.
Nav sections: Enablement · Discovery · Build · Govern & Control ·
Settings. Modules: Dashboard, Adoption, Assessments, Pulse, Use Cases
(Hub), Agent Fleet, AI FinOps.

**Voice:** product-quiet. Sentence case, short labels, glyphs from
`lucide-react`. Mixes EN/ES in source (es-ES locale strings appear),
but the English `messages/en.json` is the canonical reference.

The two products share a single brand spine — same cyan accent, same
Outer Space ink, same Plus Jakarta Sans — but apply it at very
different volumes.

---

## Quick start

```html
<!-- minimum brand boot -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="colors_and_type.css">

<h1>See Beyond Today</h1>
<p>Tech that makes sense.</p>
```

Lucide icons (used everywhere in AICC) load from CDN:
```html
<script src="https://unpkg.com/lucide@latest"></script>
```

---

## Visual Foundations

### Colors
The brand is a **2-color system** stretched with semantics. Don't
invent new palettes — `--pt-propel-blue` and `--pt-outer-space` carry
almost everything.

- **Propel Blue `#72d9d9`** — single accent. Buttons, active nav,
  eyebrow tags, focus, brand glow. Always paired with `#0d2b2b`
  (`--pt-fg-on-accent`) for text on cyan fills.
- **Outer Space `#2d3139`** — primary ink, sidebar, dark headers.
  Used at full opacity for text; 60% / 38% for secondary / disabled.
- **Tech Blue `#2A3340`** — near-twin of Outer Space. Used in
  alternate logo lockups; treat as equivalent to Outer Space.
- **Pacer White `#FFFFFF`** + **Bg Base `#F8FAFC`** — surfaces.
  Apps use white cards on the `#F8FAFC` canvas; never reverse.
- **Semantic:** success `#0e966c`, warning `#d97706`, error `#e36d57`.
  All used at a `0.10` subtle background. AICC integrates `#34d399`
  for OpenAI cost rows.

There is **no second brand color and no gradient palette**. If a
heat-mapped scale is needed (e.g. effort dots), the production code
uses amber → orange → red over a green base — see `ScoreDisplay.tsx`.

### Typography
- **New Science** — the brand display face. Geometric, wide, slightly
  technical. Use for headlines, hero numbers, ALL-CAPS eyebrows. The
  "Extended" cut is the most distinctive — use it for big hero text.
- **Plus Jakarta Sans** — every UI surface in both apps. Loaded from
  Google Fonts. Body 14px, line-height 1.5.
- **Casing & style:**
  - Showroom: UPPERCASE + italic + tight tracking on display.
  - Dashboard: Sentence case, no italic, no tracking.
  - **Eyebrow stamps** (10px, 800 weight, `0.3em` tracking, italic,
    in cyan) appear on almost every card — this is the signature
    type detail. Don't drop it.
- The PDF profile uses big light New Science for hero quotes
  ("We believe in a world where technology exists to make your life
  easier") — light weight + huge size + dark ink.

### Spacing & rhythm
- 4px base scale (`--pt-space-1` … `--pt-space-20`).
- Card interiors at 20–24px (`p-5` / `p-6`).
- Marketing cards breathe more: `p-5` shell with an inner `mb-8`
  gap to the cover image.

### Cards
Two clear conventions in production, **don't mix**:

- **Dashboard cards** (`.glass-card` in AICC):
  white bg, `1px solid rgba(0,0,0,0.08)` border, `--pt-radius-md` (12px),
  soft `--pt-shadow-sm`. Hover bumps to `--pt-shadow-md` and lifts 1px.
  Often a `3px solid <accent>` border-top to color-code modules.
- **Editorial / showroom cards** (Hub):
  white bg, **no border**, `--pt-radius-3xl` (48px / "3rem"),
  `--pt-shadow-lg`. Cover image clipped to a smaller `2.2rem` round
  inside. Hover lifts `-4px` and scales the cover image to `1.10`
  over 1000ms.

### Borders & dividers
Hairlines at `rgba(0,0,0,0.05)` (subtle) → `rgba(0,0,0,0.09)` (default)
→ `rgba(0,0,0,0.13)` (strong / hover). On the dark sidebar:
`rgba(255,255,255,0.08)`. **3px solid colored bars** are used as
section markers ("Problem" in red, "Solution" in cyan) — a small
rectangle, not a left-rail accent on the whole card.

### Shadows / glow
- `--pt-shadow-sm` (dashboard rest)
- `--pt-shadow-md` (dashboard hover)
- `--pt-shadow-lg` (marketing cards)
- `--pt-shadow-xl` (modals — `0 24px 60px rgba(0,0,0,0.18)`)
- `--pt-glow` — cyan diffuse glow for active accent CTAs. Sparingly.

### Transparency & blur
Modals use a strong `bg-black/60 backdrop-blur-[20px]` overlay; the
modal content itself is opaque white. The sidebar is opaque navy.
Glass effects (`--glass-bg: rgba(255,255,255,0.90); blur(20px)`)
exist in the AICC tokens but are barely used — keep restraint.

### Hover / press
- Buttons: `opacity: 0.9` on hover + `translateY(-0.5px)` + light glow.
  On press / active: `transform: scale(0.95)` (Hub buttons go even
  further — `active:scale-95`).
- Cards: `translateY(-1px)` (dashboard) or `translateY(-4px)`
  (marketing) with image scale.
- Links / icon buttons: bg shifts to `rgba(0,0,0,0.04)`.
- Nav active: cyan text + `rgba(114,217,217,0.12)` background
  + 2px cyan left border.

### Animation
- Used **sparingly**. Calm, short, easing out.
- `--pt-dur-fast` (120ms) for buttons / chips.
- `--pt-dur-base` (200ms) for cards.
- `--pt-dur-slow` (400ms) for layout / hovers.
- Easing default = `cubic-bezier(0.2, 0.7, 0.2, 1)`.
- Cover-image scale on card hover runs over **1000ms** — the only
  intentionally slow motion in the system.
- Score counters use a cubic-out `1 - (1-t)^3` over 750ms — see
  `useAnimatedScore` / `useCountUp` in `ScoreDisplay.tsx`.
- Framer Motion is the production tool — spring `damping: 32,
  stiffness: 320` for panels.

### Backgrounds & imagery
The brand **does not use pattern fills, gradients, or geometric
backgrounds** in production UI. Backgrounds are flat white / `#F8FAFC`
/ Outer Space.

The **marketing imagery** (in `assets/imagery/`) is generative-art
hero shots — organic, fluid, cool blue/teal with green and accent
yellow, slightly soft-focus. Used as decorative backdrops and cover
images for case studies, not as repeating patterns. Cool palette,
warm only via small yellow particles.

### Layout rules
- Sidebar width: `240px` expanded, `64px` collapsed (see
  `--sidebar-width` / `--sidebar-collapsed-width`).
- Header height: `52px`.
- Content max-width: `1280px` (dashboard) or `1280–1440px` (marketing).
- Mobile: AICC is desktop-first; Hub is responsive (grid drops from
  3 → 2 → 1 columns).

---

## Content Fundamentals

### Voice
Two distinct tones — match the surface.

**Marketing / showroom (Hub, PDF, Slides):**
- Confident, almost editorial. Big claims, short lines.
- ALL CAPS for nouns of importance ("PROJECT INSIDES", "PROPELLING
  CASE", "PORTFOLIO").
- Sentence-case body that flows into a `→` arrow when the user can
  act ("Launch Demo →", "View Technical Insights").
- Tagline DNA from the PDF:
  - "Tech that makes sense."
  - "Technology with a goal."
  - "All-in Commitment."
  - "See Beyond Today."
- Layered three-word headers ("Shorter Times to Market", "Lower TCO",
  "Innovative Approach").
- We / our / we drive / we identify — **collective first person.**
  Never "I" or "you" — the company speaks as a team.

**Product / dashboard (AICC):**
- Calm, dry, neutral. No marketing flourishes inside the product.
- Sentence case labels: "Average score", "Active campaigns",
  "View more →".
- Empty states are short and apologetic, not playful:
  "No data yet" / "Create an assessment and share it with your team
  to start collecting data."
- Status / level vocabulary: Basic · Intermediate · Advanced · Champion.
- Use-case sizes: **S · M · L · XL** as a single letter glyph.
- Time/effort framing: weeks ("4–6 sem"), `2/5 dots`, `78/100`.

### Casing rules
| Where | Casing |
|---|---|
| Showroom display headlines | UPPERCASE ITALIC |
| Eyebrow stamps everywhere | UPPERCASE, 0.3em tracking |
| Dashboard headings | Sentence case |
| Dashboard labels (KPI) | UPPERCASE, 9–10px, 0.3em tracking |
| Buttons in showroom | UPPERCASE, 0.15em tracking |
| Buttons in dashboard | Sentence case, no tracking |
| Nav items | Sentence case |

### Punctuation
- Use `→` (right arrow) as the action marker, both in CTAs and as
  list bullets (`->` is restyled to `→` in cyan inside
  `.project-content ul li::before`).
- Em-dashes and middle dots ` · ` are both fine — middle dot is
  preferred for inline tag separators ("Use Case Discovery · AI
  Architecture · AI Roadmap").
- No oxford comma in marketing copy (the PDF doesn't use it).

### Emoji
- **None in product UI.**
- Hub uses two emoji as inline icons inside the modal: `✕ Close`,
  `▶ Play`, `⊕ Expand`, `📁` (the empty state icon for an asset
  gallery — debatable; treat as legacy).
- Prefer Lucide icons (already in AICC) over emoji for anything new.

### I / you / we
- Marketing: **we** (Propelling Tech).
- Product: **you** sparingly — most strings are object-of-the-app
  ("Share this link with your team", "Sign in to continue").

### Sample copy
- Hero: "We believe in a world where technology exists to make your life easier."
- Subhead: "We are a global technology consulting firm focused on AI, Data & Analytics to drive innovation, transform businesses, and deliver real impact."
- CTA pair (marketing): `Launch Demo →` / `View Main Platform →`
- CTA (product): `Sign in` / `Save` / `Create` / `View more`
- Section label: `PROJECT INSIDES` · `PROPELLING CASE` · `PORTFOLIO`
- Status copy: `Synchronizing with Cloud assets` (loading), `No projects for this persona` (empty)

---

## Iconography

### Where icons come from
- **Lucide React** (`lucide-react`) — the only icon library used in
  the AICC codebase. Always `size={13}` or `size={14}` for sidebar /
  inline use, `size={11}` for micro-decoration. Stroke width is the
  Lucide default (1.5–2).
  Examples used in production: `LayoutDashboard`, `GraduationCap`,
  `TrendingUp`, `FolderKanban`, `Package`, `BookOpen`, `Bot`,
  `BarChart2`, `ClipboardList`, `BarChart3`, `ShieldCheck`, `Users2`,
  `SlidersHorizontal`, `LayoutList`, `Eye`, `EyeOff`, `LogIn`,
  `ChevronRight`, `ChevronLeft`, `Pencil`, `X`, `ShieldAlert`,
  `Trash2`, `Clock`, `CheckCircle2`, `ArrowRight`, `ArrowUpRight`,
  `AlertTriangle`, `Activity`, `Cpu`, `DollarSign`, `Users`.
  ```html
  <!-- CDN: drop <i data-lucide="layout-dashboard"></i> + the script -->
  <script src="https://unpkg.com/lucide@latest"></script>
  <script>lucide.createIcons();</script>
  ```
- **Inline SVG** — Hub uses three small inline SVGs (settings cog,
  star). Treat as exceptions.
- **No icon font, no sprite sheet, no PNG icons.**

### Emoji as iconography
Don't. The system replaces emoji with Lucide everywhere except
the legacy Hub modal close (`✕`) and play (`▶`) glyphs — those are
literal Unicode characters, not emoji.

### Brand symbols
The "Símbolo" set (in `assets/symbols/`) is a family of **6 geometric
compositions** built from a circle, a triangle and a square. Treat
them like brand stamps, not generic icons:
- `symbol-01` — circle + square (the canonical mark)
- `symbol-02` … `symbol-06` — variations rotating which two of the
  three shapes appear together
- Four color variants per glyph: Outer Space, Propel Blue, Tech Blue,
  Pacer White (use White only on dark backgrounds).

Use them as decorative anchors on slides and section starters, never
as functional UI icons. They scale down poorly below ~64px.

### Logo lockups (in `assets/logos/`)
- `logotype-*.png` — wordmark only, full lockup
- `*-baseline.png` — wordmark with the underline ascender baseline
  variant (recommended for hero / large use)
- `logotype-propel-blue-squared.png` — square crop for avatars / app
  icons

---

## Index — what's in this folder

```
.
├── README.md                  ← you are here
├── SKILL.md                   ← Agent Skills front-matter for invoking this system
├── colors_and_type.css        ← all CSS tokens + @font-face
├── fonts/                     ← New Science .otf files (Light → Bold + Extended cuts)
├── assets/
│   ├── logos/                 ← wordmark variants (4 colors × 2 cuts + squared)
│   ├── symbols/               ← 6 geometric brand stamps × 4 colors
│   └── imagery/               ← generative hero imagery (plants, chains, spores)
├── preview/                   ← cards rendered in the Design System tab
└── ui_kits/
    ├── hub/                   ← Propelling Hub recreation (case-study showroom)
    │   ├── index.html         ← interactive prototype
    │   └── *.jsx              ← extracted components
    └── aicc/                  ← Propelling AICC recreation (AI Command Center)
        ├── index.html         ← interactive prototype
        └── *.jsx              ← extracted components
```

---

## Substitutions & caveats

- **Plus Jakarta Sans** is loaded from Google Fonts (the canonical
  source — that's how both production apps load it too).
- **New Science** font files are bundled here directly (the user
  provided 13 cuts; we ship the 8 most useful in `fonts/`).
- Lucide icons are loaded from CDN (`unpkg.com/lucide@latest`)
  rather than bundled — matches how a designer working in HTML
  would consume them.
- Generative marketing imagery is bundled as-is. There are no
  vector versions; we have not regenerated or recreated any of it.

If any of the above feels off, see the **bold ask** at the end of
the design system tab — happy to swap fonts, palette nuances or
component variants to match what your team actually uses.
