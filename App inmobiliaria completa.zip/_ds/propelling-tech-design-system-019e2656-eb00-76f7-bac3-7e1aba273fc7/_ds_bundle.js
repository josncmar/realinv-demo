/* @ds-bundle: {"format":3,"namespace":"PropellingTechDesignSystem_019e26","components":[],"sourceHashes":{"ui_kits/aicc/Primitives.jsx":"900e5d447a49","ui_kits/aicc/Screens.jsx":"694eba697a00","ui_kits/aicc/Shell.jsx":"41db83fdec7c","ui_kits/aicc/app.jsx":"0275be9beda6"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.PropellingTechDesignSystem_019e26 = window.PropellingTechDesignSystem_019e26 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// ui_kits/aicc/Primitives.jsx
try { (() => {
// AICC primitives — Badge, ScoreDisplay (stars + dots), KpiCard, ModuleCard, etc.
// Designed to look exactly like the production AICC components.

// --- Lucide icon helper: <Icon name="..."/> renders <i data-lucide=...> and re-creates icons
function Icon({
  name,
  size = 14,
  color,
  style
}) {
  const ref = React.useRef(null);
  React.useEffect(() => {
    if (window.lucide && ref.current) {
      ref.current.setAttribute('data-lucide', name);
      window.lucide.createIcons({
        icons: window.lucide.icons,
        nameAttr: 'data-lucide'
      });
    }
  }, [name]);
  return /*#__PURE__*/React.createElement("i", {
    ref: ref,
    "data-lucide": name,
    style: {
      width: size,
      height: size,
      display: 'inline-block',
      color,
      ...style
    }
  });
}

// --- Badge
function AiccBadge({
  children,
  variant = 'default'
}) {
  const v = {
    active: {
      color: '#0d6b6b',
      background: 'rgba(114,217,217,.12)',
      border: '1px solid rgba(114,217,217,.25)'
    },
    inactive: {
      color: 'rgba(45,49,57,.5)',
      background: 'rgba(0,0,0,.04)',
      border: '1px solid rgba(0,0,0,.08)'
    },
    champion: {
      color: '#7a5a00',
      background: 'rgba(245,197,66,.12)',
      border: '1px solid rgba(245,197,66,.25)'
    },
    maybe: {
      color: '#3f2a87',
      background: 'rgba(167,139,250,.12)',
      border: '1px solid rgba(167,139,250,.25)'
    },
    warning: {
      color: '#9b5300',
      background: 'rgba(245,158,11,.15)',
      border: '1px solid rgba(245,158,11,.4)'
    },
    default: {
      color: 'rgba(45,49,57,.6)',
      background: 'rgba(0,0,0,.04)',
      border: '1px solid rgba(0,0,0,.08)'
    }
  }[variant];
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      padding: '2px 8px',
      borderRadius: 8,
      fontSize: 10,
      fontWeight: 800,
      textTransform: 'uppercase',
      letterSpacing: '0.1em',
      ...v
    }
  }, children);
}

// --- Stars (impact) & Dots (effort)
const STAR_PATH = 'M12 2 L15.09 8.26 L22 9.27 L17 14.14 L18.18 21.02 L12 17.77 L5.82 21.02 L7 14.14 L2 9.27 L8.91 8.26 Z';
function StarRating({
  score,
  size = 14
}) {
  const filled = score / 100 * 5;
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      gap: 2,
      alignItems: 'center'
    }
  }, [1, 2, 3, 4, 5].map(i => {
    const f = Math.max(0, Math.min(1, filled - (i - 1)));
    return /*#__PURE__*/React.createElement("span", {
      key: i,
      style: {
        position: 'relative',
        width: size,
        height: size
      }
    }, /*#__PURE__*/React.createElement("svg", {
      width: size,
      height: size,
      viewBox: "0 0 24 24"
    }, /*#__PURE__*/React.createElement("path", {
      d: STAR_PATH,
      fill: "rgba(251,191,36,.22)"
    })), /*#__PURE__*/React.createElement("span", {
      style: {
        position: 'absolute',
        left: 0,
        top: 0,
        width: `${f * 100}%`,
        height: '100%',
        overflow: 'hidden'
      }
    }, /*#__PURE__*/React.createElement("svg", {
      width: size,
      height: size,
      viewBox: "0 0 24 24"
    }, /*#__PURE__*/React.createElement("path", {
      d: STAR_PATH,
      fill: "#FBBF24"
    }))), /*#__PURE__*/React.createElement("svg", {
      width: size,
      height: size,
      viewBox: "0 0 24 24",
      style: {
        position: 'absolute',
        left: 0,
        top: 0
      }
    }, /*#__PURE__*/React.createElement("path", {
      d: STAR_PATH,
      fill: "none",
      stroke: "rgba(0,0,0,.18)",
      strokeWidth: "1.2",
      strokeLinejoin: "round"
    })));
  }));
}
function EffortDots({
  score,
  size = 14
}) {
  const filled = Math.round(score / 100 * 5);
  const color = filled <= 1 ? '#22C55E' : filled <= 2 ? '#86EFAC' : filled <= 3 ? '#FBBF24' : filled <= 4 ? '#F97316' : '#EF4444';
  const emptyBg = filled <= 2 ? 'rgba(34,197,94,.10)' : 'rgba(239,68,68,.12)';
  const dot = Math.round(size * 0.58);
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      gap: 4,
      alignItems: 'center'
    }
  }, [1, 2, 3, 4, 5].map(i => /*#__PURE__*/React.createElement("span", {
    key: i,
    style: {
      width: dot,
      height: dot,
      borderRadius: '50%',
      backgroundColor: i <= filled ? color : emptyBg,
      boxShadow: '0 0 0 1px rgba(0,0,0,.15)'
    }
  })));
}

// --- KpiCard
function KpiCard({
  label,
  value,
  sub,
  icon,
  accent,
  delta
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "glass-card",
    style: {
      padding: 20
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: 12
    }
  }, /*#__PURE__*/React.createElement("p", {
    className: "eyebrow",
    style: {
      margin: 0
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      width: 28,
      height: 28,
      borderRadius: 10,
      background: accent || 'rgba(114,217,217,.14)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: icon,
    size: 13,
    color: "#0d6b6b"
  }))), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 28,
      fontWeight: 700,
      letterSpacing: '-0.01em',
      color: '#2d3139',
      fontVariantNumeric: 'tabular-nums'
    }
  }, value), delta != null && /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '4px 0 0',
      fontSize: 10,
      fontWeight: 600,
      color: delta > 0 ? '#22c55e' : delta < 0 ? '#ef4444' : 'rgba(45,49,57,.38)'
    }
  }, delta > 0 ? '↑ +' : delta < 0 ? '↓ ' : '= ', delta, "%", /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: 4,
      color: 'rgba(45,49,57,.38)',
      fontWeight: 400
    }
  }, "vs. prev.")), sub && delta == null && /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '4px 0 0',
      fontSize: 10,
      color: 'rgba(45,49,57,.5)'
    }
  }, sub));
}

// --- ModuleCard (large dashboard module)
function ModuleCard({
  title,
  icon,
  accent,
  viewMore = 'View more',
  onView,
  children
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "glass-card",
    style: {
      borderTop: `3px solid ${accent}`,
      display: 'flex',
      flexDirection: 'column'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      padding: '12px 20px',
      borderBottom: '1px solid var(--aicc-border)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 24,
      height: 24,
      borderRadius: 6,
      background: `color-mix(in srgb, ${accent} 15%, transparent)`,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: icon,
    size: 13,
    color: accent
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      fontWeight: 700,
      color: '#2d3139'
    }
  }, title)), /*#__PURE__*/React.createElement("button", {
    onClick: onView,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 2,
      background: 'none',
      border: 0,
      fontSize: 10,
      fontWeight: 500,
      color: accent,
      opacity: 0.75,
      cursor: 'pointer'
    }
  }, viewMore, " ", /*#__PURE__*/React.createElement(Icon, {
    name: "arrow-up-right",
    size: 11
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 20,
      display: 'flex',
      flexDirection: 'column',
      gap: 16
    }
  }, children));
}
function MiniStat({
  label,
  value,
  valueColor
}) {
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 9,
      textTransform: 'uppercase',
      letterSpacing: '.2em',
      color: 'rgba(45,49,57,.38)'
    }
  }, label), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '2px 0 0',
      fontSize: 18,
      fontWeight: 700,
      color: valueColor || '#2d3139',
      fontVariantNumeric: 'tabular-nums',
      lineHeight: 1.1
    }
  }, value));
}

// --- Use case CaseCard
function CaseCard({
  useCase,
  onSelect,
  dept
}) {
  const a = 0.25;
  const hex = dept?.color || '#6B7280';
  const r = parseInt(hex.slice(1, 3), 16),
    g = parseInt(hex.slice(3, 5), 16),
    b = parseInt(hex.slice(5, 7), 16);
  const bg = `rgb(${Math.round(255 * (1 - a) + r * a)}, ${Math.round(255 * (1 - a) + g * a)}, ${Math.round(255 * (1 - a) + b * a)})`;
  const text = `rgb(${Math.round(r * 0.28)}, ${Math.round(g * 0.28)}, ${Math.round(b * 0.28)})`;
  const textMuted = `rgba(${Math.round(r * 0.28)}, ${Math.round(g * 0.28)}, ${Math.round(b * 0.28)}, .58)`;
  return /*#__PURE__*/React.createElement("div", {
    onClick: () => onSelect?.(useCase),
    style: {
      background: bg,
      borderRadius: 12,
      padding: 16,
      boxShadow: '0 2px 8px rgba(0,0,0,.07)',
      display: 'flex',
      flexDirection: 'column',
      cursor: 'pointer',
      minHeight: 140,
      transition: 'transform .15s ease'
    },
    onMouseEnter: e => e.currentTarget.style.transform = 'translateY(-2px)',
    onMouseLeave: e => e.currentTarget.style.transform = 'translateY(0)'
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'flex-start'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 11,
      fontWeight: 500,
      color: text,
      lineHeight: 1
    }
  }, dept?.name), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 28,
      fontWeight: 900,
      color: text,
      lineHeight: 1,
      fontFamily: 'var(--pt-font-display, "Plus Jakarta Sans")'
    }
  }, useCase.size)), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minHeight: 24
    }
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 14,
      lineHeight: 1.3,
      color: text,
      marginBottom: 10
    }
  }, useCase.name), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 11,
      fontWeight: 500,
      color: textMuted
    }
  }, useCase.duration), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      gap: 8,
      alignItems: 'center',
      fontSize: 11,
      fontWeight: 600
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 3
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 11,
      height: 11,
      background: '#FBBF24',
      display: 'inline-block',
      clipPath: 'polygon(50% 0%,61% 35%,98% 35%,68% 57%,79% 91%,50% 70%,21% 91%,32% 57%,2% 35%,39% 35%)'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      color: textMuted
    }
  }, useCase.impact)), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 3
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 9,
      height: 9,
      borderRadius: '50%',
      background: useCase.effort > 70 ? '#EF4444' : useCase.effort > 40 ? '#FBBF24' : '#22C55E',
      boxShadow: '0 0 0 1px rgba(0,0,0,.15)'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      color: textMuted
    }
  }, useCase.effort)))));
}

// Export to window so other Babel scripts see them
Object.assign(window, {
  Icon,
  AiccBadge,
  StarRating,
  EffortDots,
  KpiCard,
  ModuleCard,
  MiniStat,
  CaseCard
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/aicc/Primitives.jsx", error: String((e && e.message) || e) }); }

// ui_kits/aicc/Screens.jsx
try { (() => {
// AICC main screens — Login, Dashboard, Hub (use cases grid + detail panel)

const FIXTURE_DEPTS = [{
  id: 'sales',
  name: 'Sales',
  color: '#3B82F6'
}, {
  id: 'ops',
  name: 'Operations',
  color: '#F59E0B'
}, {
  id: 'finance',
  name: 'Finance',
  color: '#A78BFA'
}, {
  id: 'people',
  name: 'People',
  color: '#10B981'
}, {
  id: 'marketing',
  name: 'Marketing',
  color: '#EC4899'
}, {
  id: 'it',
  name: 'IT',
  color: '#64748B'
}];
const FIXTURE_CASES = [{
  id: '1',
  name: 'Lead qualifier agent for inbound RFPs',
  dept: 'sales',
  size: 'M',
  impact: 78,
  effort: 52,
  duration: '4–6 sem',
  status: 'in-discovery',
  desc: 'Triage inbound RFPs and surface the top 5 with summarised buying signals before our morning standup.'
}, {
  id: '2',
  name: 'Predictive maintenance on assembly line 4',
  dept: 'ops',
  size: 'L',
  impact: 85,
  effort: 71,
  duration: '8–12 sem',
  status: 'in-progress',
  desc: 'Predict the next failure window per machine using vibration + temperature telemetry.'
}, {
  id: '3',
  name: 'Vendor invoice extraction (OCR + LLM)',
  dept: 'finance',
  size: 'S',
  impact: 64,
  effort: 25,
  duration: '2–4 sem',
  status: 'production',
  desc: 'Extract structured line-items from non-standard supplier PDFs.',
  flag: true
}, {
  id: '4',
  name: 'Internal help desk copilot',
  dept: 'it',
  size: 'M',
  impact: 72,
  effort: 48,
  duration: '4–6 sem',
  status: 'in-discovery',
  desc: 'Answer L1 tickets using internal docs and an MCP-connected ticketing tool.'
}, {
  id: '5',
  name: 'Sales coaching from call transcripts',
  dept: 'sales',
  size: 'M',
  impact: 68,
  effort: 55,
  duration: '4–6 sem',
  status: 'in-progress',
  desc: 'Score discovery calls against the playbook and surface coaching moments.'
}, {
  id: '6',
  name: 'Promotion impact simulator',
  dept: 'marketing',
  size: 'L',
  impact: 81,
  effort: 66,
  duration: '8–10 sem',
  status: 'in-discovery',
  desc: 'Model the uplift of each planned promotion before commit.'
}, {
  id: '7',
  name: 'Performance review summariser',
  dept: 'people',
  size: 'S',
  impact: 55,
  effort: 22,
  duration: '2–3 sem',
  status: 'production',
  desc: 'Compress 360 feedback into a one-page evidence sheet for managers.'
}, {
  id: '8',
  name: 'Anomaly detection in close cycle',
  dept: 'finance',
  size: 'M',
  impact: 73,
  effort: 50,
  duration: '4–6 sem',
  status: 'in-discovery',
  desc: 'Spot odd journal entries before they hit the audit trail.'
}];

/* ───────────────────────── LOGIN VIEW ───────────────────────── */
function LoginView({
  onLogin
}) {
  const [email, setEmail] = React.useState('jane@propellingtech.com');
  const [pw, setPw] = React.useState('hunter2');
  const [pending, setPending] = React.useState(false);
  const [showPw, setShowPw] = React.useState(false);
  const submit = e => {
    e.preventDefault();
    setPending(true);
    setTimeout(() => onLogin(email), 700);
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      minHeight: '100vh',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: 24,
      background: 'var(--aicc-bg-base)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "glass-card",
    style: {
      width: 380,
      padding: 32
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      marginBottom: 20
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "assets/logo.png",
    style: {
      width: 28,
      height: 28,
      objectFit: 'contain'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      lineHeight: 1.1
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 11,
      fontWeight: 800,
      color: 'rgba(45,49,57,.5)',
      textTransform: 'uppercase',
      letterSpacing: '.2em'
    }
  }, "Propelling Tech"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 18,
      fontWeight: 800,
      fontStyle: 'italic',
      color: '#2d3139'
    }
  }, "AI Command Center"))), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '0 0 18px',
      fontSize: 13,
      color: 'rgba(45,49,57,.6)'
    }
  }, "Sign in to continue"), /*#__PURE__*/React.createElement("form", {
    onSubmit: submit,
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 14
    }
  }, /*#__PURE__*/React.createElement("label", null, /*#__PURE__*/React.createElement("span", {
    className: "eyebrow",
    style: {
      display: 'block',
      marginBottom: 6
    }
  }, "Email"), /*#__PURE__*/React.createElement("input", {
    className: "input",
    type: "email",
    value: email,
    onChange: e => setEmail(e.target.value),
    required: true
  })), /*#__PURE__*/React.createElement("label", null, /*#__PURE__*/React.createElement("span", {
    className: "eyebrow",
    style: {
      display: 'block',
      marginBottom: 6
    }
  }, "Password"), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("input", {
    className: "input",
    style: {
      paddingRight: 36
    },
    type: showPw ? 'text' : 'password',
    value: pw,
    onChange: e => setPw(e.target.value),
    required: true
  }), /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: () => setShowPw(v => !v),
    style: {
      position: 'absolute',
      right: 10,
      top: '50%',
      transform: 'translateY(-50%)',
      background: 'none',
      border: 0,
      color: 'rgba(45,49,57,.38)',
      cursor: 'pointer'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: showPw ? 'eye-off' : 'eye',
    size: 15
  })))), /*#__PURE__*/React.createElement("button", {
    type: "submit",
    disabled: pending,
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 8,
      padding: '10px 16px',
      borderRadius: 12,
      border: 0,
      background: '#72d9d9',
      color: '#0d2b2b',
      fontSize: 13,
      fontWeight: 700,
      opacity: pending ? 0.6 : 1,
      cursor: 'pointer',
      marginTop: 4
    }
  }, pending ? /*#__PURE__*/React.createElement("span", {
    className: "dot-spinner"
  }) : /*#__PURE__*/React.createElement(Icon, {
    name: "log-in",
    size: 14
  }), pending ? 'Signing in…' : 'Sign in'))));
}

/* ───────────────────────── DASHBOARD VIEW ───────────────────────── */
function DashboardView({
  onNavigate
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1100,
      display: 'flex',
      flexDirection: 'column',
      gap: 28
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: 0,
      fontSize: 20,
      fontWeight: 600,
      color: '#2d3139'
    }
  }, "Dashboard"), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '4px 0 0',
      fontSize: 13,
      color: 'rgba(45,49,57,.6)'
    }
  }, "Operational summary \xB7 last 7 days")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4, 1fr)',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(KpiCard, {
    label: "Assessed",
    value: "1,287",
    sub: "Avg. score 68/100",
    icon: "users",
    delta: 12
  }), /*#__PURE__*/React.createElement(KpiCard, {
    label: "API Req \xB7 7d",
    value: "42,310",
    icon: "activity"
  }), /*#__PURE__*/React.createElement(KpiCard, {
    label: "AI Cost \xB7 7d",
    value: "$184.22",
    icon: "dollar-sign",
    sub: "avg $0.0044/req"
  }), /*#__PURE__*/React.createElement(KpiCard, {
    label: "Fleet Health",
    value: "82%",
    sub: "2 at risk",
    icon: "cpu"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(2, 1fr)',
      gap: 24
    }
  }, /*#__PURE__*/React.createElement(ModuleCard, {
    title: "Assessment",
    icon: "clipboard-list",
    accent: "var(--aicc-accent)",
    onView: () => onNavigate?.('assessments')
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      columnGap: 32,
      rowGap: 20
    }
  }, /*#__PURE__*/React.createElement(MiniStat, {
    label: "Assessed",
    value: "1,287"
  }), /*#__PURE__*/React.createElement(MiniStat, {
    label: "Avg. score",
    value: "68/100"
  }), /*#__PURE__*/React.createElement(MiniStat, {
    label: "Advanced level",
    value: "184"
  }), /*#__PURE__*/React.createElement(MiniStat, {
    label: "Active campaigns",
    value: "3"
  }))), /*#__PURE__*/React.createElement(ModuleCard, {
    title: "API Adoption",
    icon: "activity",
    accent: "var(--aicc-accent)",
    onView: () => onNavigate?.('adoption')
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      columnGap: 32,
      rowGap: 20
    }
  }, /*#__PURE__*/React.createElement(MiniStat, {
    label: "Requests (7d)",
    value: "42,310"
  }), /*#__PURE__*/React.createElement(MiniStat, {
    label: "Active users",
    value: "48"
  }), /*#__PURE__*/React.createElement(MiniStat, {
    label: "Top model",
    value: "GPT-4o"
  }), /*#__PURE__*/React.createElement(MiniStat, {
    label: "Avg cost/req",
    value: "$0.0044"
  }))), /*#__PURE__*/React.createElement(ModuleCard, {
    title: "AI FinOps",
    icon: "dollar-sign",
    accent: "#34D399",
    onView: () => onNavigate?.('finops')
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      columnGap: 32,
      rowGap: 20
    }
  }, /*#__PURE__*/React.createElement(MiniStat, {
    label: "Total cost (7d)",
    value: "$184.22"
  }), /*#__PURE__*/React.createElement(MiniStat, {
    label: "Avg cost/req",
    value: "$0.0044"
  }), /*#__PURE__*/React.createElement(MiniStat, {
    label: "Most expensive",
    value: "GPT-4o"
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '0 0 4px',
      fontSize: 9,
      color: 'rgba(45,49,57,.38)',
      textTransform: 'uppercase',
      letterSpacing: '.2em'
    }
  }, "Daily cost 7d"), /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 100 32",
    width: "100%",
    height: "32",
    preserveAspectRatio: "none"
  }, /*#__PURE__*/React.createElement("defs", null, /*#__PURE__*/React.createElement("linearGradient", {
    id: "g1",
    x1: "0",
    y1: "0",
    x2: "0",
    y2: "1"
  }, /*#__PURE__*/React.createElement("stop", {
    offset: "5%",
    stopColor: "#34D399",
    stopOpacity: ".2"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: "95%",
    stopColor: "#34D399",
    stopOpacity: "0"
  }))), /*#__PURE__*/React.createElement("path", {
    d: "M0,22 L14,16 L28,20 L42,12 L56,18 L70,8 L84,12 L100,4 L100,32 L0,32 Z",
    fill: "url(#g1)"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M0,22 L14,16 L28,20 L42,12 L56,18 L70,8 L84,12 L100,4",
    stroke: "#34D399",
    strokeWidth: "1.5",
    fill: "none"
  })))), /*#__PURE__*/React.createElement(ModuleCard, {
    title: "Agent Fleet",
    icon: "bot",
    accent: "#F59E0B",
    onView: () => onNavigate?.('fleet')
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      columnGap: 32,
      rowGap: 20
    }
  }, /*#__PURE__*/React.createElement(MiniStat, {
    label: "Workflows",
    value: "12"
  }), /*#__PURE__*/React.createElement(MiniStat, {
    label: "Avg. health",
    value: "82%",
    valueColor: "#22c55e"
  }), /*#__PURE__*/React.createElement(MiniStat, {
    label: "At risk",
    value: "2",
    valueColor: "#ef4444"
  }), /*#__PURE__*/React.createElement(MiniStat, {
    label: "Executions (30d)",
    value: "8,940"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      padding: '8px 12px',
      borderRadius: 8,
      background: 'rgba(239,68,68,.08)',
      border: '1px solid rgba(239,68,68,.2)',
      color: '#ef4444',
      fontSize: 12,
      fontWeight: 600
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "alert-triangle",
    size: 12
  }), " 2 workflows below 70% health"))));
}

/* ───────────────────────── HUB VIEW (use cases) ───────────────────────── */
function HubView() {
  const [selected, setSelected] = React.useState(null);
  const [filter, setFilter] = React.useState('all');
  const cases = filter === 'all' ? FIXTURE_CASES : FIXTURE_CASES.filter(c => c.dept === filter);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 16,
      maxWidth: 1200
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'flex-end',
      gap: 16,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: 0,
      fontSize: 20,
      fontWeight: 600
    }
  }, "Use Cases"), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '4px 0 0',
      fontSize: 13,
      color: 'rgba(45,49,57,.6)'
    }
  }, cases.length, " cases discovered across ", FIXTURE_DEPTS.length, " departments")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("button", {
    className: "btn-ghost",
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "sliders-horizontal",
    size: 12
  }), " Filters"), /*#__PURE__*/React.createElement("button", {
    className: "btn-accent",
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "plus",
    size: 14
  }), " New use case"))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 6,
      flexWrap: 'wrap'
    }
  }, [{
    id: 'all',
    name: 'All',
    color: '#2d3139'
  }, ...FIXTURE_DEPTS].map(d => /*#__PURE__*/React.createElement("button", {
    key: d.id,
    onClick: () => setFilter(d.id),
    style: {
      padding: '6px 12px',
      borderRadius: 999,
      border: filter === d.id ? '0' : '1px solid rgba(0,0,0,.08)',
      background: filter === d.id ? d.color : 'transparent',
      color: filter === d.id ? '#fff' : 'rgba(45,49,57,.7)',
      fontSize: 11,
      fontWeight: 700,
      cursor: 'pointer'
    }
  }, d.name))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))',
      gap: 12
    }
  }, cases.map(c => /*#__PURE__*/React.createElement(CaseCard, {
    key: c.id,
    useCase: c,
    dept: FIXTURE_DEPTS.find(d => d.id === c.dept),
    onSelect: setSelected
  }))), selected && /*#__PURE__*/React.createElement(CaseDetailPanel, {
    useCase: selected,
    dept: FIXTURE_DEPTS.find(d => d.id === selected.dept),
    onClose: () => setSelected(null)
  }));
}
function CaseDetailPanel({
  useCase,
  dept,
  onClose
}) {
  const a = 0.22;
  const hex = dept?.color || '#6B7280';
  const r = parseInt(hex.slice(1, 3), 16),
    g = parseInt(hex.slice(3, 5), 16),
    b = parseInt(hex.slice(5, 7), 16);
  const bg = `rgb(${Math.round(255 * (1 - a) + r * a)}, ${Math.round(255 * (1 - a) + g * a)}, ${Math.round(255 * (1 - a) + b * a)})`;
  const text = `rgb(${Math.round(r * 0.28)}, ${Math.round(g * 0.28)}, ${Math.round(b * 0.28)})`;
  const textMuted = `rgba(${Math.round(r * 0.28)}, ${Math.round(g * 0.28)}, ${Math.round(b * 0.28)}, 0.6)`;
  const border = `rgba(${r},${g},${b},.18)`;
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    onClick: onClose,
    style: {
      position: 'fixed',
      inset: 0,
      background: 'rgba(0,0,0,.22)',
      zIndex: 40
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'fixed',
      right: 0,
      top: 0,
      bottom: 0,
      width: 540,
      zIndex: 50,
      background: bg,
      borderLeft: `1px solid ${border}`,
      boxShadow: '-12px 0 48px rgba(0,0,0,.14)',
      display: 'flex',
      flexDirection: 'column',
      animation: 'slidein .3s ease'
    }
  }, /*#__PURE__*/React.createElement("style", null, `@keyframes slidein { from { transform: translateX(20px); opacity: .5; } to { transform: translateX(0); opacity: 1; } }`), /*#__PURE__*/React.createElement("button", {
    onClick: onClose,
    style: {
      position: 'absolute',
      top: 'calc(50% - 28px)',
      left: -28,
      width: 28,
      height: 56,
      background: bg,
      border: `1px solid ${border}`,
      borderRight: 'none',
      borderRadius: '8px 0 0 8px',
      color: textMuted,
      cursor: 'pointer'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "chevron-right",
    size: 13
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '20px 20px 18px',
      borderBottom: `1px solid ${border}`
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 11,
      fontWeight: 500,
      color: text
    }
  }, dept?.name), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 10,
      color: textMuted
    }
  }, useCase.status)), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 48,
      fontWeight: 900,
      color: text,
      lineHeight: 1
    }
  }, useCase.size)), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '16px 0 14px',
      fontSize: 20,
      color: text,
      lineHeight: 1.25
    }
  }, useCase.name), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 10,
      color: textMuted
    }
  }, "Value"), /*#__PURE__*/React.createElement(StarRating, {
    score: useCase.impact
  }), " ", /*#__PURE__*/React.createElement("b", {
    style: {
      color: text
    }
  }, useCase.impact)), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 10,
      color: textMuted
    }
  }, "Effort"), /*#__PURE__*/React.createElement(EffortDots, {
    score: useCase.effort
  }), " ", /*#__PURE__*/React.createElement("b", {
    style: {
      color: text
    }
  }, useCase.effort)), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 11,
      color: textMuted
    }
  }, useCase.duration)), useCase.flag && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 10,
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      padding: '4px 10px',
      borderRadius: 999,
      background: 'rgba(245,158,11,.15)',
      border: '1px solid rgba(245,158,11,.4)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "shield-alert",
    size: 11,
    color: "#F59E0B"
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 11,
      fontWeight: 600,
      color: '#F59E0B'
    }
  }, "Restricted"))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '14px 20px',
      borderBottom: `1px solid ${border}`
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '0 0 6px',
      fontSize: 9,
      fontWeight: 800,
      textTransform: 'uppercase',
      letterSpacing: '.12em',
      color: textMuted
    }
  }, "Description"), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 12,
      color: text,
      opacity: .85,
      lineHeight: 1.5
    }
  }, useCase.desc)), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflowY: 'auto',
      padding: '16px 20px',
      display: 'flex',
      flexDirection: 'column',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("section", null, /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '0 0 10px',
      fontSize: 9,
      fontWeight: 800,
      textTransform: 'uppercase',
      letterSpacing: '.12em',
      color: textMuted
    }
  }, "Acceptance criteria (3)"), ['Top-5 surfaced before 9:00 daily', 'Score correlates ≥0.7 with last-quarter close rate', 'Connector test pack passes on 100% of mocks'].map((c, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: 'flex',
      alignItems: 'flex-start',
      gap: 10,
      padding: 12,
      borderRadius: 12,
      background: 'rgba(255,255,255,.58)',
      border: `1px solid ${border}`,
      marginBottom: 8
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "check-circle-2",
    size: 14,
    color: "#16a34a",
    style: {
      marginTop: 2
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      color: text
    }
  }, c)))), /*#__PURE__*/React.createElement("section", null, /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '0 0 8px',
      fontSize: 9,
      fontWeight: 800,
      textTransform: 'uppercase',
      letterSpacing: '.12em',
      color: textMuted
    }
  }, "Planning"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      padding: 12,
      borderRadius: 12,
      background: 'rgba(255,255,255,.58)',
      border: `1px solid ${border}`
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13,
      fontWeight: 600,
      color: text
    }
  }, "Starts March 18, 2026"), /*#__PURE__*/React.createElement("button", {
    style: {
      border: `1px solid ${border}`,
      color: textMuted,
      fontSize: 10,
      padding: '4px 8px',
      borderRadius: 8,
      background: 'transparent',
      cursor: 'pointer'
    }
  }, "Change"))))));
}
Object.assign(window, {
  LoginView,
  DashboardView,
  HubView
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/aicc/Screens.jsx", error: String((e && e.message) || e) }); }

// ui_kits/aicc/Shell.jsx
try { (() => {
// AICC Sidebar — mirrors propelling-aicc/src/components/layout/Sidebar.tsx

const NAV_SECTIONS = [{
  title: null,
  items: [{
    key: 'dashboard',
    label: 'Dashboard',
    icon: 'layout-dashboard'
  }]
}, {
  title: 'Enablement',
  items: [{
    key: 'trainings',
    label: 'Trainings',
    icon: 'graduation-cap',
    locked: true
  }, {
    key: 'adoption',
    label: 'Adoption',
    icon: 'trending-up'
  }, {
    key: 'assessments',
    label: 'Assessments',
    icon: 'clipboard-list'
  }, {
    key: 'pulse',
    label: 'Pulse',
    icon: 'bar-chart-3',
    sub: true
  }]
}, {
  title: 'Discovery',
  items: [{
    key: 'hub',
    label: 'Use Cases',
    icon: 'folder-kanban'
  }]
}, {
  title: 'Build',
  items: [{
    key: 'templates',
    label: 'Templates',
    icon: 'package',
    locked: true
  }, {
    key: 'catalog',
    label: 'Catalogue',
    icon: 'book-open',
    locked: true
  }]
}, {
  title: 'Govern & Control',
  items: [{
    key: 'fleet',
    label: 'Agent Fleet',
    icon: 'bot'
  }, {
    key: 'finops',
    label: 'AI FinOps',
    icon: 'bar-chart-2'
  }]
}, {
  title: 'Settings',
  items: [{
    key: 'users',
    label: 'Users',
    icon: 'shield-check'
  }, {
    key: 'team',
    label: 'Team',
    icon: 'users-2'
  }, {
    key: 'scoring',
    label: 'Scoring criteria',
    icon: 'sliders-horizontal'
  }, {
    key: 'context',
    label: 'Context fields',
    icon: 'layout-list'
  }]
}];
function Sidebar({
  active,
  onSelect
}) {
  const [collapsed, setCollapsed] = React.useState(false);
  const w = collapsed ? 64 : 240;
  return /*#__PURE__*/React.createElement("aside", {
    style: {
      width: w,
      flexShrink: 0,
      height: '100%',
      background: 'var(--aicc-sidebar-bg)',
      borderRight: '1px solid var(--aicc-sidebar-border)',
      display: 'flex',
      flexDirection: 'column',
      overflow: 'hidden',
      transition: 'width .2s ease'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      padding: '0 14px',
      height: 'var(--aicc-header-h)',
      borderBottom: '1px solid var(--aicc-sidebar-border)'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "assets/logo.png",
    alt: "Propelling Tech",
    style: {
      width: 22,
      height: 22,
      objectFit: 'contain',
      flexShrink: 0
    }
  }), !collapsed && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13,
      fontWeight: 800,
      color: '#f0f4f8',
      letterSpacing: '.02em',
      fontStyle: 'italic'
    }
  }, "AI Command Center")), /*#__PURE__*/React.createElement("nav", {
    style: {
      flex: 1,
      overflowY: 'auto',
      padding: '10px 8px'
    }
  }, NAV_SECTIONS.map((section, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      marginTop: i > 0 ? 4 : 0
    }
  }, section.title && !collapsed && /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '14px 10px 6px',
      fontSize: 9,
      fontWeight: 800,
      textTransform: 'uppercase',
      letterSpacing: '.18em',
      color: 'rgba(240,244,248,0.5)'
    }
  }, section.title), section.title && collapsed && /*#__PURE__*/React.createElement("div", {
    style: {
      margin: '8px',
      height: 1,
      background: 'rgba(255,255,255,.08)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 1
    }
  }, section.items.map(item => {
    const isActive = !item.locked && active === item.key;
    const locked = !!item.locked;
    const pl = item.sub && !collapsed ? 22 : 8;
    return /*#__PURE__*/React.createElement("button", {
      key: item.key,
      onClick: () => !locked && onSelect?.(item.key),
      title: collapsed ? item.label : undefined,
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 10,
        padding: `7px ${10}px 7px ${pl}px`,
        borderRadius: 6,
        border: 0,
        background: isActive ? 'rgba(114,217,217,.12)' : 'transparent',
        color: isActive ? '#72d9d9' : locked ? 'rgba(240,244,248,.25)' : 'rgba(240,244,248,.5)',
        borderLeft: isActive ? '2px solid #72d9d9' : '2px solid transparent',
        fontSize: 13,
        fontWeight: 500,
        textAlign: 'left',
        cursor: locked ? 'not-allowed' : 'pointer',
        width: '100%',
        opacity: locked ? 0.55 : 1
      },
      onMouseEnter: e => {
        if (!isActive && !locked) e.currentTarget.style.background = 'rgba(255,255,255,.07)';
      },
      onMouseLeave: e => {
        if (!isActive) e.currentTarget.style.background = isActive ? 'rgba(114,217,217,.12)' : 'transparent';
      }
    }, !item.sub && /*#__PURE__*/React.createElement(Icon, {
      name: item.icon,
      size: 14
    }), item.sub && !collapsed && /*#__PURE__*/React.createElement("span", {
      style: {
        width: 4,
        height: 4,
        borderRadius: '50%',
        background: isActive ? '#72d9d9' : 'rgba(240,244,248,.5)',
        opacity: isActive ? 1 : 0.5
      }
    }), !collapsed && /*#__PURE__*/React.createElement("span", {
      style: {
        flex: 1
      }
    }, item.label), locked && !collapsed && /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 8,
        fontWeight: 800,
        letterSpacing: '.1em',
        textTransform: 'uppercase',
        color: '#72d9d9',
        background: 'rgba(114,217,217,.14)',
        padding: '1px 5px',
        borderRadius: 4
      }
    }, "Soon"));
  }))))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 8,
      borderTop: '1px solid rgba(255,255,255,.08)'
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: () => setCollapsed(v => !v),
    style: {
      width: '100%',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: 8,
      borderRadius: 6,
      border: 0,
      background: 'transparent',
      color: 'rgba(240,244,248,.5)',
      cursor: 'pointer'
    },
    onMouseEnter: e => e.currentTarget.style.background = 'rgba(255,255,255,.07)',
    onMouseLeave: e => e.currentTarget.style.background = 'transparent'
  }, /*#__PURE__*/React.createElement(Icon, {
    name: collapsed ? 'chevron-right' : 'chevron-left',
    size: 13
  }))));
}
function Header({
  user,
  onLogout,
  locale,
  onLocale
}) {
  return /*#__PURE__*/React.createElement("header", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '0 24px',
      height: 'var(--aicc-header-h)',
      flexShrink: 0,
      background: '#fff',
      borderBottom: '1px solid rgba(0,0,0,.08)'
    }
  }, /*#__PURE__*/React.createElement("div", null), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 4,
      background: 'rgba(0,0,0,.04)',
      padding: 2,
      borderRadius: 8
    }
  }, ['en', 'es'].map(l => /*#__PURE__*/React.createElement("button", {
    key: l,
    onClick: () => onLocale?.(l),
    style: {
      padding: '4px 10px',
      borderRadius: 6,
      border: 0,
      background: locale === l ? '#fff' : 'transparent',
      fontSize: 11,
      fontWeight: 700,
      textTransform: 'uppercase',
      letterSpacing: '.1em',
      color: locale === l ? '#2d3139' : 'rgba(45,49,57,.5)',
      cursor: 'pointer',
      boxShadow: locale === l ? '0 1px 2px rgba(0,0,0,.06)' : 'none'
    }
  }, l))), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 11,
      color: 'rgba(45,49,57,.5)'
    }
  }, user), /*#__PURE__*/React.createElement("button", {
    onClick: onLogout,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      padding: '6px 10px',
      borderRadius: 8,
      border: '1px solid rgba(0,0,0,.08)',
      background: 'rgba(0,0,0,.02)',
      color: 'rgba(45,49,57,.7)',
      fontSize: 12,
      fontWeight: 600,
      cursor: 'pointer'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "log-out",
    size: 12
  }), " Sign out")));
}
Object.assign(window, {
  Sidebar,
  Header
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/aicc/Shell.jsx", error: String((e && e.message) || e) }); }

// ui_kits/aicc/app.jsx
try { (() => {
// AICC entry — composes Sidebar + Header + active view.
const {
  useState
} = React;
function App() {
  const [user, setUser] = useState(null);
  const [active, setActive] = useState('dashboard');
  const [locale, setLocale] = useState('en');
  if (!user) return /*#__PURE__*/React.createElement(LoginView, {
    onLogin: setUser
  });
  let view;
  switch (active) {
    case 'dashboard':
      view = /*#__PURE__*/React.createElement(DashboardView, {
        onNavigate: setActive
      });
      break;
    case 'hub':
      view = /*#__PURE__*/React.createElement(HubView, null);
      break;
    default:
      view = /*#__PURE__*/React.createElement(Placeholder, {
        name: active
      });
  }
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      height: '100vh',
      background: 'var(--aicc-bg-base)'
    }
  }, /*#__PURE__*/React.createElement(Sidebar, {
    active: active,
    onSelect: setActive
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      display: 'flex',
      flexDirection: 'column',
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement(Header, {
    user: user,
    locale: locale,
    onLocale: setLocale,
    onLogout: () => setUser(null)
  }), /*#__PURE__*/React.createElement("main", {
    style: {
      flex: 1,
      overflowY: 'auto',
      padding: 24
    }
  }, view)));
}
function Placeholder({
  name
}) {
  const titles = {
    adoption: ['Adoption', 'Usage and adoption metrics for your AI tool'],
    assessments: ['Assessments', 'AI readiness assessments for your team'],
    pulse: ['Pulse', 'Results across your active assessments'],
    fleet: ['Agent Fleet', 'Live status of every deployed workflow'],
    finops: ['AI FinOps', 'Cost, latency & token economics'],
    users: ['Users', 'Access roles & permissions'],
    team: ['Team', 'People and reporting lines'],
    scoring: ['Scoring criteria', 'Impact + effort weights and options'],
    context: ['Context fields', 'Custom metadata for use cases']
  };
  const [t, sub] = titles[name] || [name, 'View placeholder — wire up when the real screen lands'];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 900
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: 0,
      fontSize: 20,
      fontWeight: 600
    }
  }, t), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '4px 0 24px',
      fontSize: 13,
      color: 'rgba(45,49,57,.6)'
    }
  }, sub), /*#__PURE__*/React.createElement("div", {
    className: "glass-card",
    style: {
      padding: 40,
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "construction",
    size: 28,
    color: "rgba(45,49,57,.3)"
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '12px 0 4px',
      fontSize: 13,
      color: 'rgba(45,49,57,.6)',
      fontWeight: 600
    }
  }, "Coming from a real screen"), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 12,
      color: 'rgba(45,49,57,.45)'
    }
  }, "This UI kit ships placeholders for screens the codebase has but the kit doesn't redraw 1:1.")));
}
ReactDOM.createRoot(document.getElementById('root')).render(/*#__PURE__*/React.createElement(App, null));
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/aicc/app.jsx", error: String((e && e.message) || e) }); }

})();
